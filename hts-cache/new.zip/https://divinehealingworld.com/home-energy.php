

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Divinehealingworld
    </title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Playfair+Display:wght@500;600&display=swap"
        rel="stylesheet"
    >

    <style>

        :root {
            --purple: #382342;
            --dark-purple: #24142e;
            --pink: #b61491;
            --text: #302632;
            --muted: #817782;
            --border: #ebe7ec;
            --light: #faf8fb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "DM Sans", sans-serif;
            color: var(--text);
            background: #fff;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            font-family: inherit;
        }


        /* =========================
           TOP BAR
        ========================= */

        .top-bar {
            height: 29px;
            background: var(--pink);
            color: #fff;
            padding: 0 5.5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 10px;
        }

        .top-bar-item {
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .top-bar-item i {
            font-size: 11px;
        }


        /* =========================
           HEADER
        ========================= */

        .header {
            height: 78px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            position: relative;
            z-index: 1000;
        }

        .header-container {
            width: 89%;
            max-width: 1440px;
            height: 100%;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }


        /* LOGO */

        .logo {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 235px;
        }

        .logo-symbol {
            width: 43px;
            height: 43px;
            position: relative;
        }

        .logo-symbol img {
            width: 50px;
            height: -10px;
            object-fit: contain;
        }

        .logo-content h1 {
            font-family: "Playfair Display", serif;
            font-size: 25px;
            font-weight: 600;
            line-height: 1;
            color: var(--purple);
            letter-spacing: -0.5px;
        }

        .logo-content p {
            font-size: 10px;
            color: #77707b;
            margin-top: 4px;
            letter-spacing: .35px;
        }


        /* NAVIGATION */

        .navigation {
            height: 100%;
            display: flex;
            align-items: center;
            gap: 34px;
        }

        .nav-link {
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
            font-size: 12px;
            color: #302932;
            transition: color .25s ease;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 19px;
            width: 0;
            height: 2px;
            background: var(--purple);
            transition: width .3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            color: var(--purple);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .shop-link {
            gap: 6px;
        }

        .shop-link i {
            font-size: 8px;
        }


        /* SHOP DROPDOWN */

        .shop-dropdown {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
        }

        .shop-menu {
            display: none;
            list-style: none;
            padding: 8px 0;
            margin: 0;
            position: absolute;
            top: 100%;
            left: 0;
            min-width: 230px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 10px 28px rgba(36,20,46,.12);
            z-index: 9999;
        }

        .shop-dropdown:hover .shop-menu {
            display: block;
        }

        .shop-dropdown:hover .shop-link i {
            transform: rotate(180deg);
        }

        .shop-link i {
            transition: .25s ease;
        }

        .shop-menu li a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 11px 15px;
            color: #333;
            font-size: 13px;
            transition: .2s ease;
        }

        .shop-menu li a:hover {
            background: #faf5fb;
            color: var(--pink);
        }

        .shop-menu li a i {
            width: 17px;
            color: var(--purple);
            font-size: 12px;
        }


        /* HEADER ACTIONS */

        .header-actions {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .header-icon {
            border: 0;
            background: transparent;
            color: #302632;
            font-size: 17px;
            width: 20px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
        }

        .header-icon:hover {
            color: var(--purple);
        }

        .badge-icon span {
            position: absolute;
            top: -5px;
            right: -8px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--purple);
            color: #fff;
            font-size: 8px;
            font-weight: 600;
        }


        /* MOBILE */

        .mobile-menu-button {
            display: none;
            border: 0;
            background: transparent;
            font-size: 19px;
            color: var(--purple);
            cursor: pointer;
        }

        .mobile-navigation {
            display: none;
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 10px 5%;
            position: relative;
            z-index: 999;
            box-shadow: 0 8px 20px rgba(0,0,0,.06);
        }

        .mobile-navigation.show {
            display: block;
        }

        .mobile-navigation a {
            display: block;
            padding: 13px 5px;
            border-bottom: 1px solid #f0edf1;
            font-size: 13px;
        }

        .mobile-shop {
            border-bottom: 1px solid #f0edf1;
        }

        .mobile-shop-toggle {
            width: 100%;
            padding: 13px 5px;
            border: 0;
            background: transparent;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-family: inherit;
            font-size: 13px;
            color: #302932;
            cursor: pointer;
        }

        .mobile-shop-toggle i {
            font-size: 10px;
            transition: transform .25s ease;
        }

        .mobile-shop.open .mobile-shop-toggle i {
            transform: rotate(180deg);
        }

        .mobile-shop-menu {
            display: none;
            padding: 0 0 5px 14px;
        }

        .mobile-shop.open .mobile-shop-menu {
            display: block;
        }

        .mobile-shop-menu a {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 10px 5px;
            border-bottom: 0;
            font-size: 12px;
            color: #625a63;
        }

        .mobile-shop-menu i {
            width: 14px;
            font-size: 11px;
        }


        /* =========================
           SHOP PRODUCTS PAGE
        ========================= */


        .shop-heading {
            text-align: center;
            margin-bottom: 35px;
        }

        .shop-heading h2 {
            font-family: "Playfair Display", serif;
            font-size: 34px;
            color: var(--purple);
            margin-bottom: 8px;
        }

        .shop-heading p {
            color: var(--muted);
            font-size: 13px;
        }


        /* PRODUCT CARD */

        .products-list {
            display: grid;
            grid-template-columns: 1fr;
            gap: 18px;
        }

        .product-card {
            display: grid;
            grid-template-columns: 230px 1fr;
            gap: 25px;
            padding: 18px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            box-shadow: 0 7px 24px rgba(36,20,46,.05);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(36,20,46,.09);
        }

        .product-image-wrap {
            width: 230px;
            height: 230px;
            border-radius: 12px;
            overflow: hidden;
            background: #faf8fb;
        }

        .product-image-wrap img {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
        }

        .product-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 5px 10px 5px 0;
        }

        .product-title {
            color: var(--pink);
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 7px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .product-name {
            font-family: "Playfair Display", serif;
            color: var(--purple);
            font-size: 27px;
            font-weight: 600;
            margin-bottom: 11px;
        }

        .product-description {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.7;
            max-width: 700px;
            margin-bottom: 18px;
        }

        .product-bottom {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .product-price {
            color: var(--purple);
            font-size: 21px;
            font-weight: 700;
        }

        .add-cart-btn {
            border: 0;
            border-radius: 8px;
            padding: 11px 19px;
            background: var(--purple);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: .25s ease;
        }

        .add-cart-btn:hover {
            background: var(--pink);
        }

        .empty-products {
            text-align: center;
            padding: 55px 20px;
            border: 1px dashed #ddd5df;
            border-radius: 14px;
            color: var(--muted);
        }

        .empty-products i {
            font-size: 35px;
            color: #c7bdc9;
            margin-bottom: 12px;
        }

        .all-categories {
            display: flex;
            justify-content: center;
            gap: 9px;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .category-pill {
            padding: 8px 14px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 11px;
            color: var(--purple);
            background: #fff;
        }

        .category-pill:hover {
            background: #faf5fb;
            border-color: #d9c9dc;
        }


        /* RESPONSIVE */

        @media (max-width: 1000px) {

            .header-container {
                width: 92%;
            }

            .navigation {
                gap: 20px;
            }

            .nav-link {
                font-size: 11px;
            }

            .logo {
                min-width: 205px;
            }

            .logo-content h1 {
                font-size: 22px;
            }

            .header-actions {
                gap: 13px;
            }

            .shop-page {
                width: 92%;
            }

        }

        @media (max-width: 768px) {

            .top-bar {
                display: none;
            }

            .header {
                height: 70px;
            }

            .navigation {
                display: none;
            }

            .header-container {
                width: 92%;
            }

            .header-actions {
                gap: 13px;
            }

            .header-actions .header-icon:nth-child(1),
            .header-actions .header-icon:nth-child(2) {
                display: none;
            }

            .mobile-menu-button {
                display: flex;
            }

            .logo {
                min-width: auto;
            }

            .logo-content h1 {
                font-size: 21px;
            }

            .logo-content p {
                font-size: 7px;
            }

            .shop-page {
                width: 92%;
                padding-top: 38px;
            }

            .shop-heading h2 {
                font-size: 28px;
            }

            .product-card {
                grid-template-columns: 1fr;
                gap: 17px;
            }

            .product-image-wrap {
                width: 100%;
                height: 260px;
            }

            .product-info {
                padding: 0 4px 5px;
            }

            .product-name {
                font-size: 23px;
            }

        }

        @media (max-width: 420px) {

            .header-container {
                width: 90%;
            }

            .header-actions {
                gap: 9px;
            }

            .product-image-wrap {
                height: 230px;
            }

            .product-bottom {
                align-items: flex-start;
                flex-direction: column;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     TOP BAR
========================= -->

<!--<div class="top-bar">

    <div class="top-bar-item">
        <i class="fa-solid fa-truck"></i>
        <span>Free Shipping All Over India</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-regular fa-gem"></i>
        <span>100% Natural & Authentic Crystals</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-solid fa-shield-halved"></i>
        <span>Easy Returns & Secure Payments</span>
    </div>

</div>-->


<!-- =========================
     HEADER
========================= -->

<header class="header">

    <div class="header-container">


        <a href="https://divinehealingworld.com/" class="logo">

            <div class="logo-symbol">

                <img
                    src="https://vectorjungal.com/files/preview/1280x977/11724061489x7dnzumlkkkdctwc1jp9s6hmcc7hkelbcywsoq1ks90ylksgcvupex8nfc0knms8robegbblqtofo2ckk2viwtbtpyhxqomm1o4i.png"
                    alt="Divinehealingworld"
                >

            </div>

            <div class="logo-content">

                <h1>Divine Healing world</h1>

                <p>Nature's Energy. Your Style</p>

            </div>

        </a>


        <nav class="navigation">

            <a href="https://divinehealingworld.com/" class="nav-link">
                Home
            </a>
<a href="/reiki-healing.php" class="nav-link">
                Reiki Healing
            

            <a href="/tarot-reading.php" class="nav-link">
                Tarot Reading
            </a>

            <a href="/akashic-records.php" class="nav-link">
                Akashic Records
            </a>

            <a href="/animal-communication.php" class="nav-link">
                Animal Communication
            </a>

  <a href="/psychic-mediumship.php" class="nav-link">
                Psychic Mediumship
            </a>                          <div class="shop-dropdown">

              <!---  <a
                    href="#"
                    class="nav-link shop-link "
                    aria-haspopup="true"
                >
                    Shop
                    <i class="fa-solid fa-chevron-down"></i>
                </a>


                <ul class="shop-menu">
                    /
                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=3"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Crystals
                                </a>

                            </li>

                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=4"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Rings
                                </a>

                            </li>

                        
                    
                </ul>---->

            </div>


        </nav>


        <div class="header-actions">
         <style>
         .session-btn
         {
             background:black;
             color:#fff;
             font-size:15px;
             font-weight:bold;
             border:solid 1px white;
             padding:10px;
             border-radius:15px;
         }
         
         </style>
            <button class="session-btn"><a href="book-your-session.php">Book Session</a></button>
        </div>

    </div>

</header>


<!-- =========================
     MOBILE NAV
========================= -->

<nav
    class="mobile-navigation"
    id="mobileNavigation"
>

    <a href="index.php">
        Home
    </a>


    <div class="mobile-shop">

        <button
            type="button"
            class="mobile-shop-toggle"
            id="mobileShopToggle"
        >

            <span>
                Shop
            </span>

            <i class="fa-solid fa-chevron-down"></i>

        </button>


        <div
            class="mobile-shop-menu"
            id="mobileShopMenu"
        >

            <a href="products.php">

                <i class="fa-solid fa-box"></i>

                Products

            </a>


            <a href="best-sellers.php">

                <i class="fa-solid fa-star"></i>

                Best Sellers

            </a>


            
                <a
                    href="shop-category-products.php?category_id=3"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Crystals
                </a>

            
                <a
                    href="shop-category-products.php?category_id=4"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Rings
                </a>

            
        </div>

    </div>


    <a href="about.php">
        About Us
    </a>

    <a href="#">
        Tarot Reading
    </a>

    <a href="#">
        Akashic Records
    </a>

    <a href="#">
        Animal Communication
    </a>

</nav>


<!-- =========================
     PRODUCTS
========================= -->

<main class="shop-page">

    

</main>


<script>

    /* =========================
       MOBILE MENU
    ========================= */

    const menuButton =
        document.getElementById("menuButton");

    const mobileNavigation =
        document.getElementById("mobileNavigation");

    const menuIcon =
        menuButton
            ? menuButton.querySelector("i")
            : null;


    if (
        menuButton &&
        mobileNavigation &&
        menuIcon
    ) {

        menuButton.addEventListener("click", () => {

            mobileNavigation.classList.toggle("show");

            if (
                mobileNavigation.classList.contains("show")
            ) {

                menuIcon.classList.remove("fa-bars");
                menuIcon.classList.add("fa-xmark");

            } else {

                menuIcon.classList.remove("fa-xmark");
                menuIcon.classList.add("fa-bars");

            }

        });

    }


    /* =========================
       MOBILE SHOP
    ========================= */

    const mobileShopToggle =
        document.getElementById("mobileShopToggle");

    const mobileShop =
        document.querySelector(".mobile-shop");


    if (
        mobileShopToggle &&
        mobileShop
    ) {

        mobileShopToggle.addEventListener(
            "click",
            function () {

                mobileShop.classList.toggle("open");

            }
        );

    }


    /* =========================
       ADD TO CART
       UI READY
    ========================= */

    document
        .querySelectorAll(".add-cart-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                function () {

                    const productName =
                        this.dataset.productName || "Product";

                    alert(
                        productName +
                        " added to cart."
                    );

                }
            );

        });


    /* =========================
       CLOSE MOBILE MENU
    ========================= */

    document
        .querySelectorAll(".mobile-navigation a")
        .forEach(link => {

            link.addEventListener(
                "click",
                function () {

                    if (mobileNavigation) {
                        mobileNavigation.classList.remove("show");
                    }

                    if (menuIcon) {

                        menuIcon.classList.remove("fa-xmark");
                        menuIcon.classList.add("fa-bars");

                    }

                    if (mobileShop) {
                        mobileShop.classList.remove("open");
                    }

                }
            );

        });

</script>

</body>
</html>

<style>
/* HOME ENERGY HEALING PAGE */

.home-energy {
    --he-purple: #301745;
    --he-gold: #c69b59;
    --he-cream: #faf7f2;
    --he-text: #6e6375;
    font-family: 'Poppins', sans-serif;
    color: var(--he-text);
    overflow: hidden;
}

.home-energy * {
    box-sizing: border-box;
}

.he-container {
    width: 90%;
    max-width: 1200px;
    margin: auto;
}

.he-section {
    padding: 85px 0;
}

.he-subtitle {
    color: var(--he-gold);
    font-size: 12px;
    letter-spacing: 3px;
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 15px;
}

.he-heading {
    color: var(--he-purple);
    font-family: Georgia, serif;
    font-size: clamp(30px, 4vw, 44px);
    line-height: 1.25;
    font-weight: 500;
    margin: 0 0 20px;
}

.he-description {
    font-size: 15px;
    line-height: 1.9;
    color: var(--he-text);
}

.he-btn {
    display: inline-block;
    padding: 15px 30px;
    background: var(--he-gold);
    color: var(--he-purple) !important;
    text-decoration: none !important;
    font-size: 12px;
    letter-spacing: 1px;
    font-weight: 700;
    border: 1px solid var(--he-gold);
    border-radius: 3px;
    transition: .3s;
}

.he-btn:hover {
    background: var(--he-purple);
    border-color: var(--he-purple);
    color: white !important;
    transform: translateY(-3px);
}

/* HERO */

.he-hero {
    min-height: 630px;
    display: flex;
    align-items: center;
    position: relative;
    background:
        linear-gradient(90deg, rgba(35,17,48,.94), rgba(35,17,48,.75), rgba(35,17,48,.18)),
        url('https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2000&q=85');
    background-size: cover;
    background-position: center;
}

.he-hero-content {
    max-width: 690px;
    padding: 90px 0;
    animation: heFade 1s ease;
}

.he-hero .he-subtitle {
    color: #e4c48e;
}

.he-hero h1 {
    font-family: Georgia, serif;
    color: white;
    font-size: clamp(42px, 6vw, 68px);
    line-height: 1.12;
    font-weight: 500;
    margin: 0 0 25px;
}

.he-hero h1 span {
    color: #e4c48e;
    font-style: italic;
}

.he-hero p {
    color: #eee4f1;
    font-size: 15px;
    line-height: 1.9;
    max-width: 590px;
    margin-bottom: 32px;
}

/* INTRO */

.he-intro {
    background: var(--he-cream);
}

.he-intro-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 65px;
    align-items: center;
}

.he-image-wrap {
    position: relative;
}

.he-image-wrap img {
    width: 100%;
    height: 490px;
    object-fit: cover;
    position: relative;
    z-index: 1;
    border-radius: 3px;
}

.he-image-wrap:after {
    content: "";
    position: absolute;
    width: 75%;
    height: 75%;
    right: -15px;
    bottom: -15px;
    border: 2px solid var(--he-gold);
}

.he-intro-content {
    padding: 20px 0;
}

/* HIGHLIGHTS */

.he-highlights {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
    margin-top: 30px;
}

.he-highlight {
    display: flex;
    align-items: center;
    gap: 12px;
    color: var(--he-purple);
    font-size: 13px;
    font-weight: 600;
}

.he-highlight span {
    min-width: 38px;
    height: 38px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    background: #eee5f1;
    color: var(--he-gold);
    font-size: 19px;
}

/* WHY CLEAR */

.he-why {
    background: white;
    text-align: center;
}

.he-center-heading {
    max-width: 730px;
    margin: 0 auto 45px;
}

.he-why-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}

.he-why-card {
    padding: 35px 25px;
    background: var(--he-cream);
    border: 1px solid #eee5ed;
    border-radius: 4px;
    transition: .3s;
}

.he-why-card:hover {
    transform: translateY(-7px);
    border-color: var(--he-gold);
    box-shadow: 0 15px 35px rgba(48,23,69,.08);
}

.he-icon {
    width: 65px;
    height: 65px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--he-purple);
    color: #e5c38c;
    border-radius: 50%;
    font-size: 27px;
    margin: 0 auto 22px;
}

.he-why-card h3 {
    color: var(--he-purple);
    font-family: Georgia, serif;
    font-size: 21px;
    margin: 0 0 14px;
}

.he-why-card p {
    font-size: 13px;
    line-height: 1.9;
    margin: 0;
}

/* WHEN TO CONSIDER */

.he-consider {
    background: var(--he-cream);
}

.he-consider-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 60px;
    align-items: center;
}

.he-consider-image img {
    width: 100%;
    height: 480px;
    object-fit: cover;
    border-radius: 4px;
}

.he-check-list {
    padding: 0;
    margin: 25px 0 30px;
    list-style: none;
}

.he-check-list li {
    padding: 13px 0;
    border-bottom: 1px solid #e9e0e9;
    font-size: 14px;
    line-height: 1.7;
}

.he-check-list li:before {
    content: "✦";
    color: var(--he-gold);
    margin-right: 12px;
}

/* TYPES */

.he-types {
    background: white;
}

.he-types-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 25px;
    margin-top: 40px;
}

.he-type-card {
    background: #fff;
    border: 1px solid #eee5ed;
    overflow: hidden;
    transition: .3s;
}

.he-type-card:hover {
    transform: translateY(-6px);
    box-shadow: 0 15px 35px rgba(48,23,69,.1);
}

.he-type-card img {
    width: 100%;
    height: 230px;
    object-fit: cover;
}

.he-type-content {
    padding: 25px;
}

.he-type-content h3 {
    color: var(--he-purple);
    font-family: Georgia, serif;
    font-size: 22px;
    margin: 0 0 13px;
}

.he-type-content p {
    font-size: 13px;
    line-height: 1.9;
    margin: 0;
}

/* PROCESS */

.he-process {
    background: var(--he-cream);
}

.he-process-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-top: 45px;
}

.he-process-card {
    background: white;
    padding: 30px 22px;
    border-bottom: 3px solid var(--he-gold);
}

.he-step {
    font-family: Georgia, serif;
    font-size: 42px;
    color: #e6d8c1;
    margin-bottom: 15px;
}

.he-process-card h3 {
    color: var(--he-purple);
    font-family: Georgia, serif;
    font-size: 19px;
    margin: 0 0 13px;
}

.he-process-card p {
    font-size: 13px;
    line-height: 1.9;
    margin: 0;
}

/* BANNER */

.he-banner {
    padding: 110px 20px;
    text-align: center;
    background:
        linear-gradient(rgba(39,19,53,.87), rgba(39,19,53,.87)),
        url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1800&q=85');
    background-position: center;
    background-size: cover;
}

.he-banner h2 {
    max-width: 820px;
    margin: 0 auto 20px;
    font-family: Georgia, serif;
    font-size: clamp(30px, 4vw, 46px);
    color: white;
    line-height: 1.3;
}

.he-banner p {
    color: #e7dce9;
    font-size: 14px;
    line-height: 1.9;
    max-width: 680px;
    margin: 0 auto 30px;
}

/* FAQ */

.he-faq {
    background: var(--he-cream);
}

.he-faq-wrap {
    max-width: 850px;
    margin: 40px auto 0;
}

.he-faq-item {
    background: white;
    border: 1px solid #eee5ed;
    margin-bottom: 13px;
    border-radius: 4px;
    overflow: hidden;
}

.he-faq-question {
    width: 100%;
    border: 0;
    background: white;
    padding: 20px 22px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    color: var(--he-purple);
    font-family: Georgia, serif;
    font-size: 17px;
    text-align: left;
    cursor: pointer;
}

.he-faq-question span {
    color: var(--he-gold);
    font-size: 23px;
    transition: .3s;
}

.he-faq-answer {
    display: none;
    padding: 0 22px 20px;
    color: var(--he-text);
    font-size: 13px;
    line-height: 1.9;
}

.he-faq-item.active .he-faq-answer {
    display: block;
}

.he-faq-item.active .he-faq-question span {
    transform: rotate(45deg);
}

/* FINAL CTA */

.he-final {
    background: var(--he-purple);
    padding: 85px 20px;
    text-align: center;
}

.he-final h2 {
    color: white;
    font-family: Georgia, serif;
    font-size: clamp(30px, 4vw, 45px);
    margin: 0 0 20px;
}

.he-final p {
    max-width: 680px;
    color: #e5d9e9;
    font-size: 14px;
    line-height: 1.9;
    margin: 0 auto 30px;
}

@keyframes heFade {
    from {
        opacity: 0;
        transform: translateY(25px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* RESPONSIVE */

@media(max-width: 950px) {
    .he-process-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .he-why-grid,
    .he-types-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width: 650px) {
    .he-section {
        padding: 60px 0;
    }

    .he-hero {
        min-height: 560px;
        background-position: 60% center;
    }

    .he-hero h1 {
        font-size: 43px;
    }

    .he-hero-content {
        padding: 75px 0;
    }

    .he-intro-grid,
    .he-consider-grid {
        grid-template-columns: 1fr;
        gap: 35px;
    }

    .he-image-wrap img,
    .he-consider-image img {
        height: 340px;
    }

    .he-image-wrap:after {
        right: -8px;
        bottom: -8px;
    }

    .he-why-grid,
    .he-types-grid,
    .he-process-grid {
        grid-template-columns: 1fr;
    }

    .he-highlights {
        grid-template-columns: 1fr;
    }

    .he-banner {
        padding: 75px 20px;
    }

    .he-final {
        padding: 65px 20px;
    }
}
</style>


<main class="home-energy">

    <!-- HERO SECTION -->

    <section class="he-hero">

        <div class="he-container">

            <div class="he-hero-content">

                <div class="he-subtitle">
                    Divine Healing World
                </div>

                <h1>
                    Home Energy <span>Healing</span>
                    & Space Clearing
                </h1>

                <p>
                    Your home is more than just a place to live.
                    It is your personal sanctuary. Explore a
                    mindful space-clearing experience designed
                    to invite peace, balance and positive intentions
                    into your living environment.
                </p>

                <a href="contact.php" class="he-btn">
                    BOOK A SESSION &nbsp; →
                </a>

            </div>

        </div>

    </section>


    <!-- INTRODUCTION -->

    <section class="he-section he-intro">

        <div class="he-container">

            <div class="he-intro-grid">

                <div class="he-image-wrap">

                    <img
                        src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1000&q=85"
                        alt="Peaceful and beautiful home interior"
                        loading="lazy"
                    >

                </div>


                <div class="he-intro-content">

                    <div class="he-subtitle">
                        Restore Your Space
                    </div>

                    <h2 class="he-heading">
                        Create a Home That Feels Peaceful,
                        Balanced and Welcoming
                    </h2>

                    <p class="he-description">
                        Our homes are connected to the memories,
                        emotions and experiences of everyday life.
                        Sometimes, you may simply wish to refresh
                        the atmosphere of your space and create
                        a feeling of a fresh beginning.

                        <br><br>

                        Home Energy Healing & Space Clearing at
                        Divine Healing World is a spiritual and
                        intuitive practice focused on intention,
                        reflection and energetic renewal.

                        <br><br>

                        Whether you are moving into a new property
                        or refreshing your existing space, the
                        experience is designed to help you reconnect
                        with your home in a more mindful way.
                    </p>

                    <div class="he-highlights">

                        <div class="he-highlight">
                            <span>✧</span>
                            Energy Clearing
                        </div>

                        <div class="he-highlight">
                            <span>♡</span>
                            Peaceful Environment
                        </div>

                        <div class="he-highlight">
                            <span>☽</span>
                            Fresh Beginning
                        </div>

                        <div class="he-highlight">
                            <span>❀</span>
                            Positive Intention
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>


    <!-- WHY SPACE CLEARING -->

    <section class="he-section he-why">

        <div class="he-container">

            <div class="he-center-heading">

                <div class="he-subtitle">
                    Why Consider Space Clearing?
                </div>

                <h2 class="he-heading">
                    Give Your Space a Fresh Start
                </h2>

                <p class="he-description">
                    Every home has its own story. A space-clearing
                    session offers an opportunity to consciously
                    refresh your environment and set new intentions.
                </p>

            </div>


            <div class="he-why-grid">

                <div class="he-why-card">

                    <div class="he-icon">✧</div>

                    <h3>Release Stagnant Energy</h3>

                    <p>
                        Explore a symbolic and intentional way
                        of refreshing areas that feel heavy,
                        unsettled or stagnant.
                    </p>

                </div>


                <div class="he-why-card">

                    <div class="he-icon">♡</div>

                    <h3>Invite Peace & Harmony</h3>

                    <p>
                        Set intentions for a calmer, more
                        welcoming atmosphere throughout
                        your living space.
                    </p>

                </div>


                <div class="he-why-card">

                    <div class="he-icon">☼</div>

                    <h3>Fresh New Beginnings</h3>

                    <p>
                        Mark a new chapter when moving into
                        a home, renovating or beginning
                        a different phase of life.
                    </p>

                </div>


                <div class="he-why-card">

                    <div class="he-icon">❀</div>

                    <h3>Emotional Renewal</h3>

                    <p>
                        Create a meaningful opportunity to
                        reflect on the memories and experiences
                        connected with your space.
                    </p>

                </div>


                <div class="he-why-card">

                    <div class="he-icon">☽</div>

                    <h3>Mindful Living</h3>

                    <p>
                        Reconnect with your environment
                        through intention, awareness and
                        spiritual reflection.
                    </p>

                </div>


                <div class="he-why-card">

                    <div class="he-icon">⌂</div>

                    <h3>Balanced Surroundings</h3>

                    <p>
                        Focus on creating a living space
                        that reflects your desired feeling
                        of comfort and belonging.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <!-- WHEN TO CONSIDER -->

    <section class="he-section he-consider">

        <div class="he-container">

            <div class="he-consider-grid">

                <div>

                    <div class="he-subtitle">
                        Is It Time for a Space Refresh?
                    </div>

                    <h2 class="he-heading">
                        When Should You Consider Home Energy Healing?
                    </h2>

                    <p class="he-description">
                        There are many moments in life when you
                        may want to give your surroundings a
                        thoughtful reset.
                    </p>

                    <ul class="he-check-list">

                        <li>
                            When moving into a new home or apartment.
                        </li>

                        <li>
                            After renovation or major changes in your space.
                        </li>

                        <li>
                            When you want to refresh the atmosphere
                            after a difficult period.
                        </li>

                        <li>
                            When your home feels emotionally unsettled
                            or disconnected.
                        </li>

                        <li>
                            After major family or lifestyle transitions.
                        </li>

                        <li>
                            When you simply want to welcome a fresh
                            beginning into your home.
                        </li>

                    </ul>

                    <a href="contact.php" class="he-btn">
                        EXPLORE YOUR SESSION &nbsp; →
                    </a>

                </div>


                <div class="he-consider-image">

                    <img
                        src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1000&q=85"
                        alt="Elegant and peaceful home"
                        loading="lazy"
                    >

                </div>

            </div>

        </div>

    </section>


    <!-- TYPES OF SPACE CLEARING -->

    <section class="he-section he-types">

        <div class="he-container">

            <div class="he-center-heading">

                <div class="he-subtitle">
                    Our Space Clearing Services
                </div>

                <h2 class="he-heading">
                    Healing for Different Spaces
                </h2>

                <p class="he-description">
                    Every space has a different purpose and story.
                    Explore the type of space-clearing experience
                    that matches your intention.
                </p>

            </div>


            <div class="he-types-grid">

                <div class="he-type-card">

                    <img
                        src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=800&q=85"
                        alt="Home energy clearing"
                        loading="lazy"
                    >

                    <div class="he-type-content">

                        <h3>Home Energy Clearing</h3>

                        <p>
                            A mindful space-clearing experience
                            for your house or apartment, focused
                            on refreshing your living environment
                            and welcoming a peaceful atmosphere.
                        </p>

                    </div>

                </div>


                <div class="he-type-card">

                    <img
                        src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=800&q=85"
                        alt="Office space clearing"
                        loading="lazy"
                    >

                    <div class="he-type-content">

                        <h3>Office & Workspace Clearing</h3>

                        <p>
                            Set fresh intentions for your office,
                            studio or workspace and create an
                            environment that feels welcoming
                            and supportive.
                        </p>

                    </div>

                </div>


                <div class="he-type-card">

                    <img
                        src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=800&q=85"
                        alt="New property energy clearing"
                        loading="lazy"
                    >

                    <div class="he-type-content">

                        <h3>New Property Clearing</h3>

                        <p>
                            Welcome a new chapter into your
                            property with a thoughtful clearing
                            experience before moving in or
                            beginning a new journey.
                        </p>

                    </div>

                </div>

            </div>

        </div>

    </section>


    <!-- HOW IT WORKS -->

    <section class="he-section he-process">

        <div class="he-container">

            <div class="he-center-heading">

                <div class="he-subtitle">
                    The Experience
                </div>

                <h2 class="he-heading">
                    How Does the Space Clearing Session Work?
                </h2>

                <p class="he-description">
                    A simple, personalised process focused
                    on your space and your intentions.
                </p>

            </div>


            <div class="he-process-grid">

                <div class="he-process-card">

                    <div class="he-step">01</div>

                    <h3>Initial Consultation</h3>

                    <p>
                        Share details about your property,
                        your concerns and what you would
                        like to experience.
                    </p>

                </div>


                <div class="he-process-card">

                    <div class="he-step">02</div>

                    <h3>Space Assessment</h3>

                    <p>
                        Discuss the areas of your home or
                        workspace that you would like to
                        focus on during the session.
                    </p>

                </div>


                <div class="he-process-card">

                    <div class="he-step">03</div>

                    <h3>Energy Clearing</h3>

                    <p>
                        An intuitive spiritual clearing
                        process using intention and
                        appropriate clearing practices.
                    </p>

                </div>


                <div class="he-process-card">

                    <div class="he-step">04</div>

                    <h3>Closing & Guidance</h3>

                    <p>
                        Receive a session summary and
                        simple suggestions for maintaining
                        a mindful living environment.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <!-- QUOTE BANNER -->

    <section class="he-banner">

        <div class="he-container">

            <div class="he-subtitle">
                Divine Healing World
            </div>

            <h2>
                Your Home Is Your Sanctuary.
                Let It Reflect Peace, Love & Harmony.
            </h2>

            <p>
                Create space for new beginnings and bring
                mindful intention into the environment
                where your everyday life unfolds.
            </p>

            <a href="contact.php" class="he-btn">
                BOOK A SPACE CLEARING SESSION &nbsp; →
            </a>

        </div>

    </section>


    <!-- FAQ -->

    <section class="he-section he-faq">

        <div class="he-container">

            <div class="he-center-heading">

                <div class="he-subtitle">
                    Frequently Asked Questions
                </div>

                <h2 class="he-heading">
                    Everything You Need to Know
                </h2>

            </div>


            <div class="he-faq-wrap">


                <div class="he-faq-item active">

                    <button class="he-faq-question">
                        What is Home Energy Healing?
                        <span>+</span>
                    </button>

                    <div class="he-faq-answer">
                        Home Energy Healing is a spiritual and
                        intuitive space-clearing practice that
                        focuses on intention, reflection and
                        creating a renewed sense of harmony
                        within your living environment.
                    </div>

                </div>


                <div class="he-faq-item">

                    <button class="he-faq-question">
                        When should I book a home energy clearing?
                        <span>+</span>
                    </button>

                    <div class="he-faq-answer">
                        You may consider a session when moving
                        into a new property, after renovations,
                        during life transitions or whenever
                        you wish to refresh the atmosphere
                        of your space.
                    </div>

                </div>


                <div class="he-faq-item">

                    <button class="he-faq-question">
                        Can space clearing be done remotely?
                        <span>+</span>
                    </button>

                    <div class="he-faq-answer">
                        Remote sessions may be available depending
                        on the service arrangement. Contact Divine
                        Healing World to discuss the process and
                        requirements for your property.
                    </div>

                </div>


                <div class="he-faq-item">

                    <button class="he-faq-question">
                        What details are required before booking?
                        <span>+</span>
                    </button>

                    <div class="he-faq-answer">
                        You may be asked to share your property
                        details, photographs, relevant videos
                        and a brief description of your intentions
                        or concerns.
                    </div>

                </div>


                <div class="he-faq-item">

                    <button class="he-faq-question">
                        Is Home Energy Healing a substitute for
                        professional home services?
                        <span>+</span>
                    </button>

                    <div class="he-faq-answer">
                        No. This is a complementary spiritual
                        practice. It does not replace qualified
                        services for electrical, structural,
                        environmental, medical or psychological
                        concerns.
                    </div>

                </div>


                <div class="he-faq-item">

                    <button class="he-faq-question">
                        How can I book a session?
                        <span>+</span>
                    </button>

                    <div class="he-faq-answer">
                        Contact Divine Healing World through
                        the enquiry page to discuss your
                        requirements and available sessions.
                    </div>

                </div>


            </div>

        </div>

    </section>


    <!-- FINAL CTA -->

    <section class="he-final">

        <div class="he-container">

            <div class="he-subtitle">
                Begin Your Fresh Start
            </div>

            <h2>
                Invite Peace & Positive Intentions Into Your Space
            </h2>

            <p>
                Let your home become a reflection of the calm,
                comfort and harmony you wish to experience.
                Connect with Divine Healing World to explore
                your personalised space-clearing session.
            </p>

            <a href="contact.php" class="he-btn">
                BOOK YOUR SESSION &nbsp; →
            </a>

        </div>

    </section>

</main>


<script>
// FAQ Accordion

document.querySelectorAll('.he-faq-question').forEach(function(button) {

    button.addEventListener('click', function() {

        const currentItem = this.parentElement;

        document.querySelectorAll('.he-faq-item').forEach(function(item) {

            if (item !== currentItem) {
                item.classList.remove('active');
            }

        });

        currentItem.classList.toggle('active');

    });

});
</script>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Divinehealingworld - Customer Reviews</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

html{
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background:#fff;
    color:#29202f;
    overflow-x:hidden;
}

button,
input{
    font-family:inherit;
}

.container{
    width:92%;
    max-width:1180px;
    margin:auto;
}

/* =========================
   BENEFITS
========================= */

.benefits-section{
    padding:16px 0 10px;
}

.benefits-box{
    width:92%;
    max-width:1200px;
    margin:auto;

    background:linear-gradient(
        120deg,
        #faf7f5,
        #fff,
        #faf7f5
    );

    border-radius:10px;

    box-shadow:
        0 5px 25px rgba(45,20,55,.04);

    display:grid;
    grid-template-columns:repeat(4,1fr);

    overflow:hidden;

    animation:fadeDown .8s ease;
}

.benefit{
    min-height:74px;

    display:flex;
    align-items:center;
    gap:13px;

    padding:10px 25px;

    border-right:1px solid #d9d2d8;

    transition:.35s ease;
}

.benefit:last-child{
    border-right:none;
}

.benefit:hover{
    background:#fff;
    transform:translateY(-2px);
}

.benefit-icon{
    width:40px;
    height:40px;

    border:1.5px solid #392443;
    border-radius:50%;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:18px;

    flex-shrink:0;

    transition:.4s ease;
}

.benefit:hover .benefit-icon{
    transform:rotate(360deg);
    background:#3b2546;
    color:#fff;
}

.benefit h4{
    font-size:11px;
    font-weight:600;
    margin-bottom:1px;
}

.benefit p{
    font-size:8px;
    color:#777;
}

/* =========================
   TESTIMONIAL
========================= */

.testimonial-section{
    padding:18px 0 18px;
}

.section-title{
    text-align:center;
    margin-bottom:15px;

    animation:fadeUp .8s ease;
}

.section-title h2{
    font-family:'DM Serif Display',serif;
    font-size:28px;
    font-weight:400;
    color:#33203e;
}

.section-title p{
    font-size:18px;
    color:#777;
    margin-top:1px;
}

/* =========================
   REVIEWS
========================= */

.reviews{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:14px;
}

.review-card{
    border:1px solid #e2dfe2;
    border-radius:5px;

    padding:11px 15px;

    min-height:108px;

    background:#fff;

    transition:
        transform .35s ease,
        box-shadow .35s ease,
        border-color .35s ease;

    opacity:0;
    transform:translateY(30px);
}

.review-card.show{
    opacity:1;
    transform:translateY(0);
}

.review-card:hover{
    transform:translateY(-6px);
    border-color:#c9b6d0;

    box-shadow:
        0 12px 30px rgba(54,30,65,.10);
}

.review-top{
    display:flex;
    align-items:center;
    gap:10px;
}

.avatar{
    width:42px;
    height:42px;

    border-radius:50%;
    overflow:hidden;

    flex-shrink:0;

    background:linear-gradient(
        135deg,
        #eee,
        #ddd
    );
}

.avatar img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.stars{
    color:#e4a719;
    font-size:18px;
    letter-spacing:1px;
    margin-bottom:3px;
}

.review-text{
    font-size:12px;
    color:#4d4d4d;
    line-height:1.55;

    margin-top:8px;
}

.customer{
    margin-top:7px;
    font-size:12px;
    font-weight:600;
}

.customer-location{
    font-size:10px;
    color:#777;
    margin-top:1px;
}

/* =========================
   COMMUNITY
========================= */

.community{
    position:relative;

    background:
        linear-gradient(
            135deg,
            #684c72,
            #795a83,
            #67476e
        );

    min-height:98px;

    overflow:hidden;

    color:#fff;

    display:flex;
    justify-content:center;
    align-items:center;

    text-align:center;

    margin-top:0;
}

.community-content{
    position:relative;
    z-index:2;
}

.community h2{
    font-family:'DM Serif Display',serif;
    font-weight:400;
    font-size:25px;
}

.community p{
    font-size:15px;
    opacity:.85;
    margin:2px 0 8px;
}

.subscribe{
    display:flex;
    width:450px;
    height:40px;
    margin:auto;

    background:#fff;
    border-radius:20px;

    overflow:hidden;

    box-shadow:
        0 4px 15px rgba(0,0,0,.12);

    transition:.3s;
}

.subscribe:focus-within{
    transform:scale(1.03);
}

.subscribe input{
    flex:1;
    min-width:0;

    border:none;
    outline:none;

    padding:0 12px;

    font-size:15px;
    color:#444;
}

.subscribe button{
    border:none;

    width:100px;

    background:#28192f;
    color:#fff;

    font-size:15px;

    cursor:pointer;

    transition:.3s;
}

.subscribe button:hover{
    background:#170e1b;
}

/* Floating crystals */

.crystal{
    position:absolute;
    width:45px;
    height:45px;

    opacity:.25;

    border:1px solid #fff;

    transform:rotate(35deg);

    animation:floatCrystal 4s ease-in-out infinite;
}

.crystal::before{
    content:"";
    position:absolute;
    inset:8px;

    border:1px solid #fff;

    transform:rotate(45deg);
}

.crystal.one{
    left:15%;
    top:16px;
}

.crystal.two{
    right:15%;
    top:20px;
    width:35px;
    height:35px;

    animation-delay:1s;
}

.crystal.three{
    right:11%;
    top:43px;
    width:20px;
    height:20px;

    animation-delay:2s;
}

/* =========================
   FOOTER
========================= */

footer{
    background:
        linear-gradient(
            135deg,
            #20142a,
            #2b1936,
            #1d1325
        );

    color:#fff;

    padding:12px 0 8px;
}

.footer-container{
    width:100%;
    max-width:1200px;
    margin:auto;

    display:grid;

    grid-template-columns:
        1.7fr
        1fr
        1fr
        1.15fr;

    gap:30px;
}

/* Logo */

.footer-logo{
    display:flex;
    align-items:center;
    gap:7px;
}

.logo-icon{
    font-size:30px;
    line-height:1;
}

.footer-logo h2{
    font-family:'DM Serif Display',serif;
    font-size:23px;
    font-weight:400;
}

.footer-logo span{
    display:block;
    font-size:12px;
    color:#ddd;
    letter-spacing:.5px;
}

.footer-about p{
    font-size:10px;
    line-height:1.7;

    color:#d4ccd8;

    max-width:280px;

    margin-top:8px;
}

/* Social */

.socials{
    display:flex;
    gap:13px;
    margin-top:9px;
}

.socials a{
    color:#fff;
    text-decoration:none;

    font-size:20px;

    width:18px;
    height:18px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    transition:.3s;
}

.socials a:hover{
    background:#fff;
    color:#28182f;
    transform:translateY(-3px);
}

/* Footer columns */

.footer-column h3{
    font-size:15px;
    font-weight:500;

    margin-bottom:8px;
}

.footer-column ul{
    list-style:none;
}

.footer-column li{
    margin-bottom:5px;
}

.footer-column a{
    color:#d2cbd6;
    text-decoration:none;

    font-size:15px;

    transition:.3s;
}

.footer-column a:hover{
    color:#fff;
    padding-left:4px;
}

/* Contact */

.contact-item{
    display:flex;
    align-items:center;
    gap:8px;

    color:#d2cbd6;

    font-size:15px;

    margin-bottom:7px;
}

.contact-icon{
    width:15px;
    text-align:center;
    font-size:18px;
}

/* =========================
   COPYRIGHT
========================= */

.footer-bottom{
    width:92%;
    max-width:1180px;

    margin:8px auto 0;

    padding-top:7px;

    border-top:1px solid rgba(255,255,255,.14);

    display:flex;
    align-items:center;
    justify-content:space-between;

    font-size:12px;

    color:#bbb;
}

.footer-links{
    display:flex;
    gap:12px;
}

.footer-links a{
    color:#bbb;
    text-decoration:none;
    transition:.3s;
}

.footer-links a:hover{
    color:#fff;
}

/* =========================
   ANIMATIONS
========================= */

@keyframes fadeDown{
    from{
        opacity:0;
        transform:translateY(-25px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(20px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes floatCrystal{

    0%,100%{
        transform:
            rotate(35deg)
            translateY(0);
    }

    50%{
        transform:
            rotate(50deg)
            translateY(-8px);
    }
}

/* =========================
   TABLET
========================= */

@media(max-width:850px){

    .benefits-box{
        grid-template-columns:repeat(2,1fr);
    }

    .benefit:nth-child(2){
        border-right:none;
    }

    .benefit:nth-child(1),
    .benefit:nth-child(2){
        border-bottom:1px solid #ddd;
    }

    .reviews{
        grid-template-columns:1fr;
        max-width:600px;
        margin:auto;
    }

    .review-card{
        min-height:auto;
    }

    .footer-container{
        grid-template-columns:1fr 1fr;
    }

}

/* =========================
   MOBILE
========================= */

@media(max-width:600px){

    .benefits-section{
        padding-top:10px;
    }

    .benefits-box{
        width:94%;
        grid-template-columns:1fr 1fr;
    }

    .benefit{
        padding:10px;
        gap:8px;
    }

    .benefit-icon{
        width:34px;
        height:34px;
        font-size:14px;
    }

    .benefit h4{
        font-size:9px;
    }

    .benefit p{
        font-size:6.5px;
    }

    .section-title h2{
        font-size:21px;
    }

    .section-title p{
        font-size:8px;
    }

    .reviews{
        width:94%;
    }

    .community{
        min-height:105px;
    }

    .community h2{
        font-size:18px;
    }

    .subscribe{
        width:230px;
    }

    .crystal.one{
        left:4%;
    }

    .crystal.two{
        right:5%;
    }

    .crystal.three{
        right:2%;
    }

    footer{
        padding-top:25px;
    }

    .footer-container{
        width:88%;
        grid-template-columns:1fr 1fr;
        gap:25px 15px;
    }

    .footer-about{
        grid-column:1 / -1;
    }

    .footer-about p{
        max-width:100%;
    }

    .footer-bottom{
        width:88%;

        flex-direction:column;
        align-items:flex-start;

        gap:8px;
    }

    .footer-links{
        gap:8px;
        flex-wrap:wrap;
    }

}

/* =========================
   SMALL MOBILE
========================= */

@media(max-width:380px){

    .benefits-box{
        grid-template-columns:1fr;
    }

    .benefit{
        border-right:none !important;
        border-bottom:1px solid #ddd;
    }

    .benefit:last-child{
        border-bottom:none;
    }

    .footer-container{
        grid-template-columns:1fr;
    }

    .footer-about{
        grid-column:auto;
    }

    .footer-bottom{
        font-size:6px;
    }

}

</style>
</head>

<body>

<!-- =====================================
     COMMUNITY
===================================== -->

<section class="community">


    <div class="crystal one"></div>
    <div class="crystal two"></div>
    <div class="crystal three"></div>


    <div class="community-content">
        <br>
        <br>

        <h2>
            Join Our Crystal Community
        </h2>

        <p>
            Get exclusive offers, new arrivals and crystal tips straight to your inbox.
        </p>

<br>
        <form
            class="subscribe"
            id="subscribeForm"
        >

            <input
                type="email"
                id="email"
                placeholder="Enter your email address"
                required
            >

            <button type="submit">
                Subscribe
            </button>

        </form>
<br>
<br>
<br>
    </div>

</section>


<!-- =====================================
     FOOTER
===================================== -->

<footer>

    <div class="footer-container">


        <!-- ABOUT -->

        <div class="footer-about">

            <div class="footer-logo">

                <div class="logo-icon">
                    ♢
                </div>

                <div>

                    <h2>
                        Divinehealingworld
                    </h2>

                    <span>
                        Nature's Energy. Your Style
                    </span>

                </div>

            </div>


            <p>
                At Divinehealingworld, we bring you fine natural
                crystals and handcrafted jewellery to help you
                connect with your inner peace and positive energy.
            </p>


            <div class="socials">

                <a href="#" aria-label="Facebook">
                    f
                </a>

                <a href="#" aria-label="Instagram">
                    ◎
                </a>

                <a href="#" aria-label="Pinterest">
                    p
                </a>

                <a href="#" aria-label="Youtube">
                    ▶
                </a>

            </div>

        </div>


        <!-- QUICK LINKS -->

        <div class="footer-column">

            <h3>
                Quick Links
            </h3>

            <ul>

                <li>
                    <a href="#">Home</a>
                </li>
                <li>
                    <a href="#">About Us</a>
                </li>

                <li>
                    <a href="blog.php">Blog</a>
                </li>

                <li>
                    <a href="contact.php">Contact</a>
                </li>

            </ul>

        </div>


        <!-- SHOP -->

        <div class="footer-column">

            <h3>
               Our Services
            </h3>

            <ul>

                <li>
                    <a href="reiki-healing.php">Reiki Healing</a>
                </li>

                <li>
                    <a href="akashic-records.php">Akashic Records</a>
                </li>

                <li>
                    <a href="animal-communication.php">Animal Communication</a>
                </li>

                <li>
                    <a href="tarot-reading.php">Tarot Reading</a>
                </li>

                <li>
                    <a href="home-energy.php">Home Energy</a>
                </li>

                <li>
                    <a href="psychic-mediumShip.php<">Psychic MediumShip</a>
                </li>

            </ul>

        </div>


        <!-- CONTACT -->

        <div class="footer-column">

            <h3>
                Contact Us
            </h3>


            <div class="contact-item">

                <div class="contact-icon">
                    ✉
                </div>

                support@Divinehealingworld.com

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ☎
                </div>

                +91 9711766949

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ●
                </div>

                India

            </div>

        </div>


    </div>


    <!-- COPYRIGHT -->

    <div class="footer-bottom">

        <div>
            © 2026 Divinehealingworld. All rights reserved.
        </div>
          <div>
    Developed By
    <a
        href="https://www.google.com/search?q=parvez3737"
        target="_blank"
        rel="noopener noreferrer"
        style="text-decoration: none; color: inherit;"
    >
        Parvez Ahmad (Parvez3737)
    </a>
</div>

        <div class="footer-links">

            <a href="#">
                Privacy Policy
            </a>

            <span>|</span>

            <a href="#">
                Terms & Conditions
            </a>

            <span>|</span>

            <a href="#">
                Shipping Policy
            </a>

        </div>

    </div>

</footer>


<!-- =====================================
     JAVASCRIPT
===================================== -->

<script>

/* =====================================
   SCROLL REVEAL
===================================== */

const cards = document.querySelectorAll(".review-card");

const observer = new IntersectionObserver(
    (entries) => {

        entries.forEach((entry, index) => {

            if(entry.isIntersecting){

                setTimeout(() => {

                    entry.target.classList.add("show");

                }, index * 180);

                observer.unobserve(entry.target);

            }

        });

    },
    {
        threshold:0.15
    }
);


cards.forEach(card => {

    observer.observe(card);

});


/* =====================================
   NEWSLETTER
===================================== */

const form = document.getElementById("subscribeForm");

form.addEventListener("submit", function(e){

    e.preventDefault();

    const email =
        document.getElementById("email").value.trim();

    if(!email){
        return;
    }

    const button =
        form.querySelector("button");

    const oldText =
        button.textContent;

    button.textContent = "Subscribed ✓";

    button.style.background = "#493052";

    setTimeout(() => {

        button.textContent = oldText;

        button.style.background = "";

        form.reset();

    }, 2500);

});


/* =====================================
   MOUSE PARALLAX CRYSTALS
===================================== */

const crystals =
    document.querySelectorAll(".crystal");

document.addEventListener("mousemove", function(e){

    const x =
        (window.innerWidth / 2 - e.clientX) / 60;

    const y =
        (window.innerHeight / 2 - e.clientY) / 60;

    crystals.forEach((crystal, index) => {

        const amount =
            (index + 1) * 0.6;

        crystal.style.marginLeft =
            `${x * amount}px`;

        crystal.style.marginTop =
            `${y * amount}px`;

    });

});


/* =====================================
   REVIEW CARD HOVER
===================================== */

cards.forEach(card => {

    card.addEventListener("mouseenter", () => {

        card.style.zIndex = "5";

    });

    card.addEventListener("mouseleave", () => {

        card.style.zIndex = "";

    });

});

</script>

</body>
</html>