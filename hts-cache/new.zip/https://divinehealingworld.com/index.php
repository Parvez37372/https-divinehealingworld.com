<style>
	.hero-garley-gap {
    height: 40px;
    width: 100%;
}
.hero-garley-gap2 {
    height: 28px;
    width: 100%;
}


</style>

<!---<div class="hero-garley-gap"></div>--->

<!--<div class="hero-garley-gap2"></div>

<div class="hero-garley-gap2"></div>


<div class="hero-garley-gap2"></div>

<div class="hero-garley-gap2"></div>
<div class="hero-garley-gap2"></div>

<!----new-home---->

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Divinehealingworld
    </title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Playfair+Display:wght@500;600&display=swap"
        rel="stylesheet"
    >

    <style>

        :root {
            --purple: #382342;
            --dark-purple: #24142e;
            --pink: #b61491;
            --text: #302632;
            --muted: #817782;
            --border: #ebe7ec;
            --light: #faf8fb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "DM Sans", sans-serif;
            color: var(--text);
            background: #fff;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            font-family: inherit;
        }


        /* =========================
           TOP BAR
        ========================= */

        .top-bar {
            height: 29px;
            background: var(--pink);
            color: #fff;
            padding: 0 5.5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 10px;
        }

        .top-bar-item {
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .top-bar-item i {
            font-size: 11px;
        }


        /* =========================
           HEADER
        ========================= */

        .header {
            height: 78px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            position: relative;
            z-index: 1000;
        }

        .header-container {
            width: 89%;
            max-width: 1440px;
            height: 100%;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }


        /* LOGO */

        .logo {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 235px;
        }

        .logo-symbol {
            width: 43px;
            height: 43px;
            position: relative;
        }

        .logo-symbol img {
            width: 50px;
            height: -10px;
            object-fit: contain;
        }

        .logo-content h1 {
            font-family: "Playfair Display", serif;
            font-size: 25px;
            font-weight: 600;
            line-height: 1;
            color: var(--purple);
            letter-spacing: -0.5px;
        }

        .logo-content p {
            font-size: 10px;
            color: #77707b;
            margin-top: 4px;
            letter-spacing: .35px;
        }


        /* NAVIGATION */

        .navigation {
            height: 100%;
            display: flex;
            align-items: center;
            gap: 34px;
        }

        .nav-link {
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
            font-size: 12px;
            color: #302932;
            transition: color .25s ease;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 19px;
            width: 0;
            height: 2px;
            background: var(--purple);
            transition: width .3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            color: var(--purple);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .shop-link {
            gap: 6px;
        }

        .shop-link i {
            font-size: 8px;
        }


        /* SHOP DROPDOWN */

        .shop-dropdown {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
        }

        .shop-menu {
            display: none;
            list-style: none;
            padding: 8px 0;
            margin: 0;
            position: absolute;
            top: 100%;
            left: 0;
            min-width: 230px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 10px 28px rgba(36,20,46,.12);
            z-index: 9999;
        }

        .shop-dropdown:hover .shop-menu {
            display: block;
        }

        .shop-dropdown:hover .shop-link i {
            transform: rotate(180deg);
        }

        .shop-link i {
            transition: .25s ease;
        }

        .shop-menu li a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 11px 15px;
            color: #333;
            font-size: 13px;
            transition: .2s ease;
        }

        .shop-menu li a:hover {
            background: #faf5fb;
            color: var(--pink);
        }

        .shop-menu li a i {
            width: 17px;
            color: var(--purple);
            font-size: 12px;
        }


        /* HEADER ACTIONS */

        .header-actions {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .header-icon {
            border: 0;
            background: transparent;
            color: #302632;
            font-size: 17px;
            width: 20px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
        }

        .header-icon:hover {
            color: var(--purple);
        }

        .badge-icon span {
            position: absolute;
            top: -5px;
            right: -8px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--purple);
            color: #fff;
            font-size: 8px;
            font-weight: 600;
        }


        /* MOBILE */

        .mobile-menu-button {
            display: none;
            border: 0;
            background: transparent;
            font-size: 19px;
            color: var(--purple);
            cursor: pointer;
        }

        .mobile-navigation {
            display: none;
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 10px 5%;
            position: relative;
            z-index: 999;
            box-shadow: 0 8px 20px rgba(0,0,0,.06);
        }

        .mobile-navigation.show {
            display: block;
        }

        .mobile-navigation a {
            display: block;
            padding: 13px 5px;
            border-bottom: 1px solid #f0edf1;
            font-size: 13px;
        }

        .mobile-shop {
            border-bottom: 1px solid #f0edf1;
        }

        .mobile-shop-toggle {
            width: 100%;
            padding: 13px 5px;
            border: 0;
            background: transparent;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-family: inherit;
            font-size: 13px;
            color: #302932;
            cursor: pointer;
        }

        .mobile-shop-toggle i {
            font-size: 10px;
            transition: transform .25s ease;
        }

        .mobile-shop.open .mobile-shop-toggle i {
            transform: rotate(180deg);
        }

        .mobile-shop-menu {
            display: none;
            padding: 0 0 5px 14px;
        }

        .mobile-shop.open .mobile-shop-menu {
            display: block;
        }

        .mobile-shop-menu a {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 10px 5px;
            border-bottom: 0;
            font-size: 12px;
            color: #625a63;
        }

        .mobile-shop-menu i {
            width: 14px;
            font-size: 11px;
        }


        /* =========================
           SHOP PRODUCTS PAGE
        ========================= */


        .shop-heading {
            text-align: center;
            margin-bottom: 35px;
        }

        .shop-heading h2 {
            font-family: "Playfair Display", serif;
            font-size: 34px;
            color: var(--purple);
            margin-bottom: 8px;
        }

        .shop-heading p {
            color: var(--muted);
            font-size: 13px;
        }


        /* PRODUCT CARD */

        .products-list {
            display: grid;
            grid-template-columns: 1fr;
            gap: 18px;
        }

        .product-card {
            display: grid;
            grid-template-columns: 230px 1fr;
            gap: 25px;
            padding: 18px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            box-shadow: 0 7px 24px rgba(36,20,46,.05);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(36,20,46,.09);
        }

        .product-image-wrap {
            width: 230px;
            height: 230px;
            border-radius: 12px;
            overflow: hidden;
            background: #faf8fb;
        }

        .product-image-wrap img {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
        }

        .product-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 5px 10px 5px 0;
        }

        .product-title {
            color: var(--pink);
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 7px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .product-name {
            font-family: "Playfair Display", serif;
            color: var(--purple);
            font-size: 27px;
            font-weight: 600;
            margin-bottom: 11px;
        }

        .product-description {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.7;
            max-width: 700px;
            margin-bottom: 18px;
        }

        .product-bottom {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .product-price {
            color: var(--purple);
            font-size: 21px;
            font-weight: 700;
        }

        .add-cart-btn {
            border: 0;
            border-radius: 8px;
            padding: 11px 19px;
            background: var(--purple);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: .25s ease;
        }

        .add-cart-btn:hover {
            background: var(--pink);
        }

        .empty-products {
            text-align: center;
            padding: 55px 20px;
            border: 1px dashed #ddd5df;
            border-radius: 14px;
            color: var(--muted);
        }

        .empty-products i {
            font-size: 35px;
            color: #c7bdc9;
            margin-bottom: 12px;
        }

        .all-categories {
            display: flex;
            justify-content: center;
            gap: 9px;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .category-pill {
            padding: 8px 14px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 11px;
            color: var(--purple);
            background: #fff;
        }

        .category-pill:hover {
            background: #faf5fb;
            border-color: #d9c9dc;
        }


        /* RESPONSIVE */

        @media (max-width: 1000px) {

            .header-container {
                width: 92%;
            }

            .navigation {
                gap: 20px;
            }

            .nav-link {
                font-size: 11px;
            }

            .logo {
                min-width: 205px;
            }

            .logo-content h1 {
                font-size: 22px;
            }

            .header-actions {
                gap: 13px;
            }

            .shop-page {
                width: 92%;
            }

        }

        @media (max-width: 768px) {

            .top-bar {
                display: none;
            }

            .header {
                height: 70px;
            }

            .navigation {
                display: none;
            }

            .header-container {
                width: 92%;
            }

            .header-actions {
                gap: 13px;
            }

            .header-actions .header-icon:nth-child(1),
            .header-actions .header-icon:nth-child(2) {
                display: none;
            }

            .mobile-menu-button {
                display: flex;
            }

            .logo {
                min-width: auto;
            }

            .logo-content h1 {
                font-size: 21px;
            }

            .logo-content p {
                font-size: 7px;
            }

            .shop-page {
                width: 92%;
                padding-top: 38px;
            }

            .shop-heading h2 {
                font-size: 28px;
            }

            .product-card {
                grid-template-columns: 1fr;
                gap: 17px;
            }

            .product-image-wrap {
                width: 100%;
                height: 260px;
            }

            .product-info {
                padding: 0 4px 5px;
            }

            .product-name {
                font-size: 23px;
            }

        }

        @media (max-width: 420px) {

            .header-container {
                width: 90%;
            }

            .header-actions {
                gap: 9px;
            }

            .product-image-wrap {
                height: 230px;
            }

            .product-bottom {
                align-items: flex-start;
                flex-direction: column;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     TOP BAR
========================= -->

<!--<div class="top-bar">

    <div class="top-bar-item">
        <i class="fa-solid fa-truck"></i>
        <span>Free Shipping All Over India</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-regular fa-gem"></i>
        <span>100% Natural & Authentic Crystals</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-solid fa-shield-halved"></i>
        <span>Easy Returns & Secure Payments</span>
    </div>

</div>-->


<!-- =========================
     HEADER
========================= -->

<header class="header">

    <div class="header-container">


        <a href="https://divinehealingworld.com/" class="logo">

            <div class="logo-symbol">

                <img
                    src="https://vectorjungal.com/files/preview/1280x977/11724061489x7dnzumlkkkdctwc1jp9s6hmcc7hkelbcywsoq1ks90ylksgcvupex8nfc0knms8robegbblqtofo2ckk2viwtbtpyhxqomm1o4i.png"
                    alt="Divinehealingworld"
                >

            </div>

            <div class="logo-content">

                <h1>Divine Healing world</h1>

                <p>Nature's Energy. Your Style</p>

            </div>

        </a>


        <nav class="navigation">

            <a href="https://divinehealingworld.com/" class="nav-link">
                Home
            </a>
<a href="/reiki-healing.php" class="nav-link">
                Reiki Healing
            

            <a href="/tarot-reading.php" class="nav-link">
                Tarot Reading
            </a>

            <a href="/akashic-records.php" class="nav-link">
                Akashic Records
            </a>

            <a href="/animal-communication.php" class="nav-link">
                Animal Communication
            </a>

  <a href="/psychic-mediumship.php" class="nav-link">
                Psychic Mediumship
            </a>                          <div class="shop-dropdown">

              <!---  <a
                    href="#"
                    class="nav-link shop-link "
                    aria-haspopup="true"
                >
                    Shop
                    <i class="fa-solid fa-chevron-down"></i>
                </a>


                <ul class="shop-menu">
                    /
                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=3"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Crystals
                                </a>

                            </li>

                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=4"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Rings
                                </a>

                            </li>

                        
                    
                </ul>---->

            </div>


        </nav>


        <div class="header-actions">
         <style>
         .session-btn
         {
             background:black;
             color:#fff;
             font-size:15px;
             font-weight:bold;
             border:solid 1px white;
             padding:10px;
             border-radius:15px;
         }
         
         </style>
            <button class="session-btn"><a href="book-your-session.php">Book Session</a></button>
        </div>

    </div>

</header>


<!-- =========================
     MOBILE NAV
========================= -->

<nav
    class="mobile-navigation"
    id="mobileNavigation"
>

    <a href="index.php">
        Home
    </a>


    <div class="mobile-shop">

        <button
            type="button"
            class="mobile-shop-toggle"
            id="mobileShopToggle"
        >

            <span>
                Shop
            </span>

            <i class="fa-solid fa-chevron-down"></i>

        </button>


        <div
            class="mobile-shop-menu"
            id="mobileShopMenu"
        >

            <a href="products.php">

                <i class="fa-solid fa-box"></i>

                Products

            </a>


            <a href="best-sellers.php">

                <i class="fa-solid fa-star"></i>

                Best Sellers

            </a>


            
                <a
                    href="shop-category-products.php?category_id=3"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Crystals
                </a>

            
                <a
                    href="shop-category-products.php?category_id=4"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Rings
                </a>

            
        </div>

    </div>


    <a href="about.php">
        About Us
    </a>

    <a href="#">
        Tarot Reading
    </a>

    <a href="#">
        Akashic Records
    </a>

    <a href="#">
        Animal Communication
    </a>

</nav>


<!-- =========================
     PRODUCTS
========================= -->

<main class="shop-page">

    

</main>


<script>

    /* =========================
       MOBILE MENU
    ========================= */

    const menuButton =
        document.getElementById("menuButton");

    const mobileNavigation =
        document.getElementById("mobileNavigation");

    const menuIcon =
        menuButton
            ? menuButton.querySelector("i")
            : null;


    if (
        menuButton &&
        mobileNavigation &&
        menuIcon
    ) {

        menuButton.addEventListener("click", () => {

            mobileNavigation.classList.toggle("show");

            if (
                mobileNavigation.classList.contains("show")
            ) {

                menuIcon.classList.remove("fa-bars");
                menuIcon.classList.add("fa-xmark");

            } else {

                menuIcon.classList.remove("fa-xmark");
                menuIcon.classList.add("fa-bars");

            }

        });

    }


    /* =========================
       MOBILE SHOP
    ========================= */

    const mobileShopToggle =
        document.getElementById("mobileShopToggle");

    const mobileShop =
        document.querySelector(".mobile-shop");


    if (
        mobileShopToggle &&
        mobileShop
    ) {

        mobileShopToggle.addEventListener(
            "click",
            function () {

                mobileShop.classList.toggle("open");

            }
        );

    }


    /* =========================
       ADD TO CART
       UI READY
    ========================= */

    document
        .querySelectorAll(".add-cart-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                function () {

                    const productName =
                        this.dataset.productName || "Product";

                    alert(
                        productName +
                        " added to cart."
                    );

                }
            );

        });


    /* =========================
       CLOSE MOBILE MENU
    ========================= */

    document
        .querySelectorAll(".mobile-navigation a")
        .forEach(link => {

            link.addEventListener(
                "click",
                function () {

                    if (mobileNavigation) {
                        mobileNavigation.classList.remove("show");
                    }

                    if (menuIcon) {

                        menuIcon.classList.remove("fa-xmark");
                        menuIcon.classList.add("fa-bars");

                    }

                    if (mobileShop) {
                        mobileShop.classList.remove("open");
                    }

                }
            );

        });

</script>

</body>
</html>
<!-- DIVINE HEALING WORLD - CONTENT ONLY -->
<!-- Header and Footer are NOT included -->

<main class="dhw-page">

<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap');

.dhw-page {
    --dhw-purple: #301745;
    --dhw-purple-light: #51406d;
    --dhw-gold: #d2a15e;
    --dhw-cream: #fcf8f3;
    --dhw-text: #514b58;
    font-family: 'DM Sans', sans-serif;
    color: var(--dhw-text);
    overflow: hidden;
    background: #fffdfa;
}

.dhw-page * { box-sizing: border-box; }

.dhw-page img {
    width: 100%;
    display: block;
    object-fit: cover;
}

.dhw-page h1,
.dhw-page h2,
.dhw-page h3 {
    font-family: 'Playfair Display', serif;
    color: var(--dhw-purple);
    line-height: 1.2;
    margin: 0 0 15px;
}

.dhw-page p {
    font-size: 14px;
    line-height: 1.85;
    margin: 0 0 14px;
}

.dhw-page a { text-decoration: none; }

.dhw-page .dhw-container {
    width: min(1200px, 92%);
    margin: auto;
}

.dhw-page .dhw-eyebrow {
    color: var(--dhw-gold);
    font-size: 11px;
    letter-spacing: 3px;
    text-transform: uppercase;
    font-weight: 700;
    display: block;
    margin-bottom: 12px;
}

.dhw-page .dhw-heading {
    text-align: center;
    margin-bottom: 35px;
}

.dhw-page .dhw-heading h2 {
    font-size: clamp(27px, 3vw, 39px);
    margin-bottom: 12px;
}

.dhw-page .dhw-heading p {
    max-width: 650px;
    margin: auto;
}

.dhw-page .dhw-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    padding: 15px 25px;
    border-radius: 50px;
    background: var(--dhw-gold);
    color: #271532;
    font-size: 13px;
    font-weight: 700;
    transition: .3s ease;
    border: 1px solid transparent;
}

.dhw-page .dhw-btn:hover {
    background: #f3d18b;
    transform: translateY(-3px);
    box-shadow: 0 10px 25px #0002;
}

.dhw-page .dhw-btn-dark {
    background: var(--dhw-purple);
    color: white;
}

.dhw-page .dhw-btn-dark:hover {
    background: #513365;
}

/* ANIMATIONS */

.dhw-page .dhw-reveal {
    opacity: 0;
    transform: translateY(35px);
    transition: opacity .8s ease, transform .8s ease;
}

.dhw-page .dhw-reveal.dhw-visible {
    opacity: 1;
    transform: translateY(0);
}

.dhw-page .dhw-delay-1 { transition-delay: .12s; }
.dhw-page .dhw-delay-2 { transition-delay: .24s; }
.dhw-page .dhw-delay-3 { transition-delay: .36s; }

@keyframes dhwFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-12px); }
}

@keyframes dhwGlow {
    0%, 100% { box-shadow: 0 0 10px #d2a15e22; }
    50% { box-shadow: 0 0 28px #d2a15e66; }
}

@keyframes dhwFade {
    from { opacity: 0; transform: translateY(25px); }
    to { opacity: 1; transform: translateY(0); }
}

/* HERO */

.dhw-page .dhw-hero {
    min-height: 440px;
    position: relative;
    display: flex;
    align-items: center;
    color: white;
    background:
        linear-gradient(90deg, rgba(23, 12, 36, .94) 0%,
        rgba(35, 18, 43, .75) 46%, rgba(20, 10, 25, .12) 100%),
        url('aboutbanner.png')
        center 52% / cover no-repeat;
}

.dhw-page .dhw-hero-content {
    position: relative;
    z-index: 2;
    max-width: 650px;
    padding: 70px 0;
    animation: dhwFade 1s ease both;
}

.dhw-page .dhw-hero h1 {
    font-size: clamp(36px, 5vw, 59px);
    color: white;
    margin-bottom: 18px;
}

.dhw-page .dhw-hero h1 span { color: #f2c77b; }

.dhw-page .dhw-hero p {
    color: #f3edf5;
    max-width: 550px;
    margin-bottom: 25px;
    font-size: 14px;
}

.dhw-page .dhw-hero .dhw-eyebrow { color: #f3cb85; }

.dhw-page .dhw-hero::after {
    content: "";
    position: absolute;
    inset: auto 0 0;
    height: 75px;
    background: linear-gradient(transparent, #20102b35);
    pointer-events: none;
}

/* ABOUT */

.dhw-page .dhw-about {
    padding: 75px 0;
    background: var(--dhw-cream);
    position: relative;
}

.dhw-page .dhw-about-grid {
    display: grid;
    grid-template-columns: 1fr 1.05fr;
    gap: 55px;
    align-items: center;
}

.dhw-page .dhw-image-wrap {
    position: relative;
}

.dhw-page .dhw-about-image {
    height: 390px;
    border-radius: 12px;
    box-shadow: 0 15px 40px #3a1c2d18;
}

.dhw-page .dhw-image-wrap::before {
    content: "";
    position: absolute;
    width: 100px;
    height: 100px;
    border: 2px solid #d2a15e;
    border-radius: 12px;
    left: -12px;
    top: -12px;
    z-index: 0;
}

.dhw-page .dhw-image-wrap img {
    position: relative;
    z-index: 1;
}

.dhw-page .dhw-about h2 {
    font-size: clamp(28px, 3vw, 39px);
}

.dhw-page .dhw-about .dhw-eyebrow { color: #9b7954; }

/* FOUNDER */

.dhw-page .dhw-founder {
    padding: 75px 0;
    background: #f5eff5;
}

.dhw-page .dhw-founder-grid {
    display: grid;
    grid-template-columns: .82fr 1.4fr .55fr;
    gap: 32px;
    align-items: center;
}

.dhw-page .dhw-founder-photo {
    height: 365px;
    border-radius: 12px;
    border: 4px solid white;
    box-shadow: 0 12px 30px #30174518;
}

.dhw-page .dhw-founder h2 {
    font-size: clamp(27px, 3vw, 36px);
}

.dhw-page .dhw-founder p { font-size: 13px; }

.dhw-page .dhw-expert-list {
    background: #fff9f3;
    border-radius: 12px;
    padding: 15px;
}

.dhw-page .dhw-expert {
    text-align: center;
    padding: 19px 5px;
    border-bottom: 1px solid #e9dfe6;
}

.dhw-page .dhw-expert:last-child { border: 0; }

.dhw-page .dhw-expert-icon {
    width: 49px;
    height: 49px;
    margin: 0 auto 10px;
    border-radius: 50%;
    background: #f3e4d1;
    color: var(--dhw-purple);
    display: grid;
    place-items: center;
    font-size: 23px;
}

.dhw-page .dhw-expert span {
    font-size: 11px;
    font-weight: 600;
    line-height: 1.5;
    display: block;
}

/* SERVICES */

.dhw-page .dhw-services {
    padding: 75px 0;
    background: #fffdfa;
}

.dhw-page .dhw-service-grid {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 18px;
}

.dhw-page .dhw-service-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid #eee7ed;
    box-shadow: 0 6px 20px #3017450b;
    transition: transform .35s ease, box-shadow .35s ease;
}

.dhw-page .dhw-service-card:hover {
    transform: translateY(-9px);
    box-shadow: 0 18px 35px #30174519;
}

.dhw-page .dhw-service-card > img {
    height: 155px;
    transition: transform .6s ease;
}

.dhw-page .dhw-service-card:hover > img {
    transform: scale(1.06);
}

.dhw-page .dhw-service-content {
    padding: 0 15px 22px;
    text-align: center;
    position: relative;
}

.dhw-page .dhw-service-icon {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    margin: -24px auto 12px;
    position: relative;
    background: #fff8ef;
    border: 2px solid white;
    display: grid;
    place-items: center;
    color: #9b7745;
    font-size: 22px;
}

.dhw-page .dhw-service-card h3 {
    font-size: 17px;
    margin-bottom: 10px;
}

.dhw-page .dhw-service-card p {
    font-size: 12px;
    line-height: 1.75;
    margin: 0;
}

/* PHILOSOPHY */

.dhw-page .dhw-philosophy {
    padding: 75px 0;
    color: white;
    background:
        linear-gradient(100deg, rgba(32, 24, 65, .94),
        rgba(62, 43, 86, .94)),
        url('https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1800&q=80')
        center / cover no-repeat;
    position: relative;
}

.dhw-page .dhw-philosophy h2 { color: white; }

.dhw-page .dhw-philosophy p { color: #eee8f3; }

.dhw-page .dhw-philosophy .dhw-eyebrow { color: #edc781; }

.dhw-page .dhw-principles {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 25px;
    margin-top: 30px;
}

.dhw-page .dhw-principle {
    padding: 22px;
    border: 1px solid #ffffff2c;
    border-radius: 12px;
    background: #ffffff0b;
    transition: .3s ease;
}

.dhw-page .dhw-principle:hover {
    background: #ffffff15;
    transform: translateY(-5px);
}

.dhw-page .dhw-principle-icon {
    font-size: 30px;
    color: #f0ca83;
    margin-bottom: 12px;
}

.dhw-page .dhw-principle h3 {
    color: #f4d59c;
    font-size: 20px;
}

/* JOURNEY CTA */

.dhw-page .dhw-journey {
    padding: 75px 0;
    background: #fffaf5;
}

.dhw-page .dhw-journey-grid {
    display: grid;
    grid-template-columns: .75fr 1.5fr .7fr;
    align-items: center;
    gap: 30px;
}

.dhw-page .dhw-journey-image {
    height: 310px;
    border-radius: 12px;
}

.dhw-page .dhw-journey h2 {
    font-size: clamp(25px, 3vw, 34px);
}

.dhw-page .dhw-journey-quote {
    padding: 18px;
    border-radius: 8px;
    background: #f4e9dd;
    color: var(--dhw-purple);
    text-align: center;
    font-family: 'Playfair Display', serif;
    font-size: 15px;
    line-height: 1.7;
}

.dhw-page .dhw-connect {
    background: #f4edf4;
    border-radius: 12px;
    padding: 25px 18px;
    text-align: center;
}

.dhw-page .dhw-connect-icon {
    font-size: 37px;
    color: #b58c51;
    margin-bottom: 10px;
}

.dhw-page .dhw-connect h3 { font-size: 22px; }

.dhw-page .dhw-connect p { font-size: 12px; }

.dhw-page .dhw-connect .dhw-btn {
    padding: 13px 18px;
    font-size: 11px;
}

/* RESPONSIVE */

@media (max-width: 1000px) {
    .dhw-page .dhw-service-grid {
        grid-template-columns: repeat(3, 1fr);
    }

    .dhw-page .dhw-founder-grid {
        grid-template-columns: .8fr 1.4fr;
    }

    .dhw-page .dhw-expert-list {
        grid-column: 1 / -1;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
    }

    .dhw-page .dhw-expert {
        border-bottom: 0;
        border-right: 1px solid #e9dfe6;
    }

    .dhw-page .dhw-expert:last-child { border-right: 0; }

    .dhw-page .dhw-journey-grid {
        grid-template-columns: .7fr 1.3fr;
    }

    .dhw-page .dhw-connect {
        grid-column: 1 / -1;
    }
}

@media (max-width: 650px) {
    .dhw-page .dhw-container { width: 90%; }

    .dhw-page .dhw-hero {
        min-height: 460px;
        background-position: 62% center;
    }

    .dhw-page .dhw-hero-content { padding: 55px 0; }

    .dhw-page .dhw-hero h1 { font-size: 37px; }

    .dhw-page .dhw-hero p { font-size: 13px; }

    .dhw-page .dhw-about,
    .dhw-page .dhw-founder,
    .dhw-page .dhw-services,
    .dhw-page .dhw-philosophy,
    .dhw-page .dhw-journey { padding: 52px 0; }

    .dhw-page .dhw-about-grid,
    .dhw-page .dhw-founder-grid,
    .dhw-page .dhw-journey-grid {
        grid-template-columns: 1fr;
        gap: 28px;
    }

    .dhw-page .dhw-about-image { height: 270px; }

    .dhw-page .dhw-founder-photo { height: 340px; }

    .dhw-page .dhw-founder-grid > div:first-child {
        max-width: 380px;
        width: 100%;
        margin: auto;
    }

    .dhw-page .dhw-expert-list {
        grid-column: auto;
    }

    .dhw-page .dhw-service-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
    }

    .dhw-page .dhw-service-card > img { height: 130px; }

    .dhw-page .dhw-service-content { padding: 0 10px 17px; }

    .dhw-page .dhw-service-card h3 { font-size: 15px; }

    .dhw-page .dhw-service-card p { font-size: 11px; }

    .dhw-page .dhw-principles {
        grid-template-columns: 1fr;
        gap: 14px;
    }

    .dhw-page .dhw-principle { padding: 20px; }

    .dhw-page .dhw-journey-image { height: 260px; }

    .dhw-page .dhw-connect { grid-column: auto; }
}

@media (prefers-reduced-motion: reduce) {
    .dhw-page *,
    .dhw-page *::before,
    .dhw-page *::after {
        animation-duration: .01ms !important;
        transition-duration: .01ms !important;
        scroll-behavior: auto !important;
    }

    .dhw-page .dhw-reveal {
        opacity: 1;
        transform: none;
    }
}
</style>

<!-- 1. HERO SECTION -->

<section class="dhw-hero">
    <div class="dhw-container">
        <div class="dhw-hero-content">
            <span class="dhw-eyebrow">Divine Healing World</span>

            <h1>
                A Journey Towards
                <span>Healing, Balance &amp; Spiritual Awakening</span>
            </h1>

            <p>
                Welcome to Divine Healing World, a space dedicated to spiritual
                exploration, inner harmony, self-discovery, and holistic well-being.
                We believe that every individual deserves an opportunity to reconnect
                with their inner self, find clarity during challenging times, and
                move forward with greater peace, awareness, and purpose.
            </p>
   <!--
         <a href="#dhw-services" class="dhw-btn">
                Discover Our Services <span>→</span>
            </a>-->
        </div>
    </div>
</section>

<!-- 2. ABOUT SECTION -->

<section class="dhw-about">
    <div class="dhw-container dhw-about-grid">

        <div class="dhw-image-wrap dhw-reveal">
            <img
                class="dhw-about-image"
                src="about20.png"
                alt="Candles and a peaceful spiritual environment"
                loading="lazy"
            >
        </div>

        <div class="dhw-reveal dhw-delay-1">
            <span class="dhw-eyebrow">Divine Healing World</span>

            <h2>A Place for Healing, Growth &amp; Inner Peace</h2>

            <p>
                Through personalized healing sessions, intuitive guidance, and
                spiritual practices, Divine Healing World aims to create a supportive
                environment where you can explore your personal journey, release
                emotional burdens, and embrace a more balanced approach to life.
            </p>

            <p>
                Our mission is to support individuals as they discover new perspectives,
                reconnect with their inner wisdom, and cultivate a deeper sense of
                harmony within themselves and their surroundings.
            </p>
        </div>

    </div>
</section>

<!-- 3. FOUNDER SECTION -->

<section class="dhw-founder">
    <div class="dhw-container dhw-founder-grid">

        <div class="dhw-reveal">
            <img
                class="dhw-founder-photo"
                src="kamal-sahni.jpeg"
                alt="Portrait representing a spiritual wellness practitioner"
                loading="lazy"
            >
        </div>

        <div class="dhw-reveal dhw-delay-1">
            <span class="dhw-eyebrow">Meet Our Founder</span>

            <h2>Kamal Deep Sahni</h2>

            <p>
                Kamal Deep Sahni is the founder of Divine Healing World, bringing
                together a passion for spiritual growth and expertise in multiple
                spiritual practices. As a Reiki Grandmaster, Tarot Reading Expert,
                and Akashic Records Expert, Kamal Deep Sahni is dedicated to helping
                individuals explore their spiritual journeys through personalized
                sessions and compassionate guidance.
            </p>

            <p>
                With a focus on energy healing, intuitive interpretation, and
                spiritual exploration, Kamal Deep Sahni offers a thoughtful approach
                to understanding life's challenges and discovering new possibilities
                for personal growth.
            </p>

            <p>
                Each session is approached with care, respect, and an understanding
                that every person's experiences, questions, and needs are unique.
                The intention is to provide a peaceful and supportive space where
                individuals can reflect, gain perspective, and reconnect with their
                inner sense of balance.
            </p>

            <p>
                Through Divine Healing World, Kamal Deep Sahni aspires to make
                spiritual practices more approachable and meaningful for people
                seeking greater clarity, emotional harmony, and personal transformation.
            </p>
        </div>

        <div class="dhw-expert-list dhw-reveal dhw-delay-2">

            <div class="dhw-expert">
                <div class="dhw-expert-icon">♧</div>
                <span>Reiki Grandmaster</span>
            </div>

            <div class="dhw-expert">
                <div class="dhw-expert-icon">✧</div>
                <span>Tarot Reading Expert</span>
            </div>

            <div class="dhw-expert">
                <div class="dhw-expert-icon">◎</div>
                <span>Akashic Records Expert</span>
            </div>
            
            <div class="dhw-expert">
                <div class="dhw-expert-icon">♡</div>
                <span>Animal Communicater</span>
            </div>

        </div>

    </div>
</section>

<!-- 4. SERVICES SECTION -->

<section class="dhw-services" id="dhw-services">
    <div class="dhw-container">

        <div class="dhw-heading dhw-reveal">
            <span class="dhw-eyebrow">Our Areas of Expertise</span>
            <h2>Explore Our Healing Services</h2>
            <p>
                Discover a range of spiritual services designed to support your
                well-being, bring clarity, and help you live a more balanced
                and fulfilling life.
            </p>
        </div>

        <div class="dhw-service-grid">

            <article class="dhw-service-card dhw-reveal">
                <img
                    src="reiki.jpg"
                    alt="Peaceful wellness and meditation"
                    loading="lazy"
                >
                <div class="dhw-service-content">
                    <div class="dhw-service-icon">✧</div>
                    <h3>Reiki Healing</h3>
                    <p>
                        Reiki sessions offer a peaceful opportunity to slow down,
                        reconnect with yourself, and support your personal
                        wellness journey.
                    </p>
                </div>
            </article>

            <article class="dhw-service-card dhw-reveal dhw-delay-1">
                <img
                    src="tarotreading.png"
                    alt="Tarot cards and candlelight"
                    loading="lazy"
                >
                <div class="dhw-service-content">
                    <div class="dhw-service-icon">♧</div>
                    <h3>Tarot Reading</h3>
                    <p>
                        Tarot reading uses the symbolism of tarot cards to explore
                        questions, reflect on life situations, and consider
                        different perspectives.
                    </p>
                </div>
            </article>

            <article class="dhw-service-card dhw-reveal dhw-delay-2">
                <img
                    src="akashic.jpg"
                    alt="A starry night sky"
                    loading="lazy"
                >
                <div class="dhw-service-content">
                    <div class="dhw-service-icon">◎</div>
                    <h3>Akashic Records Reading</h3>
                    <p>
                        Explore recurring themes, personal questions, and
                        spiritual perspectives as part of your journey
                        towards greater self-awareness.
                    </p>
                </div>
            </article>

            <article class="dhw-service-card dhw-reveal dhw-delay-1">
                <img
                    src="psychic.jpg"
                    alt="Sunrise over a peaceful landscape"
                    loading="lazy"
                >
                <div class="dhw-service-content">
                    <div class="dhw-service-icon">♧</div>
                    <h3>Psychic Mentorship</h3>
                    <p>
                        Explore your intuitive potential, strengthen your spiritual awareness, and develop a deeper connection with your inner wisdom.
                    </p>
                </div>
            </article>

            <article class="dhw-service-card dhw-reveal dhw-delay-2">
                <img
                    src="houseenergy.jpg"
                    alt="Candles creating a calming atmosphere"
                    loading="lazy"
                >
                <div class="dhw-service-content">
                    <div class="dhw-service-icon">⌂</div>
                    <h3>House Energy Healing &amp; Space Clearing</h3>
                    <p>
                        Create a space that feels calmer, more harmonious,
                        and aligned with your personal intentions.
                    </p>
                </div>
            </article>

        </div>
    </div>
</section>



<!-- 6. BEGIN YOUR JOURNEY -->

<section class="dhw-journey">
    <div class="dhw-container dhw-journey-grid">

        <div class="dhw-reveal">
            <img
                class="dhw-journey-image"
                src="https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=700&q=85"
                alt="A new day and a fresh beginning"
                loading="lazy"
            >
        </div>

        <div class="dhw-reveal dhw-delay-1">
            <span class="dhw-eyebrow">Begin Your Spiritual Journey With Us</span>

            <h2>A Path to Greater Clarity &amp; Harmony</h2>

            <p>
                Whether you are exploring Reiki for the first time, seeking
                perspective through Tarot Reading, curious about Akashic Records,
                or looking to bring a greater sense of harmony into your home,
                Divine Healing World welcomes you to explore the services
                that resonate with you.
            </p>

            <p>
                Allow yourself a moment to pause, reflect, and reconnect with
                what matters most to you.
            </p>

            <div class="dhw-journey-quote">
                Divine Healing World – A Space for Spiritual Growth,
                Inner Balance &amp; Self-Discovery.
            </div>
        </div>

        <div class="dhw-connect dhw-reveal dhw-delay-2">
            <div class="dhw-connect-icon">♧</div>

            <span class="dhw-eyebrow">Connect With</span>

            <h3>Kamal Deep Sahni</h3>

            <p>
                Take the first step towards a more mindful and meaningful
                spiritual journey.
            </p>

            <!-- Replace # with your actual booking/contact page -->
            <a href="#" class="dhw-btn dhw-btn-dark">
                Book Your Session Today →
            </a>
        </div>

    </div>
</section>

</main>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Divinehealingworld - Customer Reviews</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

html{
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background:#fff;
    color:#29202f;
    overflow-x:hidden;
}

button,
input{
    font-family:inherit;
}

.container{
    width:92%;
    max-width:1180px;
    margin:auto;
}

/* =========================
   BENEFITS
========================= */

.benefits-section{
    padding:16px 0 10px;
}

.benefits-box{
    width:92%;
    max-width:1200px;
    margin:auto;

    background:linear-gradient(
        120deg,
        #faf7f5,
        #fff,
        #faf7f5
    );

    border-radius:10px;

    box-shadow:
        0 5px 25px rgba(45,20,55,.04);

    display:grid;
    grid-template-columns:repeat(4,1fr);

    overflow:hidden;

    animation:fadeDown .8s ease;
}

.benefit{
    min-height:74px;

    display:flex;
    align-items:center;
    gap:13px;

    padding:10px 25px;

    border-right:1px solid #d9d2d8;

    transition:.35s ease;
}

.benefit:last-child{
    border-right:none;
}

.benefit:hover{
    background:#fff;
    transform:translateY(-2px);
}

.benefit-icon{
    width:40px;
    height:40px;

    border:1.5px solid #392443;
    border-radius:50%;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:18px;

    flex-shrink:0;

    transition:.4s ease;
}

.benefit:hover .benefit-icon{
    transform:rotate(360deg);
    background:#3b2546;
    color:#fff;
}

.benefit h4{
    font-size:11px;
    font-weight:600;
    margin-bottom:1px;
}

.benefit p{
    font-size:8px;
    color:#777;
}

/* =========================
   TESTIMONIAL
========================= */

.testimonial-section{
    padding:18px 0 18px;
}

.section-title{
    text-align:center;
    margin-bottom:15px;

    animation:fadeUp .8s ease;
}

.section-title h2{
    font-family:'DM Serif Display',serif;
    font-size:28px;
    font-weight:400;
    color:#33203e;
}

.section-title p{
    font-size:18px;
    color:#777;
    margin-top:1px;
}

/* =========================
   REVIEWS
========================= */

.reviews{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:14px;
}

.review-card{
    border:1px solid #e2dfe2;
    border-radius:5px;

    padding:11px 15px;

    min-height:108px;

    background:#fff;

    transition:
        transform .35s ease,
        box-shadow .35s ease,
        border-color .35s ease;

    opacity:0;
    transform:translateY(30px);
}

.review-card.show{
    opacity:1;
    transform:translateY(0);
}

.review-card:hover{
    transform:translateY(-6px);
    border-color:#c9b6d0;

    box-shadow:
        0 12px 30px rgba(54,30,65,.10);
}

.review-top{
    display:flex;
    align-items:center;
    gap:10px;
}

.avatar{
    width:42px;
    height:42px;

    border-radius:50%;
    overflow:hidden;

    flex-shrink:0;

    background:linear-gradient(
        135deg,
        #eee,
        #ddd
    );
}

.avatar img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.stars{
    color:#e4a719;
    font-size:18px;
    letter-spacing:1px;
    margin-bottom:3px;
}

.review-text{
    font-size:12px;
    color:#4d4d4d;
    line-height:1.55;

    margin-top:8px;
}

.customer{
    margin-top:7px;
    font-size:12px;
    font-weight:600;
}

.customer-location{
    font-size:10px;
    color:#777;
    margin-top:1px;
}

/* =========================
   COMMUNITY
========================= */

.community{
    position:relative;

    background:
        linear-gradient(
            135deg,
            #684c72,
            #795a83,
            #67476e
        );

    min-height:98px;

    overflow:hidden;

    color:#fff;

    display:flex;
    justify-content:center;
    align-items:center;

    text-align:center;

    margin-top:0;
}

.community-content{
    position:relative;
    z-index:2;
}

.community h2{
    font-family:'DM Serif Display',serif;
    font-weight:400;
    font-size:25px;
}

.community p{
    font-size:15px;
    opacity:.85;
    margin:2px 0 8px;
}

.subscribe{
    display:flex;
    width:450px;
    height:40px;
    margin:auto;

    background:#fff;
    border-radius:20px;

    overflow:hidden;

    box-shadow:
        0 4px 15px rgba(0,0,0,.12);

    transition:.3s;
}

.subscribe:focus-within{
    transform:scale(1.03);
}

.subscribe input{
    flex:1;
    min-width:0;

    border:none;
    outline:none;

    padding:0 12px;

    font-size:15px;
    color:#444;
}

.subscribe button{
    border:none;

    width:100px;

    background:#28192f;
    color:#fff;

    font-size:15px;

    cursor:pointer;

    transition:.3s;
}

.subscribe button:hover{
    background:#170e1b;
}

/* Floating crystals */

.crystal{
    position:absolute;
    width:45px;
    height:45px;

    opacity:.25;

    border:1px solid #fff;

    transform:rotate(35deg);

    animation:floatCrystal 4s ease-in-out infinite;
}

.crystal::before{
    content:"";
    position:absolute;
    inset:8px;

    border:1px solid #fff;

    transform:rotate(45deg);
}

.crystal.one{
    left:15%;
    top:16px;
}

.crystal.two{
    right:15%;
    top:20px;
    width:35px;
    height:35px;

    animation-delay:1s;
}

.crystal.three{
    right:11%;
    top:43px;
    width:20px;
    height:20px;

    animation-delay:2s;
}

/* =========================
   FOOTER
========================= */

footer{
    background:
        linear-gradient(
            135deg,
            #20142a,
            #2b1936,
            #1d1325
        );

    color:#fff;

    padding:12px 0 8px;
}

.footer-container{
    width:100%;
    max-width:1200px;
    margin:auto;

    display:grid;

    grid-template-columns:
        1.7fr
        1fr
        1fr
        1.15fr;

    gap:30px;
}

/* Logo */

.footer-logo{
    display:flex;
    align-items:center;
    gap:7px;
}

.logo-icon{
    font-size:30px;
    line-height:1;
}

.footer-logo h2{
    font-family:'DM Serif Display',serif;
    font-size:23px;
    font-weight:400;
}

.footer-logo span{
    display:block;
    font-size:12px;
    color:#ddd;
    letter-spacing:.5px;
}

.footer-about p{
    font-size:10px;
    line-height:1.7;

    color:#d4ccd8;

    max-width:280px;

    margin-top:8px;
}

/* Social */

.socials{
    display:flex;
    gap:13px;
    margin-top:9px;
}

.socials a{
    color:#fff;
    text-decoration:none;

    font-size:20px;

    width:18px;
    height:18px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    transition:.3s;
}

.socials a:hover{
    background:#fff;
    color:#28182f;
    transform:translateY(-3px);
}

/* Footer columns */

.footer-column h3{
    font-size:15px;
    font-weight:500;

    margin-bottom:8px;
}

.footer-column ul{
    list-style:none;
}

.footer-column li{
    margin-bottom:5px;
}

.footer-column a{
    color:#d2cbd6;
    text-decoration:none;

    font-size:15px;

    transition:.3s;
}

.footer-column a:hover{
    color:#fff;
    padding-left:4px;
}

/* Contact */

.contact-item{
    display:flex;
    align-items:center;
    gap:8px;

    color:#d2cbd6;

    font-size:15px;

    margin-bottom:7px;
}

.contact-icon{
    width:15px;
    text-align:center;
    font-size:18px;
}

/* =========================
   COPYRIGHT
========================= */

.footer-bottom{
    width:92%;
    max-width:1180px;

    margin:8px auto 0;

    padding-top:7px;

    border-top:1px solid rgba(255,255,255,.14);

    display:flex;
    align-items:center;
    justify-content:space-between;

    font-size:12px;

    color:#bbb;
}

.footer-links{
    display:flex;
    gap:12px;
}

.footer-links a{
    color:#bbb;
    text-decoration:none;
    transition:.3s;
}

.footer-links a:hover{
    color:#fff;
}

/* =========================
   ANIMATIONS
========================= */

@keyframes fadeDown{
    from{
        opacity:0;
        transform:translateY(-25px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(20px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes floatCrystal{

    0%,100%{
        transform:
            rotate(35deg)
            translateY(0);
    }

    50%{
        transform:
            rotate(50deg)
            translateY(-8px);
    }
}

/* =========================
   TABLET
========================= */

@media(max-width:850px){

    .benefits-box{
        grid-template-columns:repeat(2,1fr);
    }

    .benefit:nth-child(2){
        border-right:none;
    }

    .benefit:nth-child(1),
    .benefit:nth-child(2){
        border-bottom:1px solid #ddd;
    }

    .reviews{
        grid-template-columns:1fr;
        max-width:600px;
        margin:auto;
    }

    .review-card{
        min-height:auto;
    }

    .footer-container{
        grid-template-columns:1fr 1fr;
    }

}

/* =========================
   MOBILE
========================= */

@media(max-width:600px){

    .benefits-section{
        padding-top:10px;
    }

    .benefits-box{
        width:94%;
        grid-template-columns:1fr 1fr;
    }

    .benefit{
        padding:10px;
        gap:8px;
    }

    .benefit-icon{
        width:34px;
        height:34px;
        font-size:14px;
    }

    .benefit h4{
        font-size:9px;
    }

    .benefit p{
        font-size:6.5px;
    }

    .section-title h2{
        font-size:21px;
    }

    .section-title p{
        font-size:8px;
    }

    .reviews{
        width:94%;
    }

    .community{
        min-height:105px;
    }

    .community h2{
        font-size:18px;
    }

    .subscribe{
        width:230px;
    }

    .crystal.one{
        left:4%;
    }

    .crystal.two{
        right:5%;
    }

    .crystal.three{
        right:2%;
    }

    footer{
        padding-top:25px;
    }

    .footer-container{
        width:88%;
        grid-template-columns:1fr 1fr;
        gap:25px 15px;
    }

    .footer-about{
        grid-column:1 / -1;
    }

    .footer-about p{
        max-width:100%;
    }

    .footer-bottom{
        width:88%;

        flex-direction:column;
        align-items:flex-start;

        gap:8px;
    }

    .footer-links{
        gap:8px;
        flex-wrap:wrap;
    }

}

/* =========================
   SMALL MOBILE
========================= */

@media(max-width:380px){

    .benefits-box{
        grid-template-columns:1fr;
    }

    .benefit{
        border-right:none !important;
        border-bottom:1px solid #ddd;
    }

    .benefit:last-child{
        border-bottom:none;
    }

    .footer-container{
        grid-template-columns:1fr;
    }

    .footer-about{
        grid-column:auto;
    }

    .footer-bottom{
        font-size:6px;
    }

}

</style>
</head>

<body>

<!-- =====================================
     COMMUNITY
===================================== -->

<section class="community">


    <div class="crystal one"></div>
    <div class="crystal two"></div>
    <div class="crystal three"></div>


    <div class="community-content">
        <br>
        <br>

        <h2>
            Join Our Crystal Community
        </h2>

        <p>
            Get exclusive offers, new arrivals and crystal tips straight to your inbox.
        </p>

<br>
        <form
            class="subscribe"
            id="subscribeForm"
        >

            <input
                type="email"
                id="email"
                placeholder="Enter your email address"
                required
            >

            <button type="submit">
                Subscribe
            </button>

        </form>
<br>
<br>
<br>
    </div>

</section>


<!-- =====================================
     FOOTER
===================================== -->

<footer>

    <div class="footer-container">


        <!-- ABOUT -->

        <div class="footer-about">

            <div class="footer-logo">

                <div class="logo-icon">
                    ♢
                </div>

                <div>

                    <h2>
                        Divinehealingworld
                    </h2>

                    <span>
                        Nature's Energy. Your Style
                    </span>

                </div>

            </div>


            <p>
                At Divinehealingworld, we bring you fine natural
                crystals and handcrafted jewellery to help you
                connect with your inner peace and positive energy.
            </p>


            <div class="socials">

                <a href="#" aria-label="Facebook">
                    f
                </a>

                <a href="#" aria-label="Instagram">
                    ◎
                </a>

                <a href="#" aria-label="Pinterest">
                    p
                </a>

                <a href="#" aria-label="Youtube">
                    ▶
                </a>

            </div>

        </div>


        <!-- QUICK LINKS -->

        <div class="footer-column">

            <h3>
                Quick Links
            </h3>

            <ul>

                <li>
                    <a href="#">Home</a>
                </li>
                <li>
                    <a href="#">About Us</a>
                </li>

                <li>
                    <a href="blog.php">Blog</a>
                </li>

                <li>
                    <a href="contact.php">Contact</a>
                </li>

            </ul>

        </div>


        <!-- SHOP -->

        <div class="footer-column">

            <h3>
               Our Services
            </h3>

            <ul>

                <li>
                    <a href="reiki-healing.php">Reiki Healing</a>
                </li>

                <li>
                    <a href="akashic-records.php">Akashic Records</a>
                </li>

                <li>
                    <a href="animal-communication.php">Animal Communication</a>
                </li>

                <li>
                    <a href="tarot-reading.php">Tarot Reading</a>
                </li>

                <li>
                    <a href="home-energy.php">Home Energy</a>
                </li>

                <li>
                    <a href="psychic-mediumShip.php<">Psychic MediumShip</a>
                </li>

            </ul>

        </div>


        <!-- CONTACT -->

        <div class="footer-column">

            <h3>
                Contact Us
            </h3>


            <div class="contact-item">

                <div class="contact-icon">
                    ✉
                </div>

                support@Divinehealingworld.com

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ☎
                </div>

                +91 9711766949

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ●
                </div>

                India

            </div>

        </div>


    </div>


    <!-- COPYRIGHT -->

    <div class="footer-bottom">

        <div>
            © 2026 Divinehealingworld. All rights reserved.
        </div>
          <div>
    Developed By
    <a
        href="https://www.google.com/search?q=parvez3737"
        target="_blank"
        rel="noopener noreferrer"
        style="text-decoration: none; color: inherit;"
    >
        Parvez Ahmad (Parvez3737)
    </a>
</div>

        <div class="footer-links">

            <a href="#">
                Privacy Policy
            </a>

            <span>|</span>

            <a href="#">
                Terms & Conditions
            </a>

            <span>|</span>

            <a href="#">
                Shipping Policy
            </a>

        </div>

    </div>

</footer>


<!-- =====================================
     JAVASCRIPT
===================================== -->

<script>

/* =====================================
   SCROLL REVEAL
===================================== */

const cards = document.querySelectorAll(".review-card");

const observer = new IntersectionObserver(
    (entries) => {

        entries.forEach((entry, index) => {

            if(entry.isIntersecting){

                setTimeout(() => {

                    entry.target.classList.add("show");

                }, index * 180);

                observer.unobserve(entry.target);

            }

        });

    },
    {
        threshold:0.15
    }
);


cards.forEach(card => {

    observer.observe(card);

});


/* =====================================
   NEWSLETTER
===================================== */

const form = document.getElementById("subscribeForm");

form.addEventListener("submit", function(e){

    e.preventDefault();

    const email =
        document.getElementById("email").value.trim();

    if(!email){
        return;
    }

    const button =
        form.querySelector("button");

    const oldText =
        button.textContent;

    button.textContent = "Subscribed ✓";

    button.style.background = "#493052";

    setTimeout(() => {

        button.textContent = oldText;

        button.style.background = "";

        form.reset();

    }, 2500);

});


/* =====================================
   MOUSE PARALLAX CRYSTALS
===================================== */

const crystals =
    document.querySelectorAll(".crystal");

document.addEventListener("mousemove", function(e){

    const x =
        (window.innerWidth / 2 - e.clientX) / 60;

    const y =
        (window.innerHeight / 2 - e.clientY) / 60;

    crystals.forEach((crystal, index) => {

        const amount =
            (index + 1) * 0.6;

        crystal.style.marginLeft =
            `${x * amount}px`;

        crystal.style.marginTop =
            `${y * amount}px`;

    });

});


/* =====================================
   REVIEW CARD HOVER
===================================== */

cards.forEach(card => {

    card.addEventListener("mouseenter", () => {

        card.style.zIndex = "5";

    });

    card.addEventListener("mouseleave", () => {

        card.style.zIndex = "";

    });

});

</script>

</body>
</html><script>
(function () {
    const root = document.querySelector('.dhw-page');
    if (!root) return;

    const elements = root.querySelectorAll('.dhw-reveal');

    // Reveal sections as they enter the viewport
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('dhw-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.12,
            rootMargin: '0px 0px -35px 0px'
        });

        elements.forEach(function (element) {
            observer.observe(element);
        });
    } else {
        elements.forEach(function (element) {
            element.classList.add('dhw-visible');
        });
    }

    // Smooth scrolling for links inside this content
    root.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function (event) {
            const href = link.getAttribute('href');

            if (!href || href === '#') {
                return;
            }

            const target = root.querySelector(href);

            if (target) {
                event.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
})();
</script>

