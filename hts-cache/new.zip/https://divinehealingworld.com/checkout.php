
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Checkout - Divine Healing World
</title>


<link
    rel="preconnect"
    href="https://fonts.googleapis.com"
>

<link
    rel="preconnect"
    href="https://fonts.gstatic.com"
    crossorigin
>

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet"
>


<style>

/* =====================================================
   RESET
===================================================== */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}


/* =====================================================
   BODY
===================================================== */

body{
    font-family:'Poppins',sans-serif;
    background:#f6f7fb;
    color:#171717;
}


/* =====================================================
   HEADER
===================================================== */

.checkout-header{
    width:100%;
    background:#ffffff;
    border-bottom:1px solid #e8e8e8;
    padding:18px 6%;
}


.header-inner{
    max-width:1250px;
    margin:auto;

    display:flex;
    align-items:center;
    justify-content:space-between;
}


.logo{
    font-size:25px;
    font-weight:700;
    color:#b61491;
    text-decoration:none;
}


.secure-text{
    font-size:13px;
    color:#777;
}


/* =====================================================
   MAIN
===================================================== */

.checkout-wrapper{
    width:90%;
    max-width:1250px;
    margin:45px auto;
}


.checkout-title{
    font-size:30px;
    font-weight:700;
    margin-bottom:28px;
}


/* =====================================================
   GRID
===================================================== */

.checkout-grid{
    display:grid;
    grid-template-columns:1.35fr .75fr;
    gap:28px;
}


/* =====================================================
   CARD
===================================================== */

.checkout-card{
    background:#fff;
    border-radius:18px;
    padding:28px;
    box-shadow:0 8px 30px rgba(0,0,0,.06);
    margin-bottom:22px;
}


.card-title{
    font-size:19px;
    font-weight:700;
    margin-bottom:22px;
}


/* =====================================================
   FORM
===================================================== */

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:18px;
}


.form-group{
    display:flex;
    flex-direction:column;
    gap:7px;
}


.form-group.full{
    grid-column:1/-1;
}


.form-group label{
    font-size:13px;
    font-weight:600;
    color:#444;
}


.form-group input,
.form-group select,
.form-group textarea{
    width:100%;

    border:1px solid #ddd;
    border-radius:10px;

    padding:13px 14px;

    outline:none;

    font-family:inherit;
    font-size:14px;

    background:#fff;

    transition:.25s;
}


.form-group textarea{
    min-height:95px;
    resize:vertical;
}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus{
    border-color:#b61491;

    box-shadow:
        0 0 0 3px rgba(182,20,145,.08);
}


/* =====================================================
   PAYMENT
===================================================== */

.payment-option{
    border:1px solid #ddd;

    border-radius:12px;

    padding:15px;

    margin-bottom:12px;

    display:flex;

    align-items:center;

    gap:12px;

    cursor:pointer;

    transition:.2s;
}


.payment-option:hover{
    border-color:#b61491;
    background:#fff8fd;
}


.payment-option input{
    accent-color:#b61491;
}


.payment-icon{
    width:38px;
    height:38px;

    border-radius:9px;

    display:flex;

    align-items:center;
    justify-content:center;

    background:#f5e8f2;

    font-size:18px;
}


/* =====================================================
   SUMMARY
===================================================== */

.summary-card{
    position:sticky;
    top:20px;
}


/* =====================================================
   CART PRODUCT
===================================================== */

.cart-product{
    display:grid;

    grid-template-columns:82px 1fr auto;

    gap:14px;

    padding:16px 0;

    border-bottom:1px solid #eee;
}


.cart-product:first-child{
    padding-top:0;
}


.cart-product img{
    width:82px;
    height:82px;

    border-radius:12px;

    object-fit:cover;

    border:1px solid #eee;

    background:#fafafa;
}


.cart-product-info{
    min-width:0;
}


.cart-product-info h3{
    font-size:14px;
    font-weight:600;

    margin-bottom:4px;

    color:#222;
}


.cart-product-info .product-title{
    font-size:11px;
    color:#b61491;

    margin-bottom:5px;
}


.cart-product-info p{
    font-size:12px;
    color:#777;

    line-height:1.5;
}


.cart-product-price{
    font-size:14px;
    font-weight:700;

    white-space:nowrap;
}


/* =====================================================
   QUANTITY
===================================================== */

.quantity-box{
    display:flex;

    align-items:center;

    gap:8px;

    margin-top:9px;
}


.quantity-label{
    font-size:11px;
    color:#777;
}


.quantity-number{
    font-size:12px;
    font-weight:600;

    background:#f7f1f7;

    padding:3px 8px;

    border-radius:6px;

    color:#382342;
}


/* =====================================================
   SUMMARY ROW
===================================================== */

.summary-row{
    display:flex;

    justify-content:space-between;

    padding:10px 0;

    font-size:14px;
}


.summary-row span:first-child{
    color:#666;
}


.summary-total{
    border-top:1px solid #eee;

    margin-top:10px;

    padding-top:18px;
}


.summary-total span{
    font-size:18px;
    font-weight:700;
}


/* =====================================================
   BUTTON
===================================================== */

.place-order{
    width:100%;

    border:0;

    border-radius:12px;

    padding:15px;

    background:
        linear-gradient(
            135deg,
            #b61491,
            #e52c76
        );

    color:#fff;

    font-family:inherit;

    font-size:15px;

    font-weight:700;

    cursor:pointer;

    transition:.3s;

    margin-top:18px;
}


.place-order:hover{
    transform:translateY(-2px);

    box-shadow:
        0 10px 25px
        rgba(182,20,145,.25);
}


.secure-note{
    text-align:center;

    color:#888;

    font-size:11px;

    margin-top:13px;
}


/* =====================================================
   EMPTY CART
===================================================== */

.empty-cart{
    background:#fff;

    border-radius:18px;

    padding:70px 25px;

    text-align:center;

    box-shadow:
        0 8px 30px rgba(0,0,0,.06);
}


.empty-cart-icon{
    width:75px;
    height:75px;

    border-radius:50%;

    background:#f8eaf5;

    display:flex;

    align-items:center;
    justify-content:center;

    margin:0 auto 20px;

    font-size:30px;

    color:#b61491;
}


.empty-cart h2{
    font-size:24px;

    margin-bottom:8px;
}


.empty-cart p{
    color:#777;

    font-size:13px;

    margin-bottom:22px;
}


.continue-shopping{
    display:inline-flex;

    align-items:center;

    gap:8px;

    padding:12px 20px;

    background:#382342;

    color:#fff;

    border-radius:9px;

    text-decoration:none;

    font-size:13px;

    font-weight:600;
}


.continue-shopping:hover{
    background:#b61491;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width:850px){

    .checkout-grid{
        grid-template-columns:1fr;
    }


    .summary-card{
        position:relative;
        top:0;
    }

}


@media(max-width:600px){

    .checkout-wrapper{
        width:94%;

        margin:25px auto;
    }


    .checkout-title{
        font-size:24px;

        margin-bottom:20px;
    }


    .checkout-card{
        padding:20px;

        border-radius:14px;
    }


    .form-grid{
        grid-template-columns:1fr;

        gap:14px;
    }


    .form-group.full{
        grid-column:auto;
    }


    .checkout-header{
        padding:15px 4%;
    }


    .logo{
        font-size:21px;
    }


    .secure-text{
        font-size:11px;
    }


    .cart-product{
        grid-template-columns:65px 1fr;

        gap:10px;
    }


    .cart-product img{
        width:65px;
        height:65px;
    }


    .cart-product-price{
        grid-column:2;
    }

}

</style>

</head>


<body>


<!-- =====================================================
     CHECKOUT HEADER
===================================================== -->

<header class="checkout-header">

    <div class="header-inner">

        <a
            href="index.php"
            class="logo"
        >
            Divine Healing World
        </a>


        <div class="secure-text">
            🔒 Secure Checkout
        </div>

    </div>

</header>


<!-- =====================================================
     MAIN
===================================================== -->

<main class="checkout-wrapper">




    <!-- =================================================
         EMPTY CART
    ================================================== -->

    <div class="empty-cart">

        <div class="empty-cart-icon">
            🛒
        </div>


        <h2>
            Your Cart is Empty
        </h2>


        <p>
            You haven't added any products to your cart yet.
        </p>


        <a
            href="products.php"
            class="continue-shopping"
        >

            Continue Shopping

            <span>
                →
            </span>

        </a>

    </div>




</main>


</body>
</html>


