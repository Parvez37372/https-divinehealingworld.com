
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Divinehealingworld
    </title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Playfair+Display:wght@500;600&display=swap"
        rel="stylesheet"
    >

    <style>

        :root {
            --purple: #382342;
            --dark-purple: #24142e;
            --pink: #b61491;
            --text: #302632;
            --muted: #817782;
            --border: #ebe7ec;
            --light: #faf8fb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "DM Sans", sans-serif;
            color: var(--text);
            background: #fff;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            font-family: inherit;
        }


        /* =========================
           TOP BAR
        ========================= */

        .top-bar {
            height: 29px;
            background: var(--pink);
            color: #fff;
            padding: 0 5.5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 10px;
        }

        .top-bar-item {
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .top-bar-item i {
            font-size: 11px;
        }


        /* =========================
           HEADER
        ========================= */

        .header {
            height: 78px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            position: relative;
            z-index: 1000;
        }

        .header-container {
            width: 89%;
            max-width: 1440px;
            height: 100%;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }


        /* LOGO */

        .logo {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 235px;
        }

        .logo-symbol {
            width: 43px;
            height: 43px;
            position: relative;
        }

        .logo-symbol img {
            width: 50px;
            height: -10px;
            object-fit: contain;
        }

        .logo-content h1 {
            font-family: "Playfair Display", serif;
            font-size: 25px;
            font-weight: 600;
            line-height: 1;
            color: var(--purple);
            letter-spacing: -0.5px;
        }

        .logo-content p {
            font-size: 10px;
            color: #77707b;
            margin-top: 4px;
            letter-spacing: .35px;
        }


        /* NAVIGATION */

        .navigation {
            height: 100%;
            display: flex;
            align-items: center;
            gap: 34px;
        }

        .nav-link {
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
            font-size: 12px;
            color: #302932;
            transition: color .25s ease;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 19px;
            width: 0;
            height: 2px;
            background: var(--purple);
            transition: width .3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            color: var(--purple);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .shop-link {
            gap: 6px;
        }

        .shop-link i {
            font-size: 8px;
        }


        /* SHOP DROPDOWN */

        .shop-dropdown {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
        }

        .shop-menu {
            display: none;
            list-style: none;
            padding: 8px 0;
            margin: 0;
            position: absolute;
            top: 100%;
            left: 0;
            min-width: 230px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 10px 28px rgba(36,20,46,.12);
            z-index: 9999;
        }

        .shop-dropdown:hover .shop-menu {
            display: block;
        }

        .shop-dropdown:hover .shop-link i {
            transform: rotate(180deg);
        }

        .shop-link i {
            transition: .25s ease;
        }

        .shop-menu li a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 11px 15px;
            color: #333;
            font-size: 13px;
            transition: .2s ease;
        }

        .shop-menu li a:hover {
            background: #faf5fb;
            color: var(--pink);
        }

        .shop-menu li a i {
            width: 17px;
            color: var(--purple);
            font-size: 12px;
        }


        /* HEADER ACTIONS */

        .header-actions {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .header-icon {
            border: 0;
            background: transparent;
            color: #302632;
            font-size: 17px;
            width: 20px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
        }

        .header-icon:hover {
            color: var(--purple);
        }

        .badge-icon span {
            position: absolute;
            top: -5px;
            right: -8px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--purple);
            color: #fff;
            font-size: 8px;
            font-weight: 600;
        }


        /* MOBILE */

        .mobile-menu-button {
            display: none;
            border: 0;
            background: transparent;
            font-size: 19px;
            color: var(--purple);
            cursor: pointer;
        }

        .mobile-navigation {
            display: none;
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 10px 5%;
            position: relative;
            z-index: 999;
            box-shadow: 0 8px 20px rgba(0,0,0,.06);
        }

        .mobile-navigation.show {
            display: block;
        }

        .mobile-navigation a {
            display: block;
            padding: 13px 5px;
            border-bottom: 1px solid #f0edf1;
            font-size: 13px;
        }

        .mobile-shop {
            border-bottom: 1px solid #f0edf1;
        }

        .mobile-shop-toggle {
            width: 100%;
            padding: 13px 5px;
            border: 0;
            background: transparent;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-family: inherit;
            font-size: 13px;
            color: #302932;
            cursor: pointer;
        }

        .mobile-shop-toggle i {
            font-size: 10px;
            transition: transform .25s ease;
        }

        .mobile-shop.open .mobile-shop-toggle i {
            transform: rotate(180deg);
        }

        .mobile-shop-menu {
            display: none;
            padding: 0 0 5px 14px;
        }

        .mobile-shop.open .mobile-shop-menu {
            display: block;
        }

        .mobile-shop-menu a {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 10px 5px;
            border-bottom: 0;
            font-size: 12px;
            color: #625a63;
        }

        .mobile-shop-menu i {
            width: 14px;
            font-size: 11px;
        }


        /* =========================
           SHOP PRODUCTS PAGE
        ========================= */


        .shop-heading {
            text-align: center;
            margin-bottom: 35px;
        }

        .shop-heading h2 {
            font-family: "Playfair Display", serif;
            font-size: 34px;
            color: var(--purple);
            margin-bottom: 8px;
        }

        .shop-heading p {
            color: var(--muted);
            font-size: 13px;
        }


        /* PRODUCT CARD */

        .products-list {
            display: grid;
            grid-template-columns: 1fr;
            gap: 18px;
        }

        .product-card {
            display: grid;
            grid-template-columns: 230px 1fr;
            gap: 25px;
            padding: 18px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            box-shadow: 0 7px 24px rgba(36,20,46,.05);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(36,20,46,.09);
        }

        .product-image-wrap {
            width: 230px;
            height: 230px;
            border-radius: 12px;
            overflow: hidden;
            background: #faf8fb;
        }

        .product-image-wrap img {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
        }

        .product-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 5px 10px 5px 0;
        }

        .product-title {
            color: var(--pink);
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 7px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .product-name {
            font-family: "Playfair Display", serif;
            color: var(--purple);
            font-size: 27px;
            font-weight: 600;
            margin-bottom: 11px;
        }

        .product-description {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.7;
            max-width: 700px;
            margin-bottom: 18px;
        }

        .product-bottom {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .product-price {
            color: var(--purple);
            font-size: 21px;
            font-weight: 700;
        }

        .add-cart-btn {
            border: 0;
            border-radius: 8px;
            padding: 11px 19px;
            background: var(--purple);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: .25s ease;
        }

        .add-cart-btn:hover {
            background: var(--pink);
        }

        .empty-products {
            text-align: center;
            padding: 55px 20px;
            border: 1px dashed #ddd5df;
            border-radius: 14px;
            color: var(--muted);
        }

        .empty-products i {
            font-size: 35px;
            color: #c7bdc9;
            margin-bottom: 12px;
        }

        .all-categories {
            display: flex;
            justify-content: center;
            gap: 9px;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .category-pill {
            padding: 8px 14px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 11px;
            color: var(--purple);
            background: #fff;
        }

        .category-pill:hover {
            background: #faf5fb;
            border-color: #d9c9dc;
        }


        /* RESPONSIVE */

        @media (max-width: 1000px) {

            .header-container {
                width: 92%;
            }

            .navigation {
                gap: 20px;
            }

            .nav-link {
                font-size: 11px;
            }

            .logo {
                min-width: 205px;
            }

            .logo-content h1 {
                font-size: 22px;
            }

            .header-actions {
                gap: 13px;
            }

            .shop-page {
                width: 92%;
            }

        }

        @media (max-width: 768px) {

            .top-bar {
                display: none;
            }

            .header {
                height: 70px;
            }

            .navigation {
                display: none;
            }

            .header-container {
                width: 92%;
            }

            .header-actions {
                gap: 13px;
            }

            .header-actions .header-icon:nth-child(1),
            .header-actions .header-icon:nth-child(2) {
                display: none;
            }

            .mobile-menu-button {
                display: flex;
            }

            .logo {
                min-width: auto;
            }

            .logo-content h1 {
                font-size: 21px;
            }

            .logo-content p {
                font-size: 7px;
            }

            .shop-page {
                width: 92%;
                padding-top: 38px;
            }

            .shop-heading h2 {
                font-size: 28px;
            }

            .product-card {
                grid-template-columns: 1fr;
                gap: 17px;
            }

            .product-image-wrap {
                width: 100%;
                height: 260px;
            }

            .product-info {
                padding: 0 4px 5px;
            }

            .product-name {
                font-size: 23px;
            }

        }

        @media (max-width: 420px) {

            .header-container {
                width: 90%;
            }

            .header-actions {
                gap: 9px;
            }

            .product-image-wrap {
                height: 230px;
            }

            .product-bottom {
                align-items: flex-start;
                flex-direction: column;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     TOP BAR
========================= -->

<!--<div class="top-bar">

    <div class="top-bar-item">
        <i class="fa-solid fa-truck"></i>
        <span>Free Shipping All Over India</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-regular fa-gem"></i>
        <span>100% Natural & Authentic Crystals</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-solid fa-shield-halved"></i>
        <span>Easy Returns & Secure Payments</span>
    </div>

</div>-->


<!-- =========================
     HEADER
========================= -->

<header class="header">

    <div class="header-container">


        <a href="https://divinehealingworld.com/" class="logo">

            <div class="logo-symbol">

                <img
                    src="https://vectorjungal.com/files/preview/1280x977/11724061489x7dnzumlkkkdctwc1jp9s6hmcc7hkelbcywsoq1ks90ylksgcvupex8nfc0knms8robegbblqtofo2ckk2viwtbtpyhxqomm1o4i.png"
                    alt="Divinehealingworld"
                >

            </div>

            <div class="logo-content">

                <h1>Divine Healing world</h1>

                <p>Nature's Energy. Your Style</p>

            </div>

        </a>


        <nav class="navigation">

            <a href="https://divinehealingworld.com/" class="nav-link">
                Home
            </a>
<a href="/reiki-healing.php" class="nav-link">
                Reiki Healing
            

            <a href="/tarot-reading.php" class="nav-link">
                Tarot Reading
            </a>

            <a href="/akashic-records.php" class="nav-link">
                Akashic Records
            </a>

            <a href="/animal-communication.php" class="nav-link">
                Animal Communication
            </a>

  <a href="/psychic-mediumship.php" class="nav-link">
                Psychic Mediumship
            </a>                          <div class="shop-dropdown">

              <!---  <a
                    href="#"
                    class="nav-link shop-link "
                    aria-haspopup="true"
                >
                    Shop
                    <i class="fa-solid fa-chevron-down"></i>
                </a>


                <ul class="shop-menu">
                    /
                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=3"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Crystals
                                </a>

                            </li>

                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=4"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Rings
                                </a>

                            </li>

                        
                    
                </ul>---->

            </div>


        </nav>


        <div class="header-actions">
         <style>
         .session-btn
         {
             background:black;
             color:#fff;
             font-size:15px;
             font-weight:bold;
             border:solid 1px white;
             padding:10px;
             border-radius:15px;
         }
         
         </style>
            <button class="session-btn"><a href="book-your-session.php">Book Session</a></button>
        </div>

    </div>

</header>


<!-- =========================
     MOBILE NAV
========================= -->

<nav
    class="mobile-navigation"
    id="mobileNavigation"
>

    <a href="index.php">
        Home
    </a>


    <div class="mobile-shop">

        <button
            type="button"
            class="mobile-shop-toggle"
            id="mobileShopToggle"
        >

            <span>
                Shop
            </span>

            <i class="fa-solid fa-chevron-down"></i>

        </button>


        <div
            class="mobile-shop-menu"
            id="mobileShopMenu"
        >

            <a href="products.php">

                <i class="fa-solid fa-box"></i>

                Products

            </a>


            <a href="best-sellers.php">

                <i class="fa-solid fa-star"></i>

                Best Sellers

            </a>


            
                <a
                    href="shop-category-products.php?category_id=3"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Crystals
                </a>

            
                <a
                    href="shop-category-products.php?category_id=4"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Rings
                </a>

            
        </div>

    </div>


    <a href="about.php">
        About Us
    </a>

    <a href="#">
        Tarot Reading
    </a>

    <a href="#">
        Akashic Records
    </a>

    <a href="#">
        Animal Communication
    </a>

</nav>


<!-- =========================
     PRODUCTS
========================= -->

<main class="shop-page">

    

</main>


<script>

    /* =========================
       MOBILE MENU
    ========================= */

    const menuButton =
        document.getElementById("menuButton");

    const mobileNavigation =
        document.getElementById("mobileNavigation");

    const menuIcon =
        menuButton
            ? menuButton.querySelector("i")
            : null;


    if (
        menuButton &&
        mobileNavigation &&
        menuIcon
    ) {

        menuButton.addEventListener("click", () => {

            mobileNavigation.classList.toggle("show");

            if (
                mobileNavigation.classList.contains("show")
            ) {

                menuIcon.classList.remove("fa-bars");
                menuIcon.classList.add("fa-xmark");

            } else {

                menuIcon.classList.remove("fa-xmark");
                menuIcon.classList.add("fa-bars");

            }

        });

    }


    /* =========================
       MOBILE SHOP
    ========================= */

    const mobileShopToggle =
        document.getElementById("mobileShopToggle");

    const mobileShop =
        document.querySelector(".mobile-shop");


    if (
        mobileShopToggle &&
        mobileShop
    ) {

        mobileShopToggle.addEventListener(
            "click",
            function () {

                mobileShop.classList.toggle("open");

            }
        );

    }


    /* =========================
       ADD TO CART
       UI READY
    ========================= */

    document
        .querySelectorAll(".add-cart-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                function () {

                    const productName =
                        this.dataset.productName || "Product";

                    alert(
                        productName +
                        " added to cart."
                    );

                }
            );

        });


    /* =========================
       CLOSE MOBILE MENU
    ========================= */

    document
        .querySelectorAll(".mobile-navigation a")
        .forEach(link => {

            link.addEventListener(
                "click",
                function () {

                    if (mobileNavigation) {
                        mobileNavigation.classList.remove("show");
                    }

                    if (menuIcon) {

                        menuIcon.classList.remove("fa-xmark");
                        menuIcon.classList.add("fa-bars");

                    }

                    if (mobileShop) {
                        mobileShop.classList.remove("open");
                    }

                }
            );

        });

</script>

</body>
</html>

<main class="reiki-page">

<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap');

.reiki-page{
    --purple:#301745;
    --purple-light:#51406d;
    --gold:#d2a15e;
    --cream:#fcf8f3;
    --text:#514b58;
    font-family:'DM Sans',sans-serif;
    color:var(--text);
    background:#fffdfa;
    overflow:hidden;
}
.reiki-page *{box-sizing:border-box}
.reiki-page img{display:block;width:100%;object-fit:cover}
.reiki-page h1,.reiki-page h2,.reiki-page h3{
    font-family:'Playfair Display',serif;
    color:var(--purple);
    line-height:1.25;
    margin:0 0 15px;
}
.reiki-page p{font-size:14px;line-height:1.85;margin:0 0 14px}
.reiki-page a{text-decoration:none}
.reiki-page .rk-container{width:min(1200px,92%);margin:auto}
.reiki-page .rk-label{
    display:block;color:var(--gold);font-size:11px;font-weight:700;
    letter-spacing:3px;text-transform:uppercase;margin-bottom:12px
}
.reiki-page .rk-heading{text-align:center;max-width:780px;margin:0 auto 38px}
.reiki-page .rk-heading h2{font-size:clamp(28px,3.3vw,39px)}
.reiki-page .rk-heading p{max-width:680px;margin:auto}
.reiki-page .rk-btn{
    display:inline-flex;justify-content:center;align-items:center;gap:12px;
    background:var(--gold);color:#281630;padding:15px 25px;border-radius:50px;
    font-size:13px;font-weight:700;transition:.3s ease
}
.reiki-page .rk-btn:hover{background:#f2d18f;transform:translateY(-3px);box-shadow:0 10px 25px #0002}
.reiki-page .rk-btn-dark{color:#fff;background:var(--purple)}
.reiki-page .rk-btn-dark:hover{background:#513365}
.reiki-page .rk-reveal{opacity:0;transform:translateY(30px);transition:opacity .8s ease,transform .8s ease}
.reiki-page .rk-reveal.rk-show{opacity:1;transform:translateY(0)}
.reiki-page .rk-delay1{transition-delay:.12s}
.reiki-page .rk-delay2{transition-delay:.24s}
.reiki-page .rk-delay3{transition-delay:.36s}
@keyframes rk-enter{from{opacity:0;transform:translateY(25px)}to{opacity:1;transform:translateY(0)}}
@keyframes rk-float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}

/* HERO */
.reiki-page .rk-hero{
    min-height:490px;display:flex;align-items:center;position:relative;
    background:linear-gradient(90deg,rgba(21,10,30,.94) 0%,rgba(34,17,43,.78) 48%,rgba(24,12,30,.12) 100%),
    url('reikibanner.jpg') center 48%/cover no-repeat
}
.reiki-page .rk-hero-content{max-width:680px;padding:70px 0;position:relative;z-index:1;animation:rk-enter 1s ease both}
.reiki-page .rk-hero h1{color:#fff;font-size:clamp(36px,5vw,58px);margin-bottom:17px}
.reiki-page .rk-hero h1 span{color:#f2c77b}
.reiki-page .rk-hero h2{color:#f5d49a;font:500 clamp(17px,2vw,22px)/1.6 'DM Sans',sans-serif}
.reiki-page .rk-hero p{color:#f1eaf3;max-width:580px;margin-bottom:25px}
.reiki-page .rk-hero .rk-label{color:#f2ca86}

/* INTRO */
.reiki-page .rk-intro{padding:78px 0;background:var(--cream)}
.reiki-page .rk-intro-grid{display:grid;grid-template-columns:1fr 1.05fr;gap:55px;align-items:center}
.reiki-page .rk-image-frame{position:relative}
.reiki-page .rk-intro-img{height:390px;border-radius:12px;position:relative;z-index:1;box-shadow:0 15px 35px #30174519}
.reiki-page .rk-image-frame:before{content:"";position:absolute;border:2px solid var(--gold);width:100px;height:100px;top:-12px;left:-12px;border-radius:12px}
.reiki-page .rk-intro h2{font-size:clamp(27px,3vw,38px)}
.reiki-page .rk-intro .rk-label,.reiki-page .rk-why .rk-label{color:#9b7954}
.reiki-page .rk-benefits{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-top:24px}
.reiki-page .rk-benefit{display:flex;align-items:center;gap:11px;padding:13px;border-radius:9px;background:#fff;border:1px solid #eee5e8;font-size:12px;font-weight:600}
.reiki-page .rk-benefit-icon{flex-shrink:0;display:grid;place-items:center;width:37px;height:37px;border-radius:50%;background:#f5e8d8;color:#8d6439;font-size:19px}

/* WHAT IS REIKI */
.reiki-page .rk-about{padding:76px 0;background:#fffdfa}
.reiki-page .rk-about-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:48px;align-items:center}
.reiki-page .rk-about-img{height:390px;border-radius:12px;box-shadow:0 15px 35px #30174518}
.reiki-page .rk-about h2{font-size:clamp(28px,3vw,39px)}
.reiki-page .rk-note{padding:17px 20px;background:#f7f0e7;border-left:3px solid var(--gold);border-radius:0 9px 9px 0;margin-top:18px;font-size:13px;line-height:1.8}

/* BENEFITS */
.reiki-page .rk-benefit-section{padding:78px 0;background:#f5eff5}
.reiki-page .rk-benefit-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.reiki-page .rk-benefit-card{background:#fff;border:1px solid #eee5ed;border-radius:12px;padding:26px 22px;transition:.3s ease}
.reiki-page .rk-benefit-card:hover{transform:translateY(-7px);box-shadow:0 15px 30px #30174514}
.reiki-page .rk-benefit-card .rk-card-icon{width:50px;height:50px;display:grid;place-items:center;border-radius:50%;background:#f5e8d8;color:#8d6439;font-size:23px;margin-bottom:17px}
.reiki-page .rk-benefit-card h3{font-size:19px;margin-bottom:9px}
.reiki-page .rk-benefit-card p{font-size:12px;margin:0}

/* CHAKRAS */
.reiki-page .rk-chakras{padding:78px 0;background:#fffdfa}
.reiki-page .rk-chakra-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.reiki-page .rk-chakra{display:flex;align-items:flex-start;gap:14px;padding:20px;border:1px solid #eee6ec;border-radius:11px;background:#fff;transition:.3s}
.reiki-page .rk-chakra:hover{transform:translateY(-5px);box-shadow:0 12px 25px #30174510}
.reiki-page .rk-chakra-dot{width:18px;height:18px;flex-shrink:0;border-radius:50%;margin-top:4px;box-shadow:0 0 0 5px #00000008}
.reiki-page .rk-chakra h3{font-size:17px;margin-bottom:5px}
.reiki-page .rk-chakra p{font-size:12px;margin:0}
.rk-root{background:#b84b4b}.rk-sacral{background:#e98a43}.rk-solar{background:#e5c34d}.rk-heart{background:#65a978}.rk-throat{background:#58a9c9}.rk-third{background:#596bb5}.rk-crown{background:#9873bd}

/* WHY */
.reiki-page .rk-why{padding:78px 0;background:var(--cream)}
.reiki-page .rk-why-grid{display:grid;grid-template-columns:.9fr 1.1fr;gap:55px;align-items:center}
.reiki-page .rk-why-img{height:400px;border-radius:12px;box-shadow:0 15px 35px #30174518}
.reiki-page .rk-why h2{font-size:clamp(28px,3vw,39px)}
.reiki-page .rk-why-list{display:grid;gap:14px;margin-top:24px}
.reiki-page .rk-why-item{display:flex;align-items:flex-start;gap:14px;padding:15px;background:#fff;border-radius:10px;border:1px solid #eee5ed;transition:transform .3s}
.reiki-page .rk-why-item:hover{transform:translateX(5px)}
.reiki-page .rk-check{flex-shrink:0;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:#f3e5ce;color:#72502d;font-weight:700}
.reiki-page .rk-why-item h3{font-size:16px;margin-bottom:4px}
.reiki-page .rk-why-item p{font-size:12px;margin:0}

/* PROCESS */
.reiki-page .rk-process{padding:78px 0;background:linear-gradient(110deg,#21172fef,#4c345bef),url('https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1600&q=80') center/cover}
.reiki-page .rk-process h2{color:#fff}
.reiki-page .rk-process .rk-heading p{color:#eee6f2}
.reiki-page .rk-process .rk-label{color:#f1ce91}
.reiki-page .rk-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:25px}
.reiki-page .rk-step{text-align:center;padding:30px 22px;border:1px solid #ffffff2b;border-radius:12px;background:#ffffff0b;transition:.3s}
.reiki-page .rk-step:hover{background:#ffffff15;transform:translateY(-7px)}
.reiki-page .rk-step-icon{width:68px;height:68px;display:grid;place-items:center;margin:0 auto 20px;background:#fff;color:var(--purple);border-radius:50%;font-size:26px;animation:rk-float 4s ease-in-out infinite}
.reiki-page .rk-step h3{font-size:21px;color:#f2d39c}
.reiki-page .rk-step p{color:#eee6f2;font-size:13px}

/* FAQ */
.reiki-page .rk-faq{padding:76px 0;background:#fffdfa}
.reiki-page .rk-faq-list{max-width:850px;margin:auto;display:grid;gap:13px}
.reiki-page .rk-faq details{padding:18px 21px;border:1px solid #eee5ed;border-radius:10px;background:#fff}
.reiki-page .rk-faq summary{cursor:pointer;color:var(--purple);font-weight:700;font-size:14px}
.reiki-page .rk-faq details p{font-size:13px;margin:12px 0 0}

/* CTA */
.reiki-page .rk-cta{padding:78px 0;background:linear-gradient(90deg,rgba(20,11,29,.94),rgba(40,21,45,.72)),url('https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1800&q=85') center/cover no-repeat}
.reiki-page .rk-cta-inner{max-width:780px;margin:auto;text-align:center}
.reiki-page .rk-cta h2{color:#fff;font-size:clamp(30px,4vw,45px)}
.reiki-page .rk-cta p{color:#f2eaf3;max-width:650px;margin:0 auto 25px}
.reiki-page .rk-cta .rk-label{color:#f2ce8c}
.reiki-page .rk-disclaimer{padding:20px 0;background:#f7f2ec;text-align:center}
.reiki-page .rk-disclaimer p{font-size:11px;max-width:950px;margin:auto;color:#756b78}

/* RESPONSIVE */
@media(max-width:1000px){
    .reiki-page .rk-benefit-grid{grid-template-columns:repeat(2,1fr)}
    .reiki-page .rk-chakra-grid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:650px){
    .reiki-page .rk-container{width:90%}
    .reiki-page .rk-hero{min-height:490px;background-position:63% center}
    .reiki-page .rk-hero h1{font-size:36px}
    .reiki-page .rk-hero h2{font-size:16px}
    .reiki-page .rk-hero p{font-size:13px}
    .reiki-page .rk-intro,.reiki-page .rk-about,.reiki-page .rk-benefit-section,
    .reiki-page .rk-chakras,.reiki-page .rk-why,.reiki-page .rk-process,
    .reiki-page .rk-faq,.reiki-page .rk-cta{padding:52px 0}
    .reiki-page .rk-intro-grid,.reiki-page .rk-about-grid,.reiki-page .rk-why-grid{grid-template-columns:1fr;gap:30px}
    .reiki-page .rk-intro-img,.reiki-page .rk-about-img,.reiki-page .rk-why-img{height:270px}
    .reiki-page .rk-benefits{grid-template-columns:1fr}
    .reiki-page .rk-benefit-grid,.reiki-page .rk-chakra-grid,.reiki-page .rk-steps{grid-template-columns:1fr;gap:14px}
    .reiki-page .rk-step{padding:25px 20px}
}
@media(prefers-reduced-motion:reduce){
    .reiki-page *,.reiki-page *:before,.reiki-page *:after{animation-duration:.01ms!important;transition-duration:.01ms!important}
    .reiki-page .rk-reveal{opacity:1;transform:none}
}
</style>

<!-- HERO -->
<section class="rk-hero">
    <div class="rk-container">
        <div class="rk-hero-content">
            <span class="rk-label">Reiki Healing · Divine Healing World</span>
            <h1>Reiki Healing – <span>Reconnect With Your Inner Balance</span></h1>
            <h2>A Gentle Journey Towards Calmness, Awareness &amp; Well-Being</h2>
            <p>Take a mindful pause from the demands of everyday life. Explore Reiki as a gentle, complementary wellness practice that may support relaxation, self-awareness, and a sense of emotional balance.</p>
            <a href="#rk-booking" class="rk-btn">Explore Reiki Healing <span>→</span></a>
        </div>
    </div>
</section>

<!-- INTRODUCTION -->
<section class="rk-intro">
    <div class="rk-container rk-intro-grid">
        <div class="rk-image-frame rk-reveal">
            <img class="rk-intro-img" src="https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=1000&q=85" alt="Peaceful meditation and wellness space" loading="lazy">
        </div>
        <div class="rk-reveal rk-delay1">
            <span class="rk-label">A Moment For Yourself</span>
            <h2>Give Yourself Space to Pause, Relax &amp; Rebalance</h2>
            <p>Life can sometimes feel overwhelming. Stress, busy routines, and emotional challenges can make it difficult to slow down and reconnect with yourself. Reiki sessions offer a calm, supportive setting where you can take time for rest and mindful awareness.</p>
            <p>At <strong>Divine Healing World</strong>, each session is approached with care and respect for your individual comfort. The experience is intended to complement your personal wellness journey, not replace medical care or professional treatment.</p>
            <div class="rk-benefits">
                <div class="rk-benefit"><span class="rk-benefit-icon">✧</span>Relaxing Environment</div>
                <div class="rk-benefit"><span class="rk-benefit-icon">♡</span>Compassionate Approach</div>
                <div class="rk-benefit"><span class="rk-benefit-icon">◎</span>Personalised Session</div>
                <div class="rk-benefit"><span class="rk-benefit-icon">☼</span>Mindful Self-Care</div>
            </div>
        </div>
    </div>
</section>

<!-- WHAT IS REIKI -->
<section class="rk-about">
    <div class="rk-container rk-about-grid">
        <div class="rk-reveal">
            <span class="rk-label">Understanding Reiki</span>
            <h2>What Is Reiki Healing?</h2>
            <p>Reiki is a Japanese complementary wellness practice. The word is commonly explained through two Japanese terms: <strong>Rei</strong>, meaning universal or spiritual, and <strong>Ki</strong>, meaning life energy.</p>
            <p>During a Reiki session, a practitioner places their hands lightly on or just above the body, following the recipient's comfort and consent. Some sessions may also be offered without physical touch. The experience is generally quiet and calming, allowing the person to rest and focus on their own sense of well-being.</p>
            <p>Reiki is based on a traditional belief in the flow of life energy. Scientific evidence has not established that this energy can be measured or that Reiki can treat or cure medical conditions. People may nevertheless choose it as a complementary relaxation practice.</p>
            <div class="rk-note"><strong>In simple words:</strong> Reiki is a gentle, hands-on or hands-near wellness practice that creates time for relaxation and self-reflection. Your experience may be different from someone else's.</div>
        </div>
        <div class="rk-reveal rk-delay1">
            <img class="rk-about-img" src="https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1000&q=85" alt="Person practising mindful yoga and relaxation" loading="lazy">
        </div>
    </div>
</section>

<!-- HOW IT MAY HELP -->
<section class="rk-benefit-section">
    <div class="rk-container">
        <div class="rk-heading rk-reveal">
            <span class="rk-label">Reiki &amp; Your Wellness Journey</span>
            <h2>How Can Reiki Support Your Well-Being?</h2>
            <p>Reiki is often chosen as a complementary practice for the quiet time and relaxation it offers. It is not a guaranteed treatment, and individual experiences vary.</p>
        </div>
        <div class="rk-benefit-grid">
            <article class="rk-benefit-card rk-reveal">
                <div class="rk-card-icon">☁</div>
                <h3>Relaxation &amp; Calm</h3>
                <p>A peaceful session may help you slow down, take a break from daily demands, and enjoy a quiet moment for yourself.</p>
            </article>
            <article class="rk-benefit-card rk-reveal rk-delay1">
                <div class="rk-card-icon">♡</div>
                <h3>Emotional Reflection</h3>
                <p>The session can provide personal space to notice your feelings and reflect on what you may need emotionally.</p>
            </article>
            <article class="rk-benefit-card rk-reveal rk-delay2">
                <div class="rk-card-icon">☾</div>
                <h3>Mindful Rest</h3>
                <p>A calm environment and dedicated pause may help you practise stillness and become more aware of the present moment.</p>
            </article>
            <article class="rk-benefit-card rk-reveal">
                <div class="rk-card-icon">✧</div>
                <h3>Self-Awareness</h3>
                <p>Use the time to reconnect with your thoughts, personal intentions, and your own approach to self-care.</p>
            </article>
            <article class="rk-benefit-card rk-reveal rk-delay1">
                <div class="rk-card-icon">◎</div>
                <h3>Personal Wellness Time</h3>
                <p>Make room in your routine for a supportive experience focused on comfort, rest, and personal well-being.</p>
            </article>
            <article class="rk-benefit-card rk-reveal rk-delay2">
                <div class="rk-card-icon">☼</div>
                <h3>A Complementary Practice</h3>
                <p>Some people include Reiki alongside other wellness activities as part of a broader self-care routine.</p>
            </article>
        </div>
    </div>
</section>

<!-- CHAKRAS -->
<section class="rk-chakras">
    <div class="rk-container">
        <div class="rk-heading rk-reveal">
            <span class="rk-label">Explore The Chakra Tradition</span>
            <h2>Reiki &amp; The Seven Chakras</h2>
            <p>In some Reiki and holistic wellness traditions, chakras are described as energy centres. These descriptions are part of spiritual traditions, not medically established body systems.</p>
        </div>
        <div class="rk-chakra-grid">
            <div class="rk-chakra rk-reveal"><span class="rk-chakra-dot rk-root"></span><div><h3>1. Root Chakra</h3><p>Traditionally associated with grounding, stability, and a sense of security.</p></div></div>
            <div class="rk-chakra rk-reveal rk-delay1"><span class="rk-chakra-dot rk-sacral"></span><div><h3>2. Sacral Chakra</h3><p>Traditionally associated with creativity, feelings, and emotional expression.</p></div></div>
            <div class="rk-chakra rk-reveal rk-delay2"><span class="rk-chakra-dot rk-solar"></span><div><h3>3. Solar Plexus Chakra</h3><p>Traditionally associated with confidence, motivation, and personal power.</p></div></div>
            <div class="rk-chakra rk-reveal"><span class="rk-chakra-dot rk-heart"></span><div><h3>4. Heart Chakra</h3><p>Traditionally associated with love, compassion, and connection.</p></div></div>
            <div class="rk-chakra rk-reveal rk-delay1"><span class="rk-chakra-dot rk-throat"></span><div><h3>5. Throat Chakra</h3><p>Traditionally associated with communication and authentic expression.</p></div></div>
            <div class="rk-chakra rk-reveal rk-delay2"><span class="rk-chakra-dot rk-third"></span><div><h3>6. Third Eye Chakra</h3><p>Traditionally associated with intuition, insight, and inner reflection.</p></div></div>
            <div class="rk-chakra rk-reveal"><span class="rk-chakra-dot rk-crown"></span><div><h3>7. Crown Chakra</h3><p>Traditionally associated with spiritual connection and awareness.</p></div></div>
        </div>
    </div>
</section>

<!-- WHY CHOOSE US -->
<section class="rk-why">
    <div class="rk-container rk-why-grid">
        <div class="rk-reveal">
            <img class="rk-why-img" src="https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=1000&q=85" alt="Peaceful meditation space" loading="lazy">
        </div>
        <div class="rk-reveal rk-delay1">
            <span class="rk-label">Your Comfort Comes First</span>
            <h2>Why Explore Reiki With Divine Healing World?</h2>
            <p>We aim to make every session a welcoming and respectful experience. Your comfort, boundaries, and personal preferences matter throughout the process.</p>
            <div class="rk-why-list">
                <div class="rk-why-item"><div class="rk-check">✓</div><div><h3>A Calm &amp; Supportive Space</h3><p>Take time away from everyday distractions in a peaceful setting.</p></div></div>
                <div class="rk-why-item"><div class="rk-check">✓</div><div><h3>Respect For Your Comfort</h3><p>Touch is never assumed. Your consent and preferences guide the session.</p></div></div>
                <div class="rk-why-item"><div class="rk-check">✓</div><div><h3>Personalised Attention</h3><p>Time to discuss what you hope to get from the session and ask questions.</p></div></div>
                <div class="rk-why-item"><div class="rk-check">✓</div><div><h3>No Promises Or Pressure</h3><p>We respect your choices and do not promise cures, diagnoses, or guaranteed outcomes.</p></div></div>
            </div>
        </div>
    </div>
</section>

<!-- SESSION PROCESS -->
<section class="rk-process">
    <div class="rk-container">
        <div class="rk-heading rk-reveal">
            <span class="rk-label">Your Reiki Experience</span>
            <h2>What Happens During A Reiki Session?</h2>
            <p>Every session can be adapted to your comfort. Here is a simple overview of what you can generally expect.</p>
        </div>
        <div class="rk-steps">
            <article class="rk-step rk-reveal">
                <div class="rk-step-icon">☏</div>
                <h3>1. Connect &amp; Discuss</h3>
                <p>We begin with a conversation about your expectations, comfort, and any questions you may have.</p>
            </article>
            <article class="rk-step rk-reveal rk-delay1">
                <div class="rk-step-icon">☁</div>
                <h3>2. Relax &amp; Receive</h3>
                <p>You remain comfortably seated or lying down, while the practitioner uses a gentle hands-on or hands-near approach with your consent.</p>
            </article>
            <article class="rk-step rk-reveal rk-delay2">
                <div class="rk-step-icon">✧</div>
                <h3>3. Reflect &amp; Close</h3>
                <p>After the session, you have time to sit up, share your experience if you wish, and return to your day at your own pace.</p>
            </article>
        </div>
    </div>
</section>

<!-- FAQ -->
<section class="rk-faq">
    <div class="rk-container">
        <div class="rk-heading rk-reveal">
            <span class="rk-label">Frequently Asked Questions</span>
            <h2>Questions About Reiki Healing</h2>
            <p>Some helpful information before you decide whether a session is right for you.</p>
        </div>
        <div class="rk-faq-list">
            <details class="rk-reveal"><summary>Is Reiki a medical treatment?</summary><p>No. Reiki is considered a complementary wellness practice, not a medical treatment. It should not replace medical advice, diagnosis, medication, or treatment from a qualified healthcare professional.</p></details>
            <details class="rk-reveal"><summary>Do I need to believe in Reiki for a session?</summary><p>You do not need to follow a particular belief system. You can simply approach the session as a quiet wellness experience and decide whether it feels comfortable for you.</p></details>
            <details class="rk-reveal"><summary>Does Reiki involve physical touch?</summary><p>Some practitioners use light touch, while others work with their hands just above the body. Your consent and comfort should always be discussed before the session.</p></details>
            <details class="rk-reveal"><summary>How will I feel after a Reiki session?</summary><p>Experiences differ. Some people describe feeling relaxed, while others may notice no particular change. No specific result can be guaranteed.</p></details>
            <details class="rk-reveal"><summary>Can Reiki cure an illness or health condition?</summary><p>Reiki has not been established as a cure for illnesses or medical conditions. Please continue appropriate medical care and speak with your healthcare professional about health concerns.</p></details>
        </div>
    </div>
</section>

<!-- BOOKING CTA -->
<section class="rk-cta" id="rk-booking">
    <div class="rk-container">
        <div class="rk-cta-inner rk-reveal">
            <span class="rk-label">Make Time For Your Well-Being</span>
            <h2>Your Moment Of Calm Starts Here</h2>
            <p>Give yourself permission to pause, breathe, and explore a gentle wellness experience. Connect with Divine Healing World to ask questions or arrange a Reiki Healing session.</p>
            <!-- Replace # with your actual booking/contact page URL -->
            <a href="contact.php" class="rk-btn">Book Your Reiki Healing Session <span>→</span></a>
        </div>
    </div>
</section>

<section class="rk-disclaimer">
    <div class="rk-container">
        <p><strong>Important note:</strong> Reiki is a complementary wellness practice. It is not a substitute for professional medical care and is not intended to diagnose, treat, or cure any disease or health condition. Scientific evidence for specific health benefits remains limited. Individual experiences may vary.</p>
    </div>
</section>

</main>

<script>
(function () {
    const page = document.querySelector('.reiki-page');
    if (!page) return;

    const revealItems = page.querySelectorAll('.rk-reveal');

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('rk-show');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });

        revealItems.forEach(function (item) { observer.observe(item); });
    } else {
        revealItems.forEach(function (item) { item.classList.add('rk-show'); });
    }

    page.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener('click', function (event) {
            const href = link.getAttribute('href');
            if (!href || href === '#') return;
            const target = page.querySelector(href);
            if (target) {
                event.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
})();
</script>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Divinehealingworld - Customer Reviews</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

html{
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background:#fff;
    color:#29202f;
    overflow-x:hidden;
}

button,
input{
    font-family:inherit;
}

.container{
    width:92%;
    max-width:1180px;
    margin:auto;
}

/* =========================
   BENEFITS
========================= */

.benefits-section{
    padding:16px 0 10px;
}

.benefits-box{
    width:92%;
    max-width:1200px;
    margin:auto;

    background:linear-gradient(
        120deg,
        #faf7f5,
        #fff,
        #faf7f5
    );

    border-radius:10px;

    box-shadow:
        0 5px 25px rgba(45,20,55,.04);

    display:grid;
    grid-template-columns:repeat(4,1fr);

    overflow:hidden;

    animation:fadeDown .8s ease;
}

.benefit{
    min-height:74px;

    display:flex;
    align-items:center;
    gap:13px;

    padding:10px 25px;

    border-right:1px solid #d9d2d8;

    transition:.35s ease;
}

.benefit:last-child{
    border-right:none;
}

.benefit:hover{
    background:#fff;
    transform:translateY(-2px);
}

.benefit-icon{
    width:40px;
    height:40px;

    border:1.5px solid #392443;
    border-radius:50%;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:18px;

    flex-shrink:0;

    transition:.4s ease;
}

.benefit:hover .benefit-icon{
    transform:rotate(360deg);
    background:#3b2546;
    color:#fff;
}

.benefit h4{
    font-size:11px;
    font-weight:600;
    margin-bottom:1px;
}

.benefit p{
    font-size:8px;
    color:#777;
}

/* =========================
   TESTIMONIAL
========================= */

.testimonial-section{
    padding:18px 0 18px;
}

.section-title{
    text-align:center;
    margin-bottom:15px;

    animation:fadeUp .8s ease;
}

.section-title h2{
    font-family:'DM Serif Display',serif;
    font-size:28px;
    font-weight:400;
    color:#33203e;
}

.section-title p{
    font-size:18px;
    color:#777;
    margin-top:1px;
}

/* =========================
   REVIEWS
========================= */

.reviews{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:14px;
}

.review-card{
    border:1px solid #e2dfe2;
    border-radius:5px;

    padding:11px 15px;

    min-height:108px;

    background:#fff;

    transition:
        transform .35s ease,
        box-shadow .35s ease,
        border-color .35s ease;

    opacity:0;
    transform:translateY(30px);
}

.review-card.show{
    opacity:1;
    transform:translateY(0);
}

.review-card:hover{
    transform:translateY(-6px);
    border-color:#c9b6d0;

    box-shadow:
        0 12px 30px rgba(54,30,65,.10);
}

.review-top{
    display:flex;
    align-items:center;
    gap:10px;
}

.avatar{
    width:42px;
    height:42px;

    border-radius:50%;
    overflow:hidden;

    flex-shrink:0;

    background:linear-gradient(
        135deg,
        #eee,
        #ddd
    );
}

.avatar img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.stars{
    color:#e4a719;
    font-size:18px;
    letter-spacing:1px;
    margin-bottom:3px;
}

.review-text{
    font-size:12px;
    color:#4d4d4d;
    line-height:1.55;

    margin-top:8px;
}

.customer{
    margin-top:7px;
    font-size:12px;
    font-weight:600;
}

.customer-location{
    font-size:10px;
    color:#777;
    margin-top:1px;
}

/* =========================
   COMMUNITY
========================= */

.community{
    position:relative;

    background:
        linear-gradient(
            135deg,
            #684c72,
            #795a83,
            #67476e
        );

    min-height:98px;

    overflow:hidden;

    color:#fff;

    display:flex;
    justify-content:center;
    align-items:center;

    text-align:center;

    margin-top:0;
}

.community-content{
    position:relative;
    z-index:2;
}

.community h2{
    font-family:'DM Serif Display',serif;
    font-weight:400;
    font-size:25px;
}

.community p{
    font-size:15px;
    opacity:.85;
    margin:2px 0 8px;
}

.subscribe{
    display:flex;
    width:450px;
    height:40px;
    margin:auto;

    background:#fff;
    border-radius:20px;

    overflow:hidden;

    box-shadow:
        0 4px 15px rgba(0,0,0,.12);

    transition:.3s;
}

.subscribe:focus-within{
    transform:scale(1.03);
}

.subscribe input{
    flex:1;
    min-width:0;

    border:none;
    outline:none;

    padding:0 12px;

    font-size:15px;
    color:#444;
}

.subscribe button{
    border:none;

    width:100px;

    background:#28192f;
    color:#fff;

    font-size:15px;

    cursor:pointer;

    transition:.3s;
}

.subscribe button:hover{
    background:#170e1b;
}

/* Floating crystals */

.crystal{
    position:absolute;
    width:45px;
    height:45px;

    opacity:.25;

    border:1px solid #fff;

    transform:rotate(35deg);

    animation:floatCrystal 4s ease-in-out infinite;
}

.crystal::before{
    content:"";
    position:absolute;
    inset:8px;

    border:1px solid #fff;

    transform:rotate(45deg);
}

.crystal.one{
    left:15%;
    top:16px;
}

.crystal.two{
    right:15%;
    top:20px;
    width:35px;
    height:35px;

    animation-delay:1s;
}

.crystal.three{
    right:11%;
    top:43px;
    width:20px;
    height:20px;

    animation-delay:2s;
}

/* =========================
   FOOTER
========================= */

footer{
    background:
        linear-gradient(
            135deg,
            #20142a,
            #2b1936,
            #1d1325
        );

    color:#fff;

    padding:12px 0 8px;
}

.footer-container{
    width:100%;
    max-width:1200px;
    margin:auto;

    display:grid;

    grid-template-columns:
        1.7fr
        1fr
        1fr
        1.15fr;

    gap:30px;
}

/* Logo */

.footer-logo{
    display:flex;
    align-items:center;
    gap:7px;
}

.logo-icon{
    font-size:30px;
    line-height:1;
}

.footer-logo h2{
    font-family:'DM Serif Display',serif;
    font-size:23px;
    font-weight:400;
}

.footer-logo span{
    display:block;
    font-size:12px;
    color:#ddd;
    letter-spacing:.5px;
}

.footer-about p{
    font-size:10px;
    line-height:1.7;

    color:#d4ccd8;

    max-width:280px;

    margin-top:8px;
}

/* Social */

.socials{
    display:flex;
    gap:13px;
    margin-top:9px;
}

.socials a{
    color:#fff;
    text-decoration:none;

    font-size:20px;

    width:18px;
    height:18px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    transition:.3s;
}

.socials a:hover{
    background:#fff;
    color:#28182f;
    transform:translateY(-3px);
}

/* Footer columns */

.footer-column h3{
    font-size:15px;
    font-weight:500;

    margin-bottom:8px;
}

.footer-column ul{
    list-style:none;
}

.footer-column li{
    margin-bottom:5px;
}

.footer-column a{
    color:#d2cbd6;
    text-decoration:none;

    font-size:15px;

    transition:.3s;
}

.footer-column a:hover{
    color:#fff;
    padding-left:4px;
}

/* Contact */

.contact-item{
    display:flex;
    align-items:center;
    gap:8px;

    color:#d2cbd6;

    font-size:15px;

    margin-bottom:7px;
}

.contact-icon{
    width:15px;
    text-align:center;
    font-size:18px;
}

/* =========================
   COPYRIGHT
========================= */

.footer-bottom{
    width:92%;
    max-width:1180px;

    margin:8px auto 0;

    padding-top:7px;

    border-top:1px solid rgba(255,255,255,.14);

    display:flex;
    align-items:center;
    justify-content:space-between;

    font-size:12px;

    color:#bbb;
}

.footer-links{
    display:flex;
    gap:12px;
}

.footer-links a{
    color:#bbb;
    text-decoration:none;
    transition:.3s;
}

.footer-links a:hover{
    color:#fff;
}

/* =========================
   ANIMATIONS
========================= */

@keyframes fadeDown{
    from{
        opacity:0;
        transform:translateY(-25px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(20px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes floatCrystal{

    0%,100%{
        transform:
            rotate(35deg)
            translateY(0);
    }

    50%{
        transform:
            rotate(50deg)
            translateY(-8px);
    }
}

/* =========================
   TABLET
========================= */

@media(max-width:850px){

    .benefits-box{
        grid-template-columns:repeat(2,1fr);
    }

    .benefit:nth-child(2){
        border-right:none;
    }

    .benefit:nth-child(1),
    .benefit:nth-child(2){
        border-bottom:1px solid #ddd;
    }

    .reviews{
        grid-template-columns:1fr;
        max-width:600px;
        margin:auto;
    }

    .review-card{
        min-height:auto;
    }

    .footer-container{
        grid-template-columns:1fr 1fr;
    }

}

/* =========================
   MOBILE
========================= */

@media(max-width:600px){

    .benefits-section{
        padding-top:10px;
    }

    .benefits-box{
        width:94%;
        grid-template-columns:1fr 1fr;
    }

    .benefit{
        padding:10px;
        gap:8px;
    }

    .benefit-icon{
        width:34px;
        height:34px;
        font-size:14px;
    }

    .benefit h4{
        font-size:9px;
    }

    .benefit p{
        font-size:6.5px;
    }

    .section-title h2{
        font-size:21px;
    }

    .section-title p{
        font-size:8px;
    }

    .reviews{
        width:94%;
    }

    .community{
        min-height:105px;
    }

    .community h2{
        font-size:18px;
    }

    .subscribe{
        width:230px;
    }

    .crystal.one{
        left:4%;
    }

    .crystal.two{
        right:5%;
    }

    .crystal.three{
        right:2%;
    }

    footer{
        padding-top:25px;
    }

    .footer-container{
        width:88%;
        grid-template-columns:1fr 1fr;
        gap:25px 15px;
    }

    .footer-about{
        grid-column:1 / -1;
    }

    .footer-about p{
        max-width:100%;
    }

    .footer-bottom{
        width:88%;

        flex-direction:column;
        align-items:flex-start;

        gap:8px;
    }

    .footer-links{
        gap:8px;
        flex-wrap:wrap;
    }

}

/* =========================
   SMALL MOBILE
========================= */

@media(max-width:380px){

    .benefits-box{
        grid-template-columns:1fr;
    }

    .benefit{
        border-right:none !important;
        border-bottom:1px solid #ddd;
    }

    .benefit:last-child{
        border-bottom:none;
    }

    .footer-container{
        grid-template-columns:1fr;
    }

    .footer-about{
        grid-column:auto;
    }

    .footer-bottom{
        font-size:6px;
    }

}

</style>
</head>

<body>

<!-- =====================================
     COMMUNITY
===================================== -->

<section class="community">


    <div class="crystal one"></div>
    <div class="crystal two"></div>
    <div class="crystal three"></div>


    <div class="community-content">
        <br>
        <br>

        <h2>
            Join Our Crystal Community
        </h2>

        <p>
            Get exclusive offers, new arrivals and crystal tips straight to your inbox.
        </p>

<br>
        <form
            class="subscribe"
            id="subscribeForm"
        >

            <input
                type="email"
                id="email"
                placeholder="Enter your email address"
                required
            >

            <button type="submit">
                Subscribe
            </button>

        </form>
<br>
<br>
<br>
    </div>

</section>


<!-- =====================================
     FOOTER
===================================== -->

<footer>

    <div class="footer-container">


        <!-- ABOUT -->

        <div class="footer-about">

            <div class="footer-logo">

                <div class="logo-icon">
                    ♢
                </div>

                <div>

                    <h2>
                        Divinehealingworld
                    </h2>

                    <span>
                        Nature's Energy. Your Style
                    </span>

                </div>

            </div>


            <p>
                At Divinehealingworld, we bring you fine natural
                crystals and handcrafted jewellery to help you
                connect with your inner peace and positive energy.
            </p>


            <div class="socials">

                <a href="#" aria-label="Facebook">
                    f
                </a>

                <a href="#" aria-label="Instagram">
                    ◎
                </a>

                <a href="#" aria-label="Pinterest">
                    p
                </a>

                <a href="#" aria-label="Youtube">
                    ▶
                </a>

            </div>

        </div>


        <!-- QUICK LINKS -->

        <div class="footer-column">

            <h3>
                Quick Links
            </h3>

            <ul>

                <li>
                    <a href="#">Home</a>
                </li>
                <li>
                    <a href="#">About Us</a>
                </li>

                <li>
                    <a href="blog.php">Blog</a>
                </li>

                <li>
                    <a href="contact.php">Contact</a>
                </li>

            </ul>

        </div>


        <!-- SHOP -->

        <div class="footer-column">

            <h3>
               Our Services
            </h3>

            <ul>

                <li>
                    <a href="reiki-healing.php">Reiki Healing</a>
                </li>

                <li>
                    <a href="akashic-records.php">Akashic Records</a>
                </li>

                <li>
                    <a href="animal-communication.php">Animal Communication</a>
                </li>

                <li>
                    <a href="tarot-reading.php">Tarot Reading</a>
                </li>

                <li>
                    <a href="home-energy.php">Home Energy</a>
                </li>

                <li>
                    <a href="psychic-mediumShip.php<">Psychic MediumShip</a>
                </li>

            </ul>

        </div>


        <!-- CONTACT -->

        <div class="footer-column">

            <h3>
                Contact Us
            </h3>


            <div class="contact-item">

                <div class="contact-icon">
                    ✉
                </div>

                support@Divinehealingworld.com

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ☎
                </div>

                +91 9711766949

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ●
                </div>

                India

            </div>

        </div>


    </div>


    <!-- COPYRIGHT -->

    <div class="footer-bottom">

        <div>
            © 2026 Divinehealingworld. All rights reserved.
        </div>
          <div>
    Developed By
    <a
        href="https://www.google.com/search?q=parvez3737"
        target="_blank"
        rel="noopener noreferrer"
        style="text-decoration: none; color: inherit;"
    >
        Parvez Ahmad (Parvez3737)
    </a>
</div>

        <div class="footer-links">

            <a href="#">
                Privacy Policy
            </a>

            <span>|</span>

            <a href="#">
                Terms & Conditions
            </a>

            <span>|</span>

            <a href="#">
                Shipping Policy
            </a>

        </div>

    </div>

</footer>


<!-- =====================================
     JAVASCRIPT
===================================== -->

<script>

/* =====================================
   SCROLL REVEAL
===================================== */

const cards = document.querySelectorAll(".review-card");

const observer = new IntersectionObserver(
    (entries) => {

        entries.forEach((entry, index) => {

            if(entry.isIntersecting){

                setTimeout(() => {

                    entry.target.classList.add("show");

                }, index * 180);

                observer.unobserve(entry.target);

            }

        });

    },
    {
        threshold:0.15
    }
);


cards.forEach(card => {

    observer.observe(card);

});


/* =====================================
   NEWSLETTER
===================================== */

const form = document.getElementById("subscribeForm");

form.addEventListener("submit", function(e){

    e.preventDefault();

    const email =
        document.getElementById("email").value.trim();

    if(!email){
        return;
    }

    const button =
        form.querySelector("button");

    const oldText =
        button.textContent;

    button.textContent = "Subscribed ✓";

    button.style.background = "#493052";

    setTimeout(() => {

        button.textContent = oldText;

        button.style.background = "";

        form.reset();

    }, 2500);

});


/* =====================================
   MOUSE PARALLAX CRYSTALS
===================================== */

const crystals =
    document.querySelectorAll(".crystal");

document.addEventListener("mousemove", function(e){

    const x =
        (window.innerWidth / 2 - e.clientX) / 60;

    const y =
        (window.innerHeight / 2 - e.clientY) / 60;

    crystals.forEach((crystal, index) => {

        const amount =
            (index + 1) * 0.6;

        crystal.style.marginLeft =
            `${x * amount}px`;

        crystal.style.marginTop =
            `${y * amount}px`;

    });

});


/* =====================================
   REVIEW CARD HOVER
===================================== */

cards.forEach(card => {

    card.addEventListener("mouseenter", () => {

        card.style.zIndex = "5";

    });

    card.addEventListener("mouseleave", () => {

        card.style.zIndex = "";

    });

});

</script>

</body>
</html>