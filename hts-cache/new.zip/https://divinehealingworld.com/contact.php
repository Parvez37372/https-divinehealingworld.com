
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Divinehealingworld
    </title>

    <link
        rel="stylesheet"
        href="css/style.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >

    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Playfair+Display:wght@500;600&display=swap"
        rel="stylesheet"
    >

    <style>

        :root {
            --purple: #382342;
            --dark-purple: #24142e;
            --pink: #b61491;
            --text: #302632;
            --muted: #817782;
            --border: #ebe7ec;
            --light: #faf8fb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "DM Sans", sans-serif;
            color: var(--text);
            background: #fff;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        button {
            font-family: inherit;
        }


        /* =========================
           TOP BAR
        ========================= */

        .top-bar {
            height: 29px;
            background: var(--pink);
            color: #fff;
            padding: 0 5.5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 10px;
        }

        .top-bar-item {
            display: flex;
            align-items: center;
            gap: 7px;
        }

        .top-bar-item i {
            font-size: 11px;
        }


        /* =========================
           HEADER
        ========================= */

        .header {
            height: 78px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            position: relative;
            z-index: 1000;
        }

        .header-container {
            width: 89%;
            max-width: 1440px;
            height: 100%;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }


        /* LOGO */

        .logo {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 235px;
        }

        .logo-symbol {
            width: 43px;
            height: 43px;
            position: relative;
        }

        .logo-symbol img {
            width: 50px;
            height: -10px;
            object-fit: contain;
        }

        .logo-content h1 {
            font-family: "Playfair Display", serif;
            font-size: 25px;
            font-weight: 600;
            line-height: 1;
            color: var(--purple);
            letter-spacing: -0.5px;
        }

        .logo-content p {
            font-size: 10px;
            color: #77707b;
            margin-top: 4px;
            letter-spacing: .35px;
        }


        /* NAVIGATION */

        .navigation {
            height: 100%;
            display: flex;
            align-items: center;
            gap: 34px;
        }

        .nav-link {
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
            font-size: 12px;
            color: #302932;
            transition: color .25s ease;
        }

        .nav-link::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 19px;
            width: 0;
            height: 2px;
            background: var(--purple);
            transition: width .3s ease;
        }

        .nav-link:hover,
        .nav-link.active {
            color: var(--purple);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            width: 100%;
        }

        .shop-link {
            gap: 6px;
        }

        .shop-link i {
            font-size: 8px;
        }


        /* SHOP DROPDOWN */

        .shop-dropdown {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
        }

        .shop-menu {
            display: none;
            list-style: none;
            padding: 8px 0;
            margin: 0;
            position: absolute;
            top: 100%;
            left: 0;
            min-width: 230px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 10px 28px rgba(36,20,46,.12);
            z-index: 9999;
        }

        .shop-dropdown:hover .shop-menu {
            display: block;
        }

        .shop-dropdown:hover .shop-link i {
            transform: rotate(180deg);
        }

        .shop-link i {
            transition: .25s ease;
        }

        .shop-menu li a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 11px 15px;
            color: #333;
            font-size: 13px;
            transition: .2s ease;
        }

        .shop-menu li a:hover {
            background: #faf5fb;
            color: var(--pink);
        }

        .shop-menu li a i {
            width: 17px;
            color: var(--purple);
            font-size: 12px;
        }


        /* HEADER ACTIONS */

        .header-actions {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .header-icon {
            border: 0;
            background: transparent;
            color: #302632;
            font-size: 17px;
            width: 20px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            position: relative;
        }

        .header-icon:hover {
            color: var(--purple);
        }

        .badge-icon span {
            position: absolute;
            top: -5px;
            right: -8px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--purple);
            color: #fff;
            font-size: 8px;
            font-weight: 600;
        }


        /* MOBILE */

        .mobile-menu-button {
            display: none;
            border: 0;
            background: transparent;
            font-size: 19px;
            color: var(--purple);
            cursor: pointer;
        }

        .mobile-navigation {
            display: none;
            background: #fff;
            border-bottom: 1px solid var(--border);
            padding: 10px 5%;
            position: relative;
            z-index: 999;
            box-shadow: 0 8px 20px rgba(0,0,0,.06);
        }

        .mobile-navigation.show {
            display: block;
        }

        .mobile-navigation a {
            display: block;
            padding: 13px 5px;
            border-bottom: 1px solid #f0edf1;
            font-size: 13px;
        }

        .mobile-shop {
            border-bottom: 1px solid #f0edf1;
        }

        .mobile-shop-toggle {
            width: 100%;
            padding: 13px 5px;
            border: 0;
            background: transparent;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-family: inherit;
            font-size: 13px;
            color: #302932;
            cursor: pointer;
        }

        .mobile-shop-toggle i {
            font-size: 10px;
            transition: transform .25s ease;
        }

        .mobile-shop.open .mobile-shop-toggle i {
            transform: rotate(180deg);
        }

        .mobile-shop-menu {
            display: none;
            padding: 0 0 5px 14px;
        }

        .mobile-shop.open .mobile-shop-menu {
            display: block;
        }

        .mobile-shop-menu a {
            display: flex;
            align-items: center;
            gap: 9px;
            padding: 10px 5px;
            border-bottom: 0;
            font-size: 12px;
            color: #625a63;
        }

        .mobile-shop-menu i {
            width: 14px;
            font-size: 11px;
        }


        /* =========================
           SHOP PRODUCTS PAGE
        ========================= */


        .shop-heading {
            text-align: center;
            margin-bottom: 35px;
        }

        .shop-heading h2 {
            font-family: "Playfair Display", serif;
            font-size: 34px;
            color: var(--purple);
            margin-bottom: 8px;
        }

        .shop-heading p {
            color: var(--muted);
            font-size: 13px;
        }


        /* PRODUCT CARD */

        .products-list {
            display: grid;
            grid-template-columns: 1fr;
            gap: 18px;
        }

        .product-card {
            display: grid;
            grid-template-columns: 230px 1fr;
            gap: 25px;
            padding: 18px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 15px;
            box-shadow: 0 7px 24px rgba(36,20,46,.05);
            transition: transform .25s ease, box-shadow .25s ease;
        }

        .product-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(36,20,46,.09);
        }

        .product-image-wrap {
            width: 230px;
            height: 230px;
            border-radius: 12px;
            overflow: hidden;
            background: #faf8fb;
        }

        .product-image-wrap img {
            width: 100%;
            height: 100%;
            display: block;
            object-fit: cover;
        }

        .product-info {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 5px 10px 5px 0;
        }

        .product-title {
            color: var(--pink);
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 7px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .product-name {
            font-family: "Playfair Display", serif;
            color: var(--purple);
            font-size: 27px;
            font-weight: 600;
            margin-bottom: 11px;
        }

        .product-description {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.7;
            max-width: 700px;
            margin-bottom: 18px;
        }

        .product-bottom {
            display: flex;
            align-items: center;
            gap: 18px;
            flex-wrap: wrap;
        }

        .product-price {
            color: var(--purple);
            font-size: 21px;
            font-weight: 700;
        }

        .add-cart-btn {
            border: 0;
            border-radius: 8px;
            padding: 11px 19px;
            background: var(--purple);
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: .25s ease;
        }

        .add-cart-btn:hover {
            background: var(--pink);
        }

        .empty-products {
            text-align: center;
            padding: 55px 20px;
            border: 1px dashed #ddd5df;
            border-radius: 14px;
            color: var(--muted);
        }

        .empty-products i {
            font-size: 35px;
            color: #c7bdc9;
            margin-bottom: 12px;
        }

        .all-categories {
            display: flex;
            justify-content: center;
            gap: 9px;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        .category-pill {
            padding: 8px 14px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 11px;
            color: var(--purple);
            background: #fff;
        }

        .category-pill:hover {
            background: #faf5fb;
            border-color: #d9c9dc;
        }


        /* RESPONSIVE */

        @media (max-width: 1000px) {

            .header-container {
                width: 92%;
            }

            .navigation {
                gap: 20px;
            }

            .nav-link {
                font-size: 11px;
            }

            .logo {
                min-width: 205px;
            }

            .logo-content h1 {
                font-size: 22px;
            }

            .header-actions {
                gap: 13px;
            }

            .shop-page {
                width: 92%;
            }

        }

        @media (max-width: 768px) {

            .top-bar {
                display: none;
            }

            .header {
                height: 70px;
            }

            .navigation {
                display: none;
            }

            .header-container {
                width: 92%;
            }

            .header-actions {
                gap: 13px;
            }

            .header-actions .header-icon:nth-child(1),
            .header-actions .header-icon:nth-child(2) {
                display: none;
            }

            .mobile-menu-button {
                display: flex;
            }

            .logo {
                min-width: auto;
            }

            .logo-content h1 {
                font-size: 21px;
            }

            .logo-content p {
                font-size: 7px;
            }

            .shop-page {
                width: 92%;
                padding-top: 38px;
            }

            .shop-heading h2 {
                font-size: 28px;
            }

            .product-card {
                grid-template-columns: 1fr;
                gap: 17px;
            }

            .product-image-wrap {
                width: 100%;
                height: 260px;
            }

            .product-info {
                padding: 0 4px 5px;
            }

            .product-name {
                font-size: 23px;
            }

        }

        @media (max-width: 420px) {

            .header-container {
                width: 90%;
            }

            .header-actions {
                gap: 9px;
            }

            .product-image-wrap {
                height: 230px;
            }

            .product-bottom {
                align-items: flex-start;
                flex-direction: column;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     TOP BAR
========================= -->

<!--<div class="top-bar">

    <div class="top-bar-item">
        <i class="fa-solid fa-truck"></i>
        <span>Free Shipping All Over India</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-regular fa-gem"></i>
        <span>100% Natural & Authentic Crystals</span>
    </div>

    <div class="top-bar-item">
        <i class="fa-solid fa-shield-halved"></i>
        <span>Easy Returns & Secure Payments</span>
    </div>

</div>-->


<!-- =========================
     HEADER
========================= -->

<header class="header">

    <div class="header-container">


        <a href="https://divinehealingworld.com/" class="logo">

            <div class="logo-symbol">

                <img
                    src="https://vectorjungal.com/files/preview/1280x977/11724061489x7dnzumlkkkdctwc1jp9s6hmcc7hkelbcywsoq1ks90ylksgcvupex8nfc0knms8robegbblqtofo2ckk2viwtbtpyhxqomm1o4i.png"
                    alt="Divinehealingworld"
                >

            </div>

            <div class="logo-content">

                <h1>Divine Healing world</h1>

                <p>Nature's Energy. Your Style</p>

            </div>

        </a>


        <nav class="navigation">

            <a href="https://divinehealingworld.com/" class="nav-link">
                Home
            </a>
<a href="/reiki-healing.php" class="nav-link">
                Reiki Healing
            

            <a href="/tarot-reading.php" class="nav-link">
                Tarot Reading
            </a>

            <a href="/akashic-records.php" class="nav-link">
                Akashic Records
            </a>

            <a href="/animal-communication.php" class="nav-link">
                Animal Communication
            </a>

  <a href="/psychic-mediumship.php" class="nav-link">
                Psychic Mediumship
            </a>                          <div class="shop-dropdown">

              <!---  <a
                    href="#"
                    class="nav-link shop-link "
                    aria-haspopup="true"
                >
                    Shop
                    <i class="fa-solid fa-chevron-down"></i>
                </a>


                <ul class="shop-menu">
                    /
                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=3"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Crystals
                                </a>

                            </li>

                        
                            <li>

                                <a
                                    href="shop-category-products.php?category_id=4"
                                >

                                    <i class="fa-solid fa-layer-group"></i>

                                    Rings
                                </a>

                            </li>

                        
                    
                </ul>---->

            </div>


        </nav>


        <div class="header-actions">
         <style>
         .session-btn
         {
             background:black;
             color:#fff;
             font-size:15px;
             font-weight:bold;
             border:solid 1px white;
             padding:10px;
             border-radius:15px;
         }
         
         </style>
            <button class="session-btn"><a href="book-your-session.php">Book Session</a></button>
        </div>

    </div>

</header>


<!-- =========================
     MOBILE NAV
========================= -->

<nav
    class="mobile-navigation"
    id="mobileNavigation"
>

    <a href="index.php">
        Home
    </a>


    <div class="mobile-shop">

        <button
            type="button"
            class="mobile-shop-toggle"
            id="mobileShopToggle"
        >

            <span>
                Shop
            </span>

            <i class="fa-solid fa-chevron-down"></i>

        </button>


        <div
            class="mobile-shop-menu"
            id="mobileShopMenu"
        >

            <a href="products.php">

                <i class="fa-solid fa-box"></i>

                Products

            </a>


            <a href="best-sellers.php">

                <i class="fa-solid fa-star"></i>

                Best Sellers

            </a>


            
                <a
                    href="shop-category-products.php?category_id=3"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Crystals
                </a>

            
                <a
                    href="shop-category-products.php?category_id=4"
                >

                    <i class="fa-solid fa-layer-group"></i>

                    Rings
                </a>

            
        </div>

    </div>


    <a href="about.php">
        About Us
    </a>

    <a href="#">
        Tarot Reading
    </a>

    <a href="#">
        Akashic Records
    </a>

    <a href="#">
        Animal Communication
    </a>

</nav>


<!-- =========================
     PRODUCTS
========================= -->

<main class="shop-page">

    

</main>


<script>

    /* =========================
       MOBILE MENU
    ========================= */

    const menuButton =
        document.getElementById("menuButton");

    const mobileNavigation =
        document.getElementById("mobileNavigation");

    const menuIcon =
        menuButton
            ? menuButton.querySelector("i")
            : null;


    if (
        menuButton &&
        mobileNavigation &&
        menuIcon
    ) {

        menuButton.addEventListener("click", () => {

            mobileNavigation.classList.toggle("show");

            if (
                mobileNavigation.classList.contains("show")
            ) {

                menuIcon.classList.remove("fa-bars");
                menuIcon.classList.add("fa-xmark");

            } else {

                menuIcon.classList.remove("fa-xmark");
                menuIcon.classList.add("fa-bars");

            }

        });

    }


    /* =========================
       MOBILE SHOP
    ========================= */

    const mobileShopToggle =
        document.getElementById("mobileShopToggle");

    const mobileShop =
        document.querySelector(".mobile-shop");


    if (
        mobileShopToggle &&
        mobileShop
    ) {

        mobileShopToggle.addEventListener(
            "click",
            function () {

                mobileShop.classList.toggle("open");

            }
        );

    }


    /* =========================
       ADD TO CART
       UI READY
    ========================= */

    document
        .querySelectorAll(".add-cart-btn")
        .forEach(button => {

            button.addEventListener(
                "click",
                function () {

                    const productName =
                        this.dataset.productName || "Product";

                    alert(
                        productName +
                        " added to cart."
                    );

                }
            );

        });


    /* =========================
       CLOSE MOBILE MENU
    ========================= */

    document
        .querySelectorAll(".mobile-navigation a")
        .forEach(link => {

            link.addEventListener(
                "click",
                function () {

                    if (mobileNavigation) {
                        mobileNavigation.classList.remove("show");
                    }

                    if (menuIcon) {

                        menuIcon.classList.remove("fa-xmark");
                        menuIcon.classList.add("fa-bars");

                    }

                    if (mobileShop) {
                        mobileShop.classList.remove("open");
                    }

                }
            );

        });

</script>

</body>
</html>

<!-- =====================================================
     CONTACT PAGE
===================================================== -->

<style>

/* =====================================================
   GLOBAL CONTACT PAGE
===================================================== */

.contact-page {
    width: 100%;
    overflow: hidden;
    background: #ffffff;
    color: #211b23;
}


/* =====================================================
   HERO SECTION
===================================================== */

.contact-hero {
    position: relative;
    min-height: 330px;

    display: flex;
    align-items: center;

    overflow: hidden;

    background-image:
        url("./ads2.png");

    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}


.contact-hero-overlay {
    position: absolute;
    inset: 0;

    background:
        linear-gradient(
            90deg,
            rgba(17, 7, 20, .96) 0%,
            rgba(24, 7, 24, .88) 40%,
            rgba(35, 8, 30, .60) 70%,
            rgba(30, 8, 28, .38) 100%
        );

    z-index: 1;
}


.contact-hero-container {
    position: relative;
    z-index: 3;

    width: 100%;
    max-width: 1250px;

    margin: auto;

    padding: 65px 5.5%;
}


.contact-hero-content {
    max-width: 700px;

    animation:
        contactHeroShow .9s ease forwards;
}


@keyframes contactHeroShow {

    from {
        opacity: 0;
        transform: translateY(30px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }

}


.contact-breadcrumb {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    margin-bottom: 17px;

    color: rgba(255,255,255,.70);

    font-size: 12px;
}


.contact-breadcrumb a {
    color: #ff4c99;
    text-decoration: none;
}


.contact-breadcrumb i {
    font-size: 9px;
}


.contact-hero h1 {
    margin: 0;

    color: #ffffff;

    font-size:
        clamp(38px, 5vw, 58px);

    line-height: 1.05;

    font-weight: 800;

    letter-spacing: -1.7px;
}


.contact-hero h1 span {
    background:
        linear-gradient(
            90deg,
            #ff3e8d,
            #c22bdf
        );

    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}


.contact-hero p {
    max-width: 590px;

    margin: 16px 0 0;

    color: rgba(255,255,255,.74);

    font-size: 14px;

    line-height: 1.75;
}


/* Hero decorative glow */

.contact-hero::before {
    content: "";

    position: absolute;

    width: 330px;
    height: 330px;

    right: 8%;
    top: 50%;

    transform: translateY(-50%);

    border-radius: 50%;

    background:
        radial-gradient(
            circle,
            rgba(255,47,120,.16),
            transparent 70%
        );

    z-index: 2;

    animation:
        contactGlow 4s ease-in-out infinite;
}


@keyframes contactGlow {

    0%, 100% {
        transform:
            translateY(-50%)
            scale(1);
    }

    50% {
        transform:
            translateY(-50%)
            scale(1.13);
    }

}


/* =====================================================
   CONTACT MAIN
===================================================== */

.contact-main {
    position: relative;

    padding: 85px 5.5%;

    background:
        radial-gradient(
            circle at 5% 10%,
            rgba(182,20,145,.055),
            transparent 28%
        ),
        radial-gradient(
            circle at 95% 90%,
            rgba(124,40,199,.05),
            transparent 28%
        ),
        #ffffff;
}


.contact-container {
    max-width: 1180px;

    margin: auto;
}


/* =====================================================
   TOP TITLE
===================================================== */

.contact-section-heading {
    max-width: 700px;

    margin:
        0 auto 50px;

    text-align: center;
}


.contact-section-heading .small-title {
    display: inline-flex;

    align-items: center;

    gap: 7px;

    padding:
        6px 14px;

    margin-bottom: 13px;

    border-radius: 50px;

    background:
        rgba(182,20,145,.07);

    color: #b61491;

    font-size: 10px;

    font-weight: 700;

    letter-spacing: 1px;

    text-transform: uppercase;
}


.small-title span {
    width: 6px;
    height: 6px;

    border-radius: 50%;

    background: #b61491;
}


.contact-section-heading h2 {
    margin: 0;

    color: #211b23;

    font-size:
        clamp(28px, 4vw, 42px);

    line-height: 1.15;

    font-weight: 800;

    letter-spacing: -1px;
}


.contact-section-heading h2 span {
    color: #b61491;
}


.contact-section-heading p {
    max-width: 600px;

    margin:
        13px auto 0;

    color: #77717a;

    font-size: 13px;

    line-height: 1.7;
}


/* =====================================================
   CONTACT GRID
===================================================== */

.contact-grid {
    display: grid;

    grid-template-columns:
        .85fr 1.15fr;

    gap: 28px;

    align-items: stretch;
}


/* =====================================================
   LEFT INFO PANEL
===================================================== */

.contact-info {
    position: relative;

    padding: 32px;

    overflow: hidden;

    border-radius: 24px;

    background:
        linear-gradient(
            145deg,
            #241020,
            #180c19 60%,
            #260d22
        );

    box-shadow:
        0 20px 55px
        rgba(43,12,42,.16);
}


.contact-info::after {
    content: "";

    position: absolute;

    width: 210px;
    height: 210px;

    right: -100px;
    bottom: -100px;

    border-radius: 50%;

    background:
        rgba(182,20,145,.16);

    filter: blur(3px);
}


.contact-info h3 {
    position: relative;
    z-index: 2;

    margin: 0;

    color: #ffffff;

    font-size: 25px;

    font-weight: 800;
}


.contact-info > p {
    position: relative;
    z-index: 2;

    margin:
        11px 0 28px;

    color:
        rgba(255,255,255,.65);

    font-size: 12px;

    line-height: 1.7;
}


/* =====================================================
   INFO ITEMS
===================================================== */

.contact-info-item {
    position: relative;
    z-index: 3;

    display: flex;

    align-items: flex-start;

    gap: 14px;

    padding:
        14px 0;

    border-bottom:
        1px solid
        rgba(255,255,255,.08);
}


.contact-info-item:last-of-type {
    border-bottom: none;
}


.contact-info-icon {
    width: 40px;
    height: 40px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 12px;

    color: #ff4b98;

    background:
        rgba(255,255,255,.07);

    font-size: 14px;
}


.contact-info-item strong {
    display: block;

    margin-bottom: 4px;

    color: #ffffff;

    font-size: 12px;

    font-weight: 700;
}


.contact-info-item span,
.contact-info-item a {
    color:
        rgba(255,255,255,.58);

    font-size: 11px;

    line-height: 1.5;

    text-decoration: none;

    word-break: break-word;
}


.contact-info-item a:hover {
    color: #ff4b98;
}


/* =====================================================
   SOCIAL ICONS
===================================================== */

.contact-social {
    position: relative;
    z-index: 3;

    display: flex;

    gap: 9px;

    margin-top: 25px;
}


.contact-social a {
    width: 35px;
    height: 35px;

    display: flex;

    align-items: center;
    justify-content: center;

    border:
        1px solid
        rgba(255,255,255,.10);

    border-radius: 10px;

    color:
        rgba(255,255,255,.72);

    text-decoration: none;

    background:
        rgba(255,255,255,.05);

    transition:
        .3s ease;
}


.contact-social a:hover {
    color: #ffffff;

    background:
        linear-gradient(
            135deg,
            #b61491,
            #7c28c7
        );

    transform:
        translateY(-3px);
}


/* =====================================================
   FORM CARD
===================================================== */

.contact-form-card {
    padding: 35px;

    border:
        1px solid
        #eee7ef;

    border-radius: 24px;

    background: #ffffff;

    box-shadow:
        0 20px 55px
        rgba(38,12,40,.07);
}


.contact-form-card h3 {
    margin: 0;

    color: #241e26;

    font-size: 24px;

    font-weight: 800;
}


.contact-form-card > p {
    margin:
        8px 0 24px;

    color: #89828b;

    font-size: 12px;

    line-height: 1.6;
}


/* =====================================================
   FORM GRID
===================================================== */

.contact-form {
    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 17px;
}


.form-group {
    position: relative;
}


.form-group.full {
    grid-column:
        1 / -1;
}


.form-group label {
    display: block;

    margin-bottom: 7px;

    color: #403842;

    font-size: 11px;

    font-weight: 700;
}


.form-control {
    width: 100%;

    box-sizing: border-box;

    padding:
        12px 14px;

    border:
        1px solid
        #e9e3ea;

    border-radius: 10px;

    outline: none;

    color: #302933;

    background: #faf9fb;

    font-family: inherit;

    font-size: 12px;

    transition:
        border-color .25s ease,
        box-shadow .25s ease,
        background .25s ease;
}


.form-control::placeholder {
    color: #aaa4ac;
}


.form-control:focus {
    border-color: #c23aa4;

    background: #ffffff;

    box-shadow:
        0 0 0 3px
        rgba(182,20,145,.08);
}


textarea.form-control {
    min-height: 125px;

    resize: vertical;
}


/* =====================================================
   SUBMIT BUTTON
===================================================== */

.contact-submit {
    grid-column:
        1 / -1;

    display: flex;

    justify-content: flex-end;

    margin-top: 2px;
}


.contact-submit button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    gap: 9px;

    min-width: 155px;

    padding:
        12px 20px;

    border: none;

    border-radius: 10px;

    cursor: pointer;

    color: #ffffff;

    font-family: inherit;

    font-size: 12px;

    font-weight: 700;

    background:
        linear-gradient(
            135deg,
            #b61491,
            #7c28c7
        );

    box-shadow:
        0 10px 25px
        rgba(182,20,145,.22);

    transition:
        .3s ease;
}


.contact-submit button:hover {
    transform:
        translateY(-3px);

    box-shadow:
        0 15px 30px
        rgba(182,20,145,.30);
}


.contact-submit button i {
    transition:
        transform .3s ease;
}


.contact-submit button:hover i {
    transform:
        translateX(4px);
}


/* =====================================================
   BOTTOM CTA
===================================================== */

.contact-cta {
    position: relative;

    margin-top: 70px;

    min-height: 220px;

    display: flex;

    align-items: center;

    overflow: hidden;

    border-radius: 25px;

    background-image:
        url("./ads2.png");

    background-size: cover;

    background-position: center;
}


.contact-cta-overlay {
    position: absolute;

    inset: 0;

    background:
        linear-gradient(
            90deg,
            rgba(24,8,23,.95),
            rgba(75,14,57,.72)
        );
}


.contact-cta-content {
    position: relative;

    z-index: 2;

    padding:
        35px 45px;

    max-width: 700px;
}


.contact-cta-content h3 {
    margin: 0;

    color: #ffffff;

    font-size: 28px;

    font-weight: 800;
}


.contact-cta-content h3 span {
    color: #ff4b98;
}


.contact-cta-content p {
    margin:
        9px 0 18px;

    color:
        rgba(255,255,255,.68);

    font-size: 12px;

    line-height: 1.6;
}


.cta-btn {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    padding:
        10px 17px;

    border-radius: 9px;

    color: #ffffff;

    text-decoration: none;

    font-size: 11px;

    font-weight: 700;

    background:
        linear-gradient(
            135deg,
            #ff2f78,
            #a52bd5
        );

    transition:
        .3s ease;
}


.cta-btn:hover {
    color: #ffffff;

    transform:
        translateY(-3px);
}


/* =====================================================
   ANIMATIONS
===================================================== */

.contact-animate {
    opacity: 0;

    transform:
        translateY(30px);

    transition:
        opacity .8s ease,
        transform .8s ease;
}


.contact-animate.show {
    opacity: 1;

    transform:
        translateY(0);
}


/* =====================================================
   TABLET
===================================================== */

@media (max-width: 900px) {

    .contact-hero {
        min-height: 300px;
    }


    .contact-hero-container {
        padding:
            55px 6%;
    }


    .contact-main {
        padding:
            65px 6%;
    }


    .contact-grid {
        grid-template-columns:
            1fr;
    }


    .contact-info {
        min-height:
            auto;
    }

}


/* =====================================================
   MOBILE
===================================================== */

@media (max-width: 600px) {

    .contact-hero {
        min-height: 280px;

        background-position:
            center;
    }


    .contact-hero-overlay {
        background:
            linear-gradient(
                90deg,
                rgba(17,7,20,.96),
                rgba(30,8,28,.76)
            );
    }


    .contact-hero-container {
        padding:
            48px 20px;
    }


    .contact-hero h1 {
        font-size:
            38px;

        letter-spacing:
            -1px;
    }


    .contact-hero p {
        font-size:
            12px;

        line-height:
            1.65;
    }


    .contact-main {
        padding:
            55px 18px;
    }


    .contact-section-heading {
        margin-bottom:
            35px;
    }


    .contact-section-heading h2 {
        font-size:
            29px;
    }


    .contact-section-heading p {
        font-size:
            12px;
    }


    .contact-info {
        padding:
            25px 20px;

        border-radius:
            20px;
    }


    .contact-form-card {
        padding:
            25px 18px;

        border-radius:
            20px;
    }


    .contact-form {
        grid-template-columns:
            1fr;

        gap: 14px;
    }


    .form-group.full {
        grid-column:
            auto;
    }


    .contact-submit {
        grid-column:
            auto;

        justify-content:
            stretch;
    }


    .contact-submit button {
        width: 100%;
    }


    .contact-cta {
        min-height:
            250px;

        margin-top:
            50px;

        border-radius:
            20px;
    }


    .contact-cta-content {
        padding:
            28px 22px;
    }


    .contact-cta-content h3 {
        font-size:
            25px;
    }


    .contact-hero::before {
        width:
            200px;

        height:
            200px;

        right:
            -80px;
    }

}


/* =====================================================
   SMALL MOBILE
===================================================== */

@media (max-width: 380px) {

    .contact-hero h1 {
        font-size:
            33px;
    }


    .contact-info {
        padding:
            22px 17px;
    }


    .contact-form-card {
        padding:
            22px 15px;
    }


    .contact-cta-content h3 {
        font-size:
            22px;
    }

}

</style>



<!-- =====================================================
     CONTACT PAGE START
===================================================== -->

<div class="contact-page">


    <!-- =================================================
         HERO
    ================================================== -->

    <section class="contact-hero">

        <div class="contact-hero-overlay"></div>

        <div class="contact-hero-container">

            <div class="contact-hero-content">

                <div class="contact-breadcrumb">

                    <a href="index.php">
                        Home
                    </a>

                    <i class="fa-solid fa-chevron-right"></i>

                    <span>
                        Contact Us
                    </span>

                </div>


                <h1>
                    Let's Start a
                    <span>Conversation</span>
                </h1>


                <p>
                    Have a question, suggestion, or simply want to
                    get in touch? Our team is here to listen and help.
                    Send us a message and we'll get back to you soon.
                </p>

            </div>

        </div>

    </section>



    <!-- =================================================
         CONTACT MAIN
    ================================================== -->

    <section class="contact-main">

        <div class="contact-container">


            <!-- SECTION HEADING -->

            <div class="contact-section-heading contact-animate">

                <div class="small-title">

                    <span></span>

                    Get In Touch

                </div>


                <h2>
                    We're Here To
                    <span>Help You</span>
                </h2>


                <p>
                    Whether you need assistance, have feedback,
                    or want to know more about us, feel free to
                    reach out through the form below.
                </p>

            </div>



            <!-- CONTACT GRID -->

            <div class="contact-grid">


                <!-- =========================================
                     LEFT INFORMATION
                ========================================== -->

                <div class="contact-info contact-animate">

                    <h3>
                        Contact Information
                    </h3>


                    <p>
                        Reach us through any of the options below.
                        We would love to hear from you.
                    </p>


                    <!-- Email -->

                    <div class="contact-info-item">

                        <div class="contact-info-icon">

                            <i class="fa-solid fa-envelope"></i>

                        </div>


                        <div>

                            <strong>
                                Email Address
                            </strong>

                            <a href="mailto:support@example.com">
                                support@example.com
                            </a>

                        </div>

                    </div>


                    <!-- Phone -->

                    <div class="contact-info-item">

                        <div class="contact-info-icon">

                            <i class="fa-solid fa-phone"></i>

                        </div>


                        <div>

                            <strong>
                                Phone Number
                            </strong>

                            <a href="tel:+919999999999">
                                +91 99999 99999
                            </a>

                        </div>

                    </div>


                    <!-- Location -->

                    <div class="contact-info-item">

                        <div class="contact-info-icon">

                            <i class="fa-solid fa-location-dot"></i>

                        </div>


                        <div>

                            <strong>
                                Location
                            </strong>

                            <span>
                                New Delhi, India
                            </span>

                        </div>

                    </div>


                    <!-- Working Hours -->

                    <div class="contact-info-item">

                        <div class="contact-info-icon">

                            <i class="fa-solid fa-clock"></i>

                        </div>


                        <div>

                            <strong>
                                Working Hours
                            </strong>

                            <span>
                                Monday – Saturday<br>
                                10:00 AM – 7:00 PM
                            </span>

                        </div>

                    </div>


                    <!-- Social -->

                    <div class="contact-social">

                        <a href="#" aria-label="Facebook">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>

                        <a href="#" aria-label="Instagram">
                            <i class="fa-brands fa-instagram"></i>
                        </a>

                        <a href="#" aria-label="Twitter">
                            <i class="fa-brands fa-x-twitter"></i>
                        </a>

                        <a href="#" aria-label="LinkedIn">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>

                    </div>

                </div>



                <!-- =========================================
                     CONTACT FORM
                ========================================== -->

                <div class="contact-form-card contact-animate">

                    <h3>
                        Send Us a Message
                    </h3>


                    <p>
                        Fill in the details below and we'll get
                        back to you as soon as possible.
                    </p>


                    <form
                        class="contact-form"
                        action="contact-submit.php"
                        method="POST"
                    >


                        <!-- Name -->

                        <div class="form-group">

                            <label for="name">
                                Full Name
                            </label>

                            <input
                                type="text"
                                id="name"
                                name="name"
                                class="form-control"
                                placeholder="Enter your name"
                                required
                            >

                        </div>


                        <!-- Email -->

                        <div class="form-group">

                            <label for="email">
                                Email Address
                            </label>

                            <input
                                type="email"
                                id="email"
                                name="email"
                                class="form-control"
                                placeholder="Enter your email"
                                required
                            >

                        </div>


                        <!-- Phone -->

                        <div class="form-group">

                            <label for="phone">
                                Phone Number
                            </label>

                            <input
                                type="tel"
                                id="phone"
                                name="phone"
                                class="form-control"
                                placeholder="Enter phone number"
                            >

                        </div>


                        <!-- Subject -->

                        <div class="form-group">

                            <label for="subject">
                                Subject
                            </label>

                            <input
                                type="text"
                                id="subject"
                                name="subject"
                                class="form-control"
                                placeholder="What is this about?"
                                required
                            >

                        </div>


                        <!-- Message -->

                        <div class="form-group full">

                            <label for="message">
                                Your Message
                            </label>

                            <textarea
                                id="message"
                                name="message"
                                class="form-control"
                                placeholder="Write your message here..."
                                required
                            ></textarea>

                        </div>


                        <!-- Submit -->

                        <div class="contact-submit">

                            <button
                                type="submit"
                            >

                                Send Message

                                <i class="fa-solid fa-paper-plane"></i>

                            </button>

                        </div>


                    </form>

                </div>

            </div>



            <!-- =================================================
                 BOTTOM AD / CTA
            ================================================== -->

            <div class="contact-cta contact-animate">

                <div class="contact-cta-overlay"></div>


                <div class="contact-cta-content">

                    <h3>
                        Have More Questions?
                        <span>We're Here.</span>
                    </h3>


                    <p>
                        Don't hesitate to reach out. Our team is
                        always happy to help you with your questions
                        and provide the information you need.
                    </p>


                    <a
                        href="mailto:support@example.com"
                        class="cta-btn"
                    >

                        Contact Support

                        <i class="fa-solid fa-arrow-right"></i>

                    </a>

                </div>

            </div>


        </div>

    </section>

</div>



<!-- =====================================================
     CONTACT PAGE JS
===================================================== -->

<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {


        /* ================================================
           SCROLL REVEAL
        ================================================ */

        const elements =
            document.querySelectorAll(
                ".contact-animate"
            );


        const observer =
            new IntersectionObserver(
                function (entries) {

                    entries.forEach(
                        function (entry) {

                            if (
                                entry.isIntersecting
                            ) {

                                entry.target.classList.add(
                                    "show"
                                );

                                observer.unobserve(
                                    entry.target
                                );

                            }

                        }
                    );

                },
                {
                    threshold: 0.12
                }
            );


        elements.forEach(
            function (element) {

                observer.observe(element);

            }
        );


        /* ================================================
           FORM BUTTON LOADING
        ================================================ */

        const form =
            document.querySelector(
                ".contact-form"
            );


        if (form) {

            form.addEventListener(
                "submit",
                function () {

                    const button =
                        form.querySelector(
                            "button[type='submit']"
                        );


                    if (button) {

                        button.innerHTML =
                            `
                            Sending...
                            <i class="fa-solid fa-spinner fa-spin"></i>
                            `;

                        button.style.pointerEvents =
                            "none";

                    }

                }
            );

        }

    }
);

</script>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Divinehealingworld - Customer Reviews</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

html{
    scroll-behavior:smooth;
}

body{
    font-family:'Poppins',sans-serif;
    background:#fff;
    color:#29202f;
    overflow-x:hidden;
}

button,
input{
    font-family:inherit;
}

.container{
    width:92%;
    max-width:1180px;
    margin:auto;
}

/* =========================
   BENEFITS
========================= */

.benefits-section{
    padding:16px 0 10px;
}

.benefits-box{
    width:92%;
    max-width:1200px;
    margin:auto;

    background:linear-gradient(
        120deg,
        #faf7f5,
        #fff,
        #faf7f5
    );

    border-radius:10px;

    box-shadow:
        0 5px 25px rgba(45,20,55,.04);

    display:grid;
    grid-template-columns:repeat(4,1fr);

    overflow:hidden;

    animation:fadeDown .8s ease;
}

.benefit{
    min-height:74px;

    display:flex;
    align-items:center;
    gap:13px;

    padding:10px 25px;

    border-right:1px solid #d9d2d8;

    transition:.35s ease;
}

.benefit:last-child{
    border-right:none;
}

.benefit:hover{
    background:#fff;
    transform:translateY(-2px);
}

.benefit-icon{
    width:40px;
    height:40px;

    border:1.5px solid #392443;
    border-radius:50%;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:18px;

    flex-shrink:0;

    transition:.4s ease;
}

.benefit:hover .benefit-icon{
    transform:rotate(360deg);
    background:#3b2546;
    color:#fff;
}

.benefit h4{
    font-size:11px;
    font-weight:600;
    margin-bottom:1px;
}

.benefit p{
    font-size:8px;
    color:#777;
}

/* =========================
   TESTIMONIAL
========================= */

.testimonial-section{
    padding:18px 0 18px;
}

.section-title{
    text-align:center;
    margin-bottom:15px;

    animation:fadeUp .8s ease;
}

.section-title h2{
    font-family:'DM Serif Display',serif;
    font-size:28px;
    font-weight:400;
    color:#33203e;
}

.section-title p{
    font-size:18px;
    color:#777;
    margin-top:1px;
}

/* =========================
   REVIEWS
========================= */

.reviews{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:14px;
}

.review-card{
    border:1px solid #e2dfe2;
    border-radius:5px;

    padding:11px 15px;

    min-height:108px;

    background:#fff;

    transition:
        transform .35s ease,
        box-shadow .35s ease,
        border-color .35s ease;

    opacity:0;
    transform:translateY(30px);
}

.review-card.show{
    opacity:1;
    transform:translateY(0);
}

.review-card:hover{
    transform:translateY(-6px);
    border-color:#c9b6d0;

    box-shadow:
        0 12px 30px rgba(54,30,65,.10);
}

.review-top{
    display:flex;
    align-items:center;
    gap:10px;
}

.avatar{
    width:42px;
    height:42px;

    border-radius:50%;
    overflow:hidden;

    flex-shrink:0;

    background:linear-gradient(
        135deg,
        #eee,
        #ddd
    );
}

.avatar img{
    width:100%;
    height:100%;
    object-fit:cover;
}

.stars{
    color:#e4a719;
    font-size:18px;
    letter-spacing:1px;
    margin-bottom:3px;
}

.review-text{
    font-size:12px;
    color:#4d4d4d;
    line-height:1.55;

    margin-top:8px;
}

.customer{
    margin-top:7px;
    font-size:12px;
    font-weight:600;
}

.customer-location{
    font-size:10px;
    color:#777;
    margin-top:1px;
}

/* =========================
   COMMUNITY
========================= */

.community{
    position:relative;

    background:
        linear-gradient(
            135deg,
            #684c72,
            #795a83,
            #67476e
        );

    min-height:98px;

    overflow:hidden;

    color:#fff;

    display:flex;
    justify-content:center;
    align-items:center;

    text-align:center;

    margin-top:0;
}

.community-content{
    position:relative;
    z-index:2;
}

.community h2{
    font-family:'DM Serif Display',serif;
    font-weight:400;
    font-size:25px;
}

.community p{
    font-size:15px;
    opacity:.85;
    margin:2px 0 8px;
}

.subscribe{
    display:flex;
    width:450px;
    height:40px;
    margin:auto;

    background:#fff;
    border-radius:20px;

    overflow:hidden;

    box-shadow:
        0 4px 15px rgba(0,0,0,.12);

    transition:.3s;
}

.subscribe:focus-within{
    transform:scale(1.03);
}

.subscribe input{
    flex:1;
    min-width:0;

    border:none;
    outline:none;

    padding:0 12px;

    font-size:15px;
    color:#444;
}

.subscribe button{
    border:none;

    width:100px;

    background:#28192f;
    color:#fff;

    font-size:15px;

    cursor:pointer;

    transition:.3s;
}

.subscribe button:hover{
    background:#170e1b;
}

/* Floating crystals */

.crystal{
    position:absolute;
    width:45px;
    height:45px;

    opacity:.25;

    border:1px solid #fff;

    transform:rotate(35deg);

    animation:floatCrystal 4s ease-in-out infinite;
}

.crystal::before{
    content:"";
    position:absolute;
    inset:8px;

    border:1px solid #fff;

    transform:rotate(45deg);
}

.crystal.one{
    left:15%;
    top:16px;
}

.crystal.two{
    right:15%;
    top:20px;
    width:35px;
    height:35px;

    animation-delay:1s;
}

.crystal.three{
    right:11%;
    top:43px;
    width:20px;
    height:20px;

    animation-delay:2s;
}

/* =========================
   FOOTER
========================= */

footer{
    background:
        linear-gradient(
            135deg,
            #20142a,
            #2b1936,
            #1d1325
        );

    color:#fff;

    padding:12px 0 8px;
}

.footer-container{
    width:100%;
    max-width:1200px;
    margin:auto;

    display:grid;

    grid-template-columns:
        1.7fr
        1fr
        1fr
        1.15fr;

    gap:30px;
}

/* Logo */

.footer-logo{
    display:flex;
    align-items:center;
    gap:7px;
}

.logo-icon{
    font-size:30px;
    line-height:1;
}

.footer-logo h2{
    font-family:'DM Serif Display',serif;
    font-size:23px;
    font-weight:400;
}

.footer-logo span{
    display:block;
    font-size:12px;
    color:#ddd;
    letter-spacing:.5px;
}

.footer-about p{
    font-size:10px;
    line-height:1.7;

    color:#d4ccd8;

    max-width:280px;

    margin-top:8px;
}

/* Social */

.socials{
    display:flex;
    gap:13px;
    margin-top:9px;
}

.socials a{
    color:#fff;
    text-decoration:none;

    font-size:20px;

    width:18px;
    height:18px;

    display:flex;
    align-items:center;
    justify-content:center;

    border-radius:50%;

    transition:.3s;
}

.socials a:hover{
    background:#fff;
    color:#28182f;
    transform:translateY(-3px);
}

/* Footer columns */

.footer-column h3{
    font-size:15px;
    font-weight:500;

    margin-bottom:8px;
}

.footer-column ul{
    list-style:none;
}

.footer-column li{
    margin-bottom:5px;
}

.footer-column a{
    color:#d2cbd6;
    text-decoration:none;

    font-size:15px;

    transition:.3s;
}

.footer-column a:hover{
    color:#fff;
    padding-left:4px;
}

/* Contact */

.contact-item{
    display:flex;
    align-items:center;
    gap:8px;

    color:#d2cbd6;

    font-size:15px;

    margin-bottom:7px;
}

.contact-icon{
    width:15px;
    text-align:center;
    font-size:18px;
}

/* =========================
   COPYRIGHT
========================= */

.footer-bottom{
    width:92%;
    max-width:1180px;

    margin:8px auto 0;

    padding-top:7px;

    border-top:1px solid rgba(255,255,255,.14);

    display:flex;
    align-items:center;
    justify-content:space-between;

    font-size:12px;

    color:#bbb;
}

.footer-links{
    display:flex;
    gap:12px;
}

.footer-links a{
    color:#bbb;
    text-decoration:none;
    transition:.3s;
}

.footer-links a:hover{
    color:#fff;
}

/* =========================
   ANIMATIONS
========================= */

@keyframes fadeDown{
    from{
        opacity:0;
        transform:translateY(-25px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes fadeUp{
    from{
        opacity:0;
        transform:translateY(20px);
    }

    to{
        opacity:1;
        transform:translateY(0);
    }
}

@keyframes floatCrystal{

    0%,100%{
        transform:
            rotate(35deg)
            translateY(0);
    }

    50%{
        transform:
            rotate(50deg)
            translateY(-8px);
    }
}

/* =========================
   TABLET
========================= */

@media(max-width:850px){

    .benefits-box{
        grid-template-columns:repeat(2,1fr);
    }

    .benefit:nth-child(2){
        border-right:none;
    }

    .benefit:nth-child(1),
    .benefit:nth-child(2){
        border-bottom:1px solid #ddd;
    }

    .reviews{
        grid-template-columns:1fr;
        max-width:600px;
        margin:auto;
    }

    .review-card{
        min-height:auto;
    }

    .footer-container{
        grid-template-columns:1fr 1fr;
    }

}

/* =========================
   MOBILE
========================= */

@media(max-width:600px){

    .benefits-section{
        padding-top:10px;
    }

    .benefits-box{
        width:94%;
        grid-template-columns:1fr 1fr;
    }

    .benefit{
        padding:10px;
        gap:8px;
    }

    .benefit-icon{
        width:34px;
        height:34px;
        font-size:14px;
    }

    .benefit h4{
        font-size:9px;
    }

    .benefit p{
        font-size:6.5px;
    }

    .section-title h2{
        font-size:21px;
    }

    .section-title p{
        font-size:8px;
    }

    .reviews{
        width:94%;
    }

    .community{
        min-height:105px;
    }

    .community h2{
        font-size:18px;
    }

    .subscribe{
        width:230px;
    }

    .crystal.one{
        left:4%;
    }

    .crystal.two{
        right:5%;
    }

    .crystal.three{
        right:2%;
    }

    footer{
        padding-top:25px;
    }

    .footer-container{
        width:88%;
        grid-template-columns:1fr 1fr;
        gap:25px 15px;
    }

    .footer-about{
        grid-column:1 / -1;
    }

    .footer-about p{
        max-width:100%;
    }

    .footer-bottom{
        width:88%;

        flex-direction:column;
        align-items:flex-start;

        gap:8px;
    }

    .footer-links{
        gap:8px;
        flex-wrap:wrap;
    }

}

/* =========================
   SMALL MOBILE
========================= */

@media(max-width:380px){

    .benefits-box{
        grid-template-columns:1fr;
    }

    .benefit{
        border-right:none !important;
        border-bottom:1px solid #ddd;
    }

    .benefit:last-child{
        border-bottom:none;
    }

    .footer-container{
        grid-template-columns:1fr;
    }

    .footer-about{
        grid-column:auto;
    }

    .footer-bottom{
        font-size:6px;
    }

}

</style>
</head>

<body>

<!-- =====================================
     COMMUNITY
===================================== -->

<section class="community">


    <div class="crystal one"></div>
    <div class="crystal two"></div>
    <div class="crystal three"></div>


    <div class="community-content">
        <br>
        <br>

        <h2>
            Join Our Crystal Community
        </h2>

        <p>
            Get exclusive offers, new arrivals and crystal tips straight to your inbox.
        </p>

<br>
        <form
            class="subscribe"
            id="subscribeForm"
        >

            <input
                type="email"
                id="email"
                placeholder="Enter your email address"
                required
            >

            <button type="submit">
                Subscribe
            </button>

        </form>
<br>
<br>
<br>
    </div>

</section>


<!-- =====================================
     FOOTER
===================================== -->

<footer>

    <div class="footer-container">


        <!-- ABOUT -->

        <div class="footer-about">

            <div class="footer-logo">

                <div class="logo-icon">
                    ♢
                </div>

                <div>

                    <h2>
                        Divinehealingworld
                    </h2>

                    <span>
                        Nature's Energy. Your Style
                    </span>

                </div>

            </div>


            <p>
                At Divinehealingworld, we bring you fine natural
                crystals and handcrafted jewellery to help you
                connect with your inner peace and positive energy.
            </p>


            <div class="socials">

                <a href="#" aria-label="Facebook">
                    f
                </a>

                <a href="#" aria-label="Instagram">
                    ◎
                </a>

                <a href="#" aria-label="Pinterest">
                    p
                </a>

                <a href="#" aria-label="Youtube">
                    ▶
                </a>

            </div>

        </div>


        <!-- QUICK LINKS -->

        <div class="footer-column">

            <h3>
                Quick Links
            </h3>

            <ul>

                <li>
                    <a href="#">Home</a>
                </li>
                <li>
                    <a href="#">About Us</a>
                </li>

                <li>
                    <a href="blog.php">Blog</a>
                </li>

                <li>
                    <a href="contact.php">Contact</a>
                </li>

            </ul>

        </div>


        <!-- SHOP -->

        <div class="footer-column">

            <h3>
               Our Services
            </h3>

            <ul>

                <li>
                    <a href="reiki-healing.php">Reiki Healing</a>
                </li>

                <li>
                    <a href="akashic-records.php">Akashic Records</a>
                </li>

                <li>
                    <a href="animal-communication.php">Animal Communication</a>
                </li>

                <li>
                    <a href="tarot-reading.php">Tarot Reading</a>
                </li>

                <li>
                    <a href="home-energy.php">Home Energy</a>
                </li>

                <li>
                    <a href="psychic-mediumShip.php<">Psychic MediumShip</a>
                </li>

            </ul>

        </div>


        <!-- CONTACT -->

        <div class="footer-column">

            <h3>
                Contact Us
            </h3>


            <div class="contact-item">

                <div class="contact-icon">
                    ✉
                </div>

                support@Divinehealingworld.com

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ☎
                </div>

                +91 9711766949

            </div>


            <div class="contact-item">

                <div class="contact-icon">
                    ●
                </div>

                India

            </div>

        </div>


    </div>


    <!-- COPYRIGHT -->

    <div class="footer-bottom">

        <div>
            © 2026 Divinehealingworld. All rights reserved.
        </div>
          <div>
    Developed By
    <a
        href="https://www.google.com/search?q=parvez3737"
        target="_blank"
        rel="noopener noreferrer"
        style="text-decoration: none; color: inherit;"
    >
        Parvez Ahmad (Parvez3737)
    </a>
</div>

        <div class="footer-links">

            <a href="#">
                Privacy Policy
            </a>

            <span>|</span>

            <a href="#">
                Terms & Conditions
            </a>

            <span>|</span>

            <a href="#">
                Shipping Policy
            </a>

        </div>

    </div>

</footer>


<!-- =====================================
     JAVASCRIPT
===================================== -->

<script>

/* =====================================
   SCROLL REVEAL
===================================== */

const cards = document.querySelectorAll(".review-card");

const observer = new IntersectionObserver(
    (entries) => {

        entries.forEach((entry, index) => {

            if(entry.isIntersecting){

                setTimeout(() => {

                    entry.target.classList.add("show");

                }, index * 180);

                observer.unobserve(entry.target);

            }

        });

    },
    {
        threshold:0.15
    }
);


cards.forEach(card => {

    observer.observe(card);

});


/* =====================================
   NEWSLETTER
===================================== */

const form = document.getElementById("subscribeForm");

form.addEventListener("submit", function(e){

    e.preventDefault();

    const email =
        document.getElementById("email").value.trim();

    if(!email){
        return;
    }

    const button =
        form.querySelector("button");

    const oldText =
        button.textContent;

    button.textContent = "Subscribed ✓";

    button.style.background = "#493052";

    setTimeout(() => {

        button.textContent = oldText;

        button.style.background = "";

        form.reset();

    }, 2500);

});


/* =====================================
   MOUSE PARALLAX CRYSTALS
===================================== */

const crystals =
    document.querySelectorAll(".crystal");

document.addEventListener("mousemove", function(e){

    const x =
        (window.innerWidth / 2 - e.clientX) / 60;

    const y =
        (window.innerHeight / 2 - e.clientY) / 60;

    crystals.forEach((crystal, index) => {

        const amount =
            (index + 1) * 0.6;

        crystal.style.marginLeft =
            `${x * amount}px`;

        crystal.style.marginTop =
            `${y * amount}px`;

    });

});


/* =====================================
   REVIEW CARD HOVER
===================================== */

cards.forEach(card => {

    card.addEventListener("mouseenter", () => {

        card.style.zIndex = "5";

    });

    card.addEventListener("mouseleave", () => {

        card.style.zIndex = "";

    });

});

</script>

</body>
</html>